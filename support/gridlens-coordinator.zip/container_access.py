#!/usr/bin/env python3
"""Restricted, container-local administration of explicitly approved VPN PCs.

This module uses Runtime's owned volume and glwg0 operations. Only public device
enrollment travels between PCs. Client private keys live in bounded, expiring
process memory; they are never written to a volume or returned by inventory.
"""

import base64
from concurrent.futures import ThreadPoolExecutor, wait
import hashlib
import hmac
import http.client
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import socket
import socketserver
import ssl
import stat
import struct
import threading
import time
from urllib.parse import urlsplit

MAX_PCS = 1024
MAX_REQUEST = 2 * 1024 * 1024
MAX_DOCUMENT = 8 * 1024 * 1024
LIFETIME = 900
MAX_SESSIONS = 32
CLIENT_NETWORK = ipaddress.ip_network('100.96.0.0/11')
ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}')
GENERATION = re.compile(r'[0-9a-f]{32}')
NAME = re.compile(r'[A-Za-z0-9_-]{1,48}')
RECORD_FIELDS = {'id', 'name', 'dashboard_url', 'control_url', 'certificate',
                 'server_public_key', 'endpoint', 'endpoint_family', 'ready', 'reason'}


class Error(Exception):
    pass


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise Error('duplicate JSON fields are not accepted')
        result[key] = value
    return result


def _key(value):
    try:
        return isinstance(value, str) and len(value) == 44 and len(base64.b64decode(value, validate=True)) == 32
    except (ValueError, TypeError):
        return False


def _identifier(value):
    return isinstance(value, str) and ID.fullmatch(value)


def _private(value):
    address = ipaddress.ip_address(value)
    if not any(address in ipaddress.ip_network(block) for block in
               ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', 'fc00::/7')):
        raise Error('access administration requires a private assigned address')
    return str(address)


def _origin(value, scheme, path=''):
    if not isinstance(value, str) or len(value) > 512:
        raise Error('invalid access URL')
    try:
        parsed = urlsplit(value)
        if (parsed.scheme != scheme or parsed.username or parsed.password or parsed.path != path
                or parsed.query or parsed.fragment or not parsed.port or not 1024 <= parsed.port <= 65535):
            raise ValueError()
        address = _private(parsed.hostname)
        expected = scheme + '://' + _hostport(address, parsed.port) + path
        if expected != value:
            raise ValueError()
        return parsed
    except (ValueError, TypeError) as exc:
        raise Error('access URL must use a literal assigned private address and explicit port') from exc


def _hostport(address, port):
    return ('[' + address + ']' if ':' in address else address) + ':' + str(port)


def certificate_pin(certificate):
    if (not isinstance(certificate, str) or len(certificate) > 16384
            or certificate.count('-----BEGIN CERTIFICATE-----') != 1
            or not certificate.strip().startswith('-----BEGIN CERTIFICATE-----')
            or not certificate.strip().endswith('-----END CERTIFICATE-----')
            or 'PRIVATE KEY' in certificate):
        raise Error('access approval requires one public certificate')
    try:
        der = ssl.PEM_cert_to_DER_cert(certificate)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.load_verify_locations(cadata=certificate)
        return hashlib.sha256(der).hexdigest()
    except (ValueError, ssl.SSLError) as exc:
        raise Error('access approval certificate is malformed') from exc


def _endpoint(value):
    try:
        parsed = urlsplit('udp://' + value)
        address = ipaddress.ip_address(parsed.hostname)
        if (parsed.username or parsed.password or parsed.path or parsed.query or parsed.fragment
                or not parsed.port or not 1 <= parsed.port <= 65535 or address.is_unspecified
                or address.is_loopback or address.is_multicast or getattr(address, 'ipv4_mapped', None)):
            raise ValueError()
        if value != _hostport(str(address), parsed.port):
            raise ValueError()
        return address, parsed.port
    except (ValueError, TypeError, AttributeError) as exc:
        raise Error('prepared VPN endpoints must be literal IP addresses with a UDP port') from exc


def validate_record(record):
    if not isinstance(record, dict) or set(record) != RECORD_FIELDS or not _identifier(record.get('id')):
        raise Error('invalid access PC registration fields')
    if (not isinstance(record['name'], str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', record['name'])
            or type(record['ready']) is not bool or not isinstance(record['reason'], str) or len(record['reason']) > 256
            or any(ord(char) < 32 or ord(char) == 127 for char in record['reason'])):
        raise Error('invalid access PC metadata')
    if (not isinstance(record['endpoint'], str) or len(record['endpoint']) > 300
            or record['endpoint_family'] not in ('', 'ipv4', 'ipv6') or not isinstance(record['server_public_key'], str)):
        raise Error('invalid access PC endpoint metadata')
    dashboard = _origin(record['dashboard_url'], 'http')
    control = _origin(record['control_url'], 'https', '/v1/access')
    if dashboard.hostname != control.hostname:
        raise Error('a PC must use its assigned address for dashboard and private administration')
    certificate_pin(record['certificate'])
    if record['ready']:
        remote, _ = _endpoint(record['endpoint'])
        if not _key(record['server_public_key']) or record['endpoint_family'] != 'ipv' + str(remote.version):
            raise Error('invalid prepared WireGuard server identity')
        if str(remote) == dashboard.hostname:
            raise Error('VPN endpoint conflicts with its dashboard route')
        # This runtime's owned DNAT supports IPv4 dashboard destinations only.
        if ipaddress.ip_address(dashboard.hostname).version != 4:
            raise Error('IPv6 dashboard VPN routing needs configuration')
    elif record['server_public_key'] and not _key(record['server_public_key']):
        raise Error('invalid WireGuard server public key')
    return dict(record)


class PeerTransport:
    """Private mTLS with an exact approved certificate pin; never HTTP redirects."""
    def __init__(self, runtime):
        self.runtime = runtime

    def __call__(self, pc, request):
        parsed = _origin(pc['control_url'], 'https', '/v1/access')
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.minimum_version = ssl.TLSVersion.TLSv1_3
        context.load_verify_locations(cadata=pc['certificate'])
        # Each public self-signed machine leaf is an explicit trust anchor.
        context.verify_flags |= getattr(ssl, 'VERIFY_X509_PARTIAL_CHAIN', 0)
        directory = self.runtime.base / 'identities/hub'
        for name in ('identity.crt', 'identity.key'):
            self.runtime._safe(directory / name)
        context.load_cert_chain(directory / 'identity.crt', directory / 'identity.key')
        connection = http.client.HTTPSConnection(parsed.hostname, parsed.port, timeout=4, context=context)
        try:
            connection.connect()
            pin = hashlib.sha256(connection.sock.getpeercert(binary_form=True)).hexdigest()
            if not hmac.compare_digest(pin, certificate_pin(pc['certificate'])):
                raise Error('private access server identity changed')
            payload = json.dumps(request, separators=(',', ':')).encode()
            if len(payload) > MAX_REQUEST:
                raise Error('public enrollment request exceeds its limit')
            connection.request('POST', '/v1/access', body=payload,
                               headers={'Content-Type': 'application/json', 'Accept': 'application/json'})
            response = connection.getresponse()
            data = response.read(MAX_REQUEST + 1)
            if response.status != 200 or len(data) > MAX_REQUEST:
                raise Error('private access operation was not acknowledged')
            result = json.loads(data, object_pairs_hook=_unique_object)
            if not isinstance(result, dict):
                raise Error('invalid private access acknowledgment')
            # The Go private endpoint returns the same envelope as the socket.
            if 'ok' in result:
                if result.get('ok') is not True or not isinstance(result.get('result'), dict):
                    raise Error('private access operation was rejected')
                result = result['result']
            return result
        finally:
            connection.close()


class AccessController:
    def __init__(self, runtime, transport=None, now=None):
        self.runtime = runtime
        self.now = now or runtime.now
        self.transport = transport or PeerTransport(runtime)
        self.sessions = {}
        self.session_lock = threading.RLock()
        self.path = runtime.control / 'access.json'

    def _load(self, state):
        if not self.path.exists():
            return {'schema': 1, 'owner': state['owner'], 'pcs': [], 'enrollments': {}}
        self.runtime._safe(self.path)
        raw = self.path.read_bytes()
        if len(raw) > MAX_DOCUMENT:
            raise Error('access state exceeds its limit')
        document = json.loads(raw)
        if (not isinstance(document, dict) or set(document) != {'schema', 'owner', 'pcs', 'enrollments'}
                or document['schema'] != 1 or document['owner'] != state['owner']
                or not isinstance(document['pcs'], list) or len(document['pcs']) > MAX_PCS
                or not isinstance(document['enrollments'], dict) or len(document['enrollments']) > 4096):
            raise Error('invalid owned access state')
        return document

    def _save(self, document):
        if len(document['enrollments']) > 4096 or len(json.dumps(document).encode()) > MAX_DOCUMENT:
            raise Error('saved access state exceeds its limit')
        self.runtime._write(self.path, document)

    def _public(self, state):
        runtime, c = self.runtime, state['config']
        if not c.get('advertise_host') or not c.get('management_available', True):
            raise Error('assign this PC a canonical private dashboard address before fleet access enrollment')
        dashboard = 'http://' + _hostport(c['advertise_host'], c['http_port'])
        record = {'id': state['hub_id'], 'name': c['name'], 'dashboard_url': dashboard,
                  'control_url': 'https://' + _hostport(c['advertise_host'], c['telemetry_port']) + '/v1/access',
                  'certificate': runtime._certificate('hub'), 'server_public_key': state.get('server_public_key', ''),
                  'endpoint': '', 'endpoint_family': '', 'ready': False, 'reason': 'WireGuard needs installation'}
        if c['mode'] == 'wireguard':
            endpoints = runtime._endpoints(state)
            verified = set()
            for peer in state.get('peers', {}).values():
                test = peer.get('last_test')
                if not isinstance(test, dict) or not test.get('verified') or test.get('endpoint_port') != c['udp_port']:
                    continue
                family = test.get('endpoint_family') if peer.get('fleet') else peer.get('profile')
                if family in endpoints and test.get('endpoint') == endpoints[family]:
                    verified.add(family)
            families = sorted(endpoints, key=lambda family: (family not in verified, family != 'ipv4'))
            for family in families:
                try:
                    host = endpoints[family]
                    try:
                        address = ipaddress.ip_address(host)
                    except ValueError:
                        af = socket.AF_INET if family == 'ipv4' else socket.AF_INET6
                        resolved = socket.getaddrinfo(host, c['udp_port'], af, socket.SOCK_DGRAM)
                        addresses = {str(ipaddress.ip_address(item[4][0])) for item in resolved}
                        if c['advertise_host'] in addresses or not addresses:
                            raise Error('endpoint routing conflict')
                        address = ipaddress.ip_address(sorted(addresses)[0])
                    candidate = {**record, 'endpoint': _hostport(str(address), c['udp_port']),
                                 'endpoint_family': 'ipv' + str(address.version), 'ready': True, 'reason': ''}
                    return validate_record(candidate)
                except (Error, ValueError, OSError):
                    record['reason'] = 'VPN endpoint or dashboard route needs configuration'
        return validate_record(record)

    def public(self):
        with self.runtime.locked():
            return self._public(self.runtime.load())

    def _roster(self, state, document):
        own = self._public(state)
        return [own] + [pc for pc in document['pcs'] if pc['id'] != own['id']]

    def _publish_roster(self, state, document):
        self.runtime._write(self.runtime.base / 'app/access-roster.json',
                            {'schema': 1, 'self_id': state['hub_id'], 'pcs': self._roster(state, document)},
                            0o640, gid=10001)

    def join(self, pcs):
        """Installer-only explicit trust replacement; never exposed over the socket."""
        if not isinstance(pcs, list) or len(pcs) > MAX_PCS:
            raise Error('an access roster supports at most 1,024 PCs')
        records = [validate_record(pc) for pc in pcs]
        if len({pc['id'] for pc in records}) != len(records) or len({certificate_pin(pc['certificate']) for pc in records}) != len(records):
            raise Error('duplicate access PC identity or certificate')
        with self.runtime.locked():
            state = self.runtime.load()
            own = self._public(state)
            supplied_self = next((pc for pc in records if pc['id'] == own['id']), own)
            if supplied_self != own:
                raise Error('roster does not match this PC\'s current public access registration')
            if len([pc for pc in records if pc['id'] != own['id']]) >= MAX_PCS:
                raise Error('the 1,024-PC access limit includes this PC')
            if any(pc['id'] != own['id'] and certificate_pin(pc['certificate']) == certificate_pin(own['certificate']) for pc in records):
                raise Error('another PC cannot reuse this PC\'s machine certificate')
            document = self._load(state)
            document['pcs'] = records
            self._save(document)
            self._publish_roster(state, document)
            return {'approved': len(self._roster(state, document)), 'restart_required': False}

    def _snapshot(self):
        with self.runtime.locked():
            state = self.runtime.load()
            document = self._load(state)
            return state, document, self._roster(state, document)

    @staticmethod
    def _route_conflicts(pcs):
        failures, destinations = {}, {}
        for pc in pcs:
            address = _origin(pc['dashboard_url'], 'http').hostname
            destinations.setdefault(address, []).append(pc['id'])
        for ids in destinations.values():
            if len(ids) > 1:
                for pc_id in ids:
                    failures[pc_id] = 'duplicate dashboard destination'
        for pc in pcs:
            if not pc['ready']:
                continue
            endpoint, _ = _endpoint(pc['endpoint'])
            if str(endpoint) in destinations:
                failures[pc['id']] = 'VPN endpoint conflicts with a dashboard route'
                for pc_id in destinations[str(endpoint)]:
                    failures[pc_id] = 'dashboard route conflicts with a VPN endpoint'
        keys, endpoints = {}, {}
        for pc in pcs:
            if pc['ready']:
                keys.setdefault(pc['server_public_key'], []).append(pc['id'])
                endpoints.setdefault(pc['endpoint'], []).append(pc['id'])
        for ids in endpoints.values():
            if len(ids) > 1:
                for pc_id in ids:
                    failures[pc_id] = 'independent PCs sharing a public IP need distinct external UDP ports'
        for ids in keys.values():
            if len(ids) > 1:
                for pc_id in ids:
                    failures[pc_id] = 'PCs must have independent WireGuard server keys'
        return failures

    def readiness(self, actor):
        return self.runtime.service_readiness()

    def inventory(self, actor):
        state, document, pcs = self._snapshot()
        conflicts = self._route_conflicts(pcs)
        items = []
        for pc in pcs:
            item = {key: pc[key] for key in ('id', 'name', 'dashboard_url', 'endpoint_family', 'ready', 'reason')}
            item['current'] = pc['id'] == state['hub_id']
            item['approved'] = True
            if pc['id'] in conflicts:
                item.update(ready=False, reason=conflicts[pc['id']])
            items.append(item)
        generations = []
        for generation, record in document['enrollments'].items():
            results = record.get('results', {})
            display_status = record['status']
            if (record.get('confirmed_members') and state['hub_id'] not in record['confirmed_members']
                    and not record.get('revocation_requested')):
                display_status = 'confirmed'
            elif record.get('revocation_requested'):
                display_status = ('revoked' if all(results.get(pc_id, {}).get('status') == 'revoked'
                                                   for pc_id in record.get('members', [])) else 'revocation_pending')
            elif display_status == 'revoked' and any(result.get('status') != 'revoked' for result in results.values()):
                display_status = 'revocation_pending'
            generations.append({'generation': generation, 'name': record['name'], 'device': record['device'],
                                'status': display_status, 'local_status': record['status'], 'results': results,
                                'can_verify': record['device'] == actor and record['status'] in ('prepared', 'confirmed')})
        return {'available': True, 'self_id': state['hub_id'], 'pcs': items, 'enrollments': generations,
                'max_pcs': MAX_PCS, 'refresh_required': True}

    def _public_enrollment(self, record):
        return {key: record[key] for key in ('generation', 'name', 'device', 'public_key', 'client_ip',
                                            'created_at', 'expires_at', 'members', 'replaces')}

    def _validate_enrollment(self, value):
        fields = {'generation', 'name', 'device', 'public_key', 'client_ip', 'created_at', 'expires_at', 'members', 'replaces'}
        if not isinstance(value, dict) or set(value) != fields:
            raise Error('invalid public enrollment fields')
        if (not isinstance(value['generation'], str) or not GENERATION.fullmatch(value['generation'])
                or not isinstance(value['name'], str) or not NAME.fullmatch(value['name'])
                or value['device'] != 'fleet_' + value['generation'][:24] or not _key(value['public_key'])):
            raise Error('invalid public device identity')
        if value['replaces'] and (not isinstance(value['replaces'], str) or not GENERATION.fullmatch(value['replaces'])):
            raise Error('invalid replacement generation')
        try:
            address = ipaddress.ip_address(value['client_ip'])
        except (ValueError, TypeError) as exc:
            raise Error('invalid common client address') from exc
        if address not in CLIENT_NETWORK or address in (CLIENT_NETWORK.network_address, CLIENT_NETWORK.broadcast_address):
            raise Error('fleet client address must use the reserved internal pool')
        if (not isinstance(value['members'], list) or not 1 <= len(value['members']) <= MAX_PCS
                or any(not _identifier(item) for item in value['members'])
                or len(set(value['members'])) != len(value['members'])):
            raise Error('invalid enrollment PC coverage')
        if (type(value['created_at']) is not int or type(value['expires_at']) is not int
                or not 0 < value['expires_at'] - value['created_at'] <= LIFETIME
                or value['created_at'] > int(self.now()) + 30):
            raise Error('invalid enrollment lifetime')

    def _local(self, request, expire=False):
        action = request.get('action')
        expected = {'action', 'enrollment', 'target'} if action == 'enroll' else {'action', 'generation', 'confirmed_members'} if action == 'confirm' else {'action', 'generation'}
        if not isinstance(request, dict) or set(request) != expected or action not in ('enroll', 'status', 'confirm', 'revoke'):
            raise Error('unsupported public enrollment operation')
        value = request.get('enrollment')
        generation = value.get('generation') if isinstance(value, dict) else request.get('generation')
        if not isinstance(generation, str) or not GENERATION.fullmatch(generation):
            raise Error('invalid enrollment generation')
        if action == 'enroll':
            self._validate_enrollment(value)
        with self.runtime.locked():
            runtime, state = self.runtime, self.runtime.load()
            document = self._load(state)
            record = document['enrollments'].get(generation)
            if expire and (not record or record['status'] not in ('prepared', 'revoking')
                           or record.get('expires_at', 0) > int(self.now())):
                return {'generation': generation, 'status': record['status'] if record else 'unknown',
                        'verified': bool(record and record.get('verified'))}
            if action == 'enroll':
                if state['hub_id'] not in value['members']:
                    raise Error('this PC is absent from the requested profile coverage')
                if record and record['status'] in ('revoking', 'revoked', 'expired'):
                    raise Error('retired generation cannot be enrolled again')
                if record and self._public_enrollment(record) != value:
                    raise Error('saved generation belongs to a different device identity')
                if int(self.now()) >= value['expires_at'] and (not record or record['status'] != 'confirmed'):
                    raise Error('enrollment expired; create an explicit replacement')
                own = self._public(state)
                if not own['ready']:
                    raise Error('this PC needs VPN network configuration')
                target = request['target']
                target_fields = {'id', 'dashboard_url', 'server_public_key', 'endpoint', 'endpoint_family'}
                if not isinstance(target, dict) or set(target) != target_fields:
                    raise Error('invalid enrollment target metadata')
                for key in ('id', 'dashboard_url', 'server_public_key'):
                    if target[key] != own[key]:
                        raise Error('approved PC registration changed; refresh its public roster record')
                selected_address, selected_port = _endpoint(target['endpoint'])
                family = 'ipv' + str(selected_address.version)
                configured = runtime._endpoints(state).get(family)
                if not configured or target['endpoint_family'] != family or selected_port != state['config']['udp_port']:
                    raise Error('approved VPN endpoint changed; refresh its public roster record')
                try:
                    configured_addresses = {str(ipaddress.ip_address(configured))}
                except ValueError:
                    af = socket.AF_INET if family == 'ipv4' else socket.AF_INET6
                    configured_addresses = {str(ipaddress.ip_address(item[4][0])) for item in
                                            socket.getaddrinfo(configured, selected_port, af, socket.SOCK_DGRAM)}
                if str(selected_address) not in configured_addresses:
                    raise Error('approved VPN endpoint changed; refresh its public roster record')
                for peer in state['peers'].values():
                    if (peer['ip'] == value['client_ip'] or peer['public_key'] == value['public_key']) and peer.get('generation') != generation:
                        raise Error('client address or public key already belongs to another enrollment')
                if not record:
                    if len(document['enrollments']) >= 4096:
                        raise Error('too many saved access generations')
                    record = {**value, 'status': 'prepared', 'verified': False, 'results': {}}
                    document['enrollments'][generation] = record
                device = value['device']
                credential = state['credentials'].get(device)
                if credential and credential.get('fleet_generation') != generation:
                    raise Error('device name already belongs to a different local identity')
                state['credentials'][device] = credential or {'hash': hashlib.sha256(secrets.token_bytes(32)).hexdigest(),
                                                            'role': 'operator', 'fleet_generation': generation}
                peer = {**state['peers'].get('fleet_' + generation, {}),
                        'device': device, 'public_key': value['public_key'], 'ip': value['client_ip'],
                        'profile': 'fleet', 'fleet': True, 'generation': generation, 'created_at': value['created_at'],
                        'endpoint': str(selected_address), 'endpoint_port': selected_port, 'endpoint_family': family,
                        'dashboard_routes': [_origin(self._public(state)['dashboard_url'], 'http').hostname + '/32']}
                state['peers']['fleet_' + generation] = peer
                runtime.guard(True)
                runtime._owned_link(state)
                # Persist intent before activating; retries repair interrupted activation.
                self._save(document)
                runtime._save(state)
                runtime._activate_peer(peer)
                runtime._credentials(state)
            elif not record:
                if action == 'revoke':
                    # A tombstone prevents a delayed enrollment on a PC that was
                    # unreachable during preparation. No private identity is needed.
                    document['enrollments'][generation] = {'generation': generation, 'status': 'revoked',
                        'name': 'revoked', 'device': 'fleet_' + generation[:24], 'members': [], 'results': {}}
                    self._save(document)
                    return {'generation': generation, 'status': 'revoked', 'verified': False}
                return {'generation': generation, 'status': 'unknown', 'verified': False}
            elif action == 'confirm':
                if record['status'] not in ('prepared', 'confirmed') or not record.get('verified'):
                    raise Error('canonical dashboard access has not been verified for this device')
                if record['status'] == 'prepared' and int(self.now()) >= record['expires_at']:
                    raise Error('provisional enrollment expired before confirmation')
                members = request['confirmed_members']
                if (not isinstance(members, list) or not members or len(members) > MAX_PCS
                        or any(not _identifier(item) for item in members) or len(set(members)) != len(members)
                        or set(members) - set(record['members']) or state['hub_id'] not in members):
                    raise Error('invalid confirmed profile coverage')
                if record.get('confirmed_members') and set(record['confirmed_members']) != set(members):
                    raise Error('confirmed profile coverage is immutable; create an explicit replacement')
                record['confirmed_members'] = members
                record['status'] = 'confirmed'
                self._save(document)
            elif action == 'revoke':
                # A confirmed member knows this retired profile had fleet-wide
                # coverage. Keep that intent visible on backup administrators
                # even when the original coordinator disappears mid-revocation.
                # An excluded provisional peer is only local cleanup and must
                # not claim revocation of the confirmed subset elsewhere.
                if record['status'] == 'confirmed' or state['hub_id'] in record.get('confirmed_members', []):
                    record['revocation_requested'] = True
                record['status'] = 'revoking'
                self._save(document)
                key = 'fleet_' + generation
                if key in state['peers']:
                    state['peers'][key]['revoking'] = True
                    runtime._save(state)
                    runtime._vpn_peers(state)
                    runtime._remove_peer(state, key)
                    runtime._save(state)
                credential = state['credentials'].get(record['device'])
                if credential and credential.get('fleet_generation') == generation:
                    del state['credentials'][record['device']]
                    runtime._save(state)
                    runtime._credentials(state)
                record['status'] = 'revoked'
                record.setdefault('results', {})[state['hub_id']] = {
                    'generation': generation, 'status': 'revoked', 'verified': bool(record.get('verified'))}
                self._save(document)
            return {'generation': generation, 'status': record['status'], 'verified': bool(record.get('verified'))}

    def peer(self, caller, pin, request):
        state, document, pcs = self._snapshot()
        approved = next((pc for pc in pcs if pc['id'] == caller and caller != state['hub_id']), None)
        if (not approved or not isinstance(pin, str)
                or not hmac.compare_digest(certificate_pin(approved['certificate']), pin)):
            raise Error('PC has not been explicitly approved for access administration')
        return self._local(request)

    def _coordinate(self, generation, action, members=None, confirmed_members=None, deadline=None):
        deadline = time.monotonic() + 24 if deadline is None else deadline
        state, document, pcs = self._snapshot()
        record = document['enrollments'].get(generation)
        if not record or not record.get('members'):
            raise Error('unknown enrollment coverage')
        roster = {pc['id']: pc for pc in pcs}
        enrollment_targets = {}
        if action == 'enroll':
            with self.session_lock:
                temporary = next((value for value in self.sessions.values() if value['generation'] == generation), None)
                if not temporary:
                    raise Error('enrollment material is unavailable; create an explicit replacement')
                enrollment_targets = {pc['id']: pc for pc in temporary['pcs']}
        request = {'action': action, 'enrollment': self._public_enrollment(record)} if action == 'enroll' else {'action': action, 'generation': generation}
        if action == 'confirm':
            request['confirmed_members'] = confirmed_members
        members = record['members'] if members is None else members
        def one(pc_id):
            # A durable acknowledgment survives a coordinator restart and later
            # loss of connectivity or approval. Never turn completed cleanup
            # back into pending merely because that PC is now offline.
            previous = record.get('results', {}).get(pc_id, {})
            if action == 'revoke' and previous.get('status') == 'revoked':
                return pc_id, previous
            pc = roster.get(pc_id)
            if pc is None:
                return pc_id, {'status': 'pending', 'reason': 'PC is not currently approved'}
            if time.monotonic() >= deadline:
                return pc_id, {'status': 'pending', 'reason': 'PC did not acknowledge before the operation deadline'}
            try:
                outbound = request
                if action == 'enroll':
                    target = enrollment_targets.get(pc_id)
                    if not target or certificate_pin(target['certificate']) != certificate_pin(pc['certificate']):
                        raise Error('approved PC identity changed during this enrollment')
                    outbound = {**request, 'target': {key: target[key] for key in
                                ('id', 'dashboard_url', 'server_public_key', 'endpoint', 'endpoint_family')}}
                result = self._local(outbound) if pc_id == state['hub_id'] else self.transport(pc, outbound)
                if (not isinstance(result, dict) or result.get('generation') != generation
                        or result.get('status') not in ('prepared', 'confirmed', 'revoking', 'revoked', 'expired', 'unknown')
                        or type(result.get('verified')) is not bool):
                    raise Error('invalid PC acknowledgment')
                return pc_id, result
            except Exception:
                # Network errors can contain credentials or input bytes; publish
                # a fixed failure message, retaining this PC as pending.
                return pc_id, {'status': 'pending', 'reason': 'PC did not acknowledge; retry when available'}
        # Bound the whole fleet operation, not just each connection. A fleet with
        # 1,024 unreachable PCs must still return a truthful partial result.
        if not members:
            return {}
        pool = ThreadPoolExecutor(max_workers=min(16, len(members)))
        pending = {pool.submit(one, pc_id): pc_id for pc_id in members}
        done, _ = wait(pending, timeout=max(0, deadline - time.monotonic()))
        results = {pending[future]: {'status': 'pending', 'reason': 'PC did not acknowledge; retry when available'}
                   for future in pending}
        for future in done:
            pc_id, result = future.result()
            results[pc_id] = result
        pool.shutdown(wait=False, cancel_futures=True)
        with self.runtime.locked():
            state = self.runtime.load()
            document = self._load(state)
            current = document['enrollments'][generation]
            saved_results = current.setdefault('results', {})
            if not current.get('revocation_requested') or action == 'revoke':
                for pc_id, result in results.items():
                    if action == 'revoke' and saved_results.get(pc_id, {}).get('status') == 'revoked':
                        results[pc_id] = saved_results[pc_id]
                    else:
                        saved_results[pc_id] = result
            self._save(document)
        return results

    def _session(self, session, actor):
        if not isinstance(session, str):
            raise Error('temporary enrollment session is required')
        with self.session_lock:
            value = self.sessions.get(session)
            if not value or value['actor'] != actor and value['device'] != actor:
                raise Error('unknown enrollment session for this browser identity')
            if int(self.now()) >= value['expires_at']:
                self.sessions.pop(session, None)
                raise Error('private profile expired; cancel or create an explicit replacement')
            return value

    def prepare(self, actor, name, replaces=''):
        if not isinstance(name, str) or not NAME.fullmatch(name):
            raise Error('choose a device name using at most 48 letters, numbers, dashes or underscores')
        state, document, pcs = self._snapshot()
        previous = document['enrollments'].get(replaces, {}) if isinstance(replaces, str) else {}
        previous_confirmed = (previous.get('status') == 'confirmed' or
                              previous.get('confirmed_members') and state['hub_id'] not in previous['confirmed_members']
                              and not previous.get('revocation_requested'))
        if replaces and (not isinstance(replaces, str) or not GENERATION.fullmatch(replaces) or not previous_confirmed):
            raise Error('choose a confirmed enrollment to replace explicitly')
        conflicts = self._route_conflicts(pcs)
        included = [pc for pc in pcs if pc['ready'] and pc['id'] not in conflicts]
        if not included:
            raise Error('no approved PC has a prepared conflict-free VPN route')
        with self.session_lock:
            self.sessions = {key: value for key, value in self.sessions.items() if value['expires_at'] > int(self.now())}
            if len(self.sessions) >= MAX_SESSIONS:
                raise Error('too many temporary profiles; cancel one or wait for expiry')
            private = self.runtime.runner.run(['/usr/bin/wg', 'genkey']).stdout.strip()
            public = self.runtime.runner.run(['/usr/bin/wg', 'pubkey'], input=private).stdout.strip()
            if not _key(private) or not _key(public):
                raise Error('WireGuard could not generate a valid client identity')
            generation = secrets.token_hex(16)
            used = {peer['ip'] for peer in state['peers'].values()}
            candidates = (str(CLIENT_NETWORK.network_address + secrets.randbelow(CLIENT_NETWORK.num_addresses - 2) + 1)
                          for _ in range(64))
            address = next((candidate for candidate in candidates if candidate not in used), None)
            if not address or address in used:
                raise Error('could not reserve a unique common client address; retry preparation')
            now = int(self.now())
            record = {'generation': generation, 'name': name, 'device': 'fleet_' + generation[:24],
                      'public_key': public, 'client_ip': address, 'created_at': now, 'expires_at': now + LIFETIME,
                      'members': [pc['id'] for pc in included], 'replaces': replaces,
                      'status': 'prepared', 'verified': False, 'results': {}}
            token = secrets.token_urlsafe(32)
            self.sessions[token] = {'actor': actor, 'private': private, 'generation': generation,
                                    'device': record['device'], 'expires_at': now + LIFETIME,
                                    'pcs': pcs, 'conflicts': conflicts}
        with self.runtime.locked():
            current = self.runtime.load()
            document = self._load(current)
            if len(document['enrollments']) >= 4096:
                self.sessions.pop(token, None)
                raise Error('too many saved access generations')
            document['enrollments'][generation] = record
            self._save(document)
        self._coordinate(generation, 'enroll')
        return self.status(actor, token, retry=False)

    def status(self, actor, session=None, retry=True):
        if not session:
            return self.inventory(actor)
        temporary = self._session(session, actor)
        generation = temporary['generation']
        if retry:
            _, before, _ = self._snapshot()
            record = before['enrollments'][generation]
            if record.get('revocation_requested') or (record['status'] in ('revoked', 'revoking', 'expired')
                                                     and not record.get('confirmed_members')):
                raise Error('this enrollment was cancelled or expired')
            if record.get('confirmed_members'):
                self._coordinate(generation, 'status', members=record['confirmed_members'])
            else:
                self._coordinate(generation, 'enroll')
        state, document, _ = self._snapshot()
        record = document['enrollments'][generation]
        included, excluded = [], []
        for pc in temporary['pcs']:
            result = record['results'].get(pc['id'], {})
            public = {key: pc[key] for key in ('id', 'name', 'dashboard_url')}
            if result.get('status') in ('prepared', 'confirmed'):
                included.append(public)
            else:
                excluded.append({**public, 'reason': temporary['conflicts'].get(pc['id']) or pc['reason']
                                 or result.get('reason') or result.get('status') or 'not enrolled'})
        included.sort(key=lambda pc: (pc['id'] != state['hub_id'], pc['name'], pc['id']))
        status = 'confirmed' if record.get('confirmed_members') and not record.get('revocation_requested') else record['status']
        return {'self_id': state['hub_id'], 'session': session, 'generation': generation, 'device': record['device'], 'name': record['name'],
                'public_key': record['public_key'], 'client_ip': record['client_ip'], 'expires_at': record['expires_at'],
                'included': included, 'excluded': excluded, 'results': record['results'], 'status': status,
                'replaces': record['replaces'], 'complete': len(included) == len(temporary['pcs'])}

    def export(self, actor, session, pcs=None):
        temporary = self._session(session, actor)
        status = self.status(actor, session)
        selected = status['included']
        if pcs is not None:
            if (not isinstance(pcs, list) or not pcs or len(pcs) > MAX_PCS or any(not _identifier(item) for item in pcs)
                    or len(set(pcs)) != len(pcs) or set(pcs) - {pc['id'] for pc in selected}):
                raise Error('profile subset must contain successfully enrolled PCs only')
            selected = [pc for pc in selected if pc['id'] in pcs]
        if not selected:
            raise Error('no PC has acknowledged this enrollment')
        by_id = {pc['id']: pc for pc in temporary['pcs']}
        parts = ['[Interface]\nPrivateKey = ' + temporary['private'] + '\nAddress = ' + status['client_ip'] + '/32\n']
        for item in selected:
            pc = by_id[item['id']]
            parts.append('[Peer]\nPublicKey = ' + pc['server_public_key'] + '\nEndpoint = ' + pc['endpoint']
                         + '\nAllowedIPs = ' + _origin(pc['dashboard_url'], 'http').hostname + '/32\n')
        excluded = status['excluded'] + [{**pc, 'reason': 'not selected for this export'}
                                         for pc in status['included'] if pc not in selected]
        return {**status, 'config': '\n'.join(parts), 'included': selected, 'excluded': excluded,
                'complete': not excluded, 'filename': 'gridlens-' + status['name'] + '-' + status['generation'][:8] + '.conf'}

    def verify(self, actor, tunnel_ip, generation):
        if not isinstance(generation, str) or not GENERATION.fullmatch(generation):
            raise Error('invalid enrollment generation')
        with self.runtime.locked():
            state = self.runtime.load()
            document = self._load(state)
            record = document['enrollments'].get(generation)
            peer = state['peers'].get('fleet_' + generation)
            if (not record or not peer or record['status'] not in ('prepared', 'confirmed')
                    or peer.get('revoking') or actor != record['device'] or tunnel_ip != record['client_ip']
                    or peer['public_key'] != record['public_key']):
                raise Error('verification must arrive through this replacement device\'s authenticated VPN identity')
            if record['status'] == 'prepared' and int(self.now()) >= record['expires_at']:
                raise Error('provisional enrollment expired before verification')
            evidence = self.runtime._peer_evidence(state, peer)
            if (not record['created_at'] <= evidence['handshake'] <= int(self.now())
                    or evidence['rx'] <= 0 or evidence['tx'] <= 0):
                raise Error('this device has no fresh WireGuard handshake and traffic evidence')
            record['verified'] = True
            record['verified_at'] = int(self.now())
            peer['last_test'] = {'verified': True, 'canonical_url': self.runtime._dashboard(state),
                                 'tested_at': int(self.now()), 'endpoint_family': evidence.get('endpoint_family', 'unknown'),
                                 'endpoint': peer.get('endpoint', ''), 'endpoint_port': peer.get('endpoint_port'),
                                 'endpoint_family_scope': 'server-observed', 'mobile_data_user_confirmed': False,
                                 'remote_verified': False}
            self.runtime._save(state)
            self._save(document)
            return {'generation': generation, 'status': record['status'], 'verified': True}

    def confirm(self, actor, session, pcs=None):
        deadline = time.monotonic() + 24
        temporary = self._session(session, actor)
        generation = temporary['generation']
        results = self._coordinate(generation, 'status', deadline=deadline)
        eligible = {pc_id for pc_id, result in results.items() if result.get('status') in ('prepared', 'confirmed')}
        if pcs is None:
            pcs = sorted(eligible)
        if (not isinstance(pcs, list) or not pcs or len(pcs) > MAX_PCS or any(not _identifier(item) for item in pcs)
                or len(set(pcs)) != len(pcs) or set(pcs) - eligible):
            raise Error('confirmation must identify successfully enrolled PCs in the imported profile')
        if any(not results[pc_id].get('verified') for pc_id in pcs):
            raise Error('verify this replacement on every included PC before retiring the previous profile')
        state, document, _ = self._snapshot()
        results = self._coordinate(generation, 'confirm', members=pcs, confirmed_members=pcs, deadline=deadline)
        complete = all(result.get('status') == 'confirmed' for result in results.values())
        if complete:
            with self.runtime.locked():
                current = self.runtime.load()
                saved = self._load(current)
                saved['enrollments'][generation]['confirmed_members'] = pcs
                self._save(saved)
        replaces = document['enrollments'][generation]['replaces']
        retirement = None
        omitted = [pc_id for pc_id in document['enrollments'][generation]['members'] if pc_id not in pcs]
        exclusions = self._coordinate(generation, 'revoke', members=omitted, deadline=deadline) if complete else {}
        previous = document['enrollments'].get(replaces, {})
        previous_coverage = set(previous.get('confirmed_members', previous.get('members', [])))
        if complete and replaces and previous_coverage.issubset(pcs):
            retirement = self.revoke(actor, replaces, deadline=deadline)
        result = self.status(actor, session, retry=False)
        result.update(confirmed=complete, confirmed_pcs=pcs, exclusions=exclusions,
                      previous_generation=retirement, previous_preserved=bool(replaces and retirement is None))
        # Keep the same temporary material until its deadline so confirmation does
        # not silently generate another identity when the user downloads again.
        return result

    def revoke(self, actor, generation, deadline=None):
        if not isinstance(generation, str) or not GENERATION.fullmatch(generation):
            raise Error('invalid enrollment generation')
        with self.runtime.locked():
            state = self.runtime.load()
            document = self._load(state)
            record = document['enrollments'].get(generation)
            if not record or not record.get('members'):
                raise Error('unknown enrollment coverage')
            record['revocation_requested'] = True
            self._save(document)
        results = self._coordinate(generation, 'revoke', deadline=deadline)
        with self.session_lock:
            self.sessions = {key: value for key, value in self.sessions.items() if value['generation'] != generation}
        complete = all(result.get('status') == 'revoked' for result in results.values())
        return {'generation': generation, 'status': 'revoked' if complete else 'revocation_pending',
                'complete': complete, 'results': results}

    def cancel(self, actor, session):
        temporary = self._session(session, actor)
        _, document, _ = self._snapshot()
        record = document['enrollments'][temporary['generation']]
        if record['status'] == 'confirmed' or record.get('confirmed_members'):
            raise Error('confirmed profiles require explicit revocation')
        return self.revoke(actor, temporary['generation'])

    def reap(self):
        """Every PC retires its own expired provisional identity after restarts.

        Confirmed generations survive indefinitely. No key is reconstructed, and
        a durable tombstone rejects a late request from an offline coordinator.
        """
        with self.session_lock:
            self.sessions = {key: value for key, value in self.sessions.items() if value['expires_at'] > int(self.now())}
        with self.runtime.locked():
            state = self.runtime.load()
            document = self._load(state)
            expired = [generation for generation, record in document['enrollments'].items()
                       if record['status'] in ('prepared', 'revoking') and record.get('expires_at', 0) <= int(self.now())]
        for generation in expired:
            try:
                self._local({'action': 'revoke', 'generation': generation}, expire=True)
            except Exception:
                # Persisted revoking state and the public peer map fail closed;
                # the periodic sweep retries interrupted kernel cleanup.
                continue

    def dispatch(self, body):
        if not isinstance(body, dict) or not isinstance(body.get('op'), str):
            raise Error('invalid container access operation')
        op = body['op']
        fields = {'readiness': {'actor'}, 'inventory': {'actor'}, 'prepare': {'actor', 'name', 'replaces'}, 'status': {'actor', 'session'},
                  'export': {'actor', 'session', 'pcs'}, 'confirm': {'actor', 'session', 'pcs'}, 'cancel': {'actor', 'session'},
                  'revoke': {'actor', 'generation'}, 'verify': {'actor', 'tunnel_ip', 'generation'},
                  'peer': {'caller', 'certificate_sha256', 'request'}}
        if op not in fields or set(body) - (fields[op] | {'op'}):
            raise Error('unsupported container access operation or fields')
        if op != 'peer' and (not isinstance(body.get('actor'), str) or not NAME.fullmatch(body['actor'])):
            raise Error('authenticated browser identity is required')
        arguments = {key: value for key, value in body.items() if key != 'op'}
        if op == 'peer':
            return self.peer(arguments.get('caller'), arguments.get('certificate_sha256'), arguments.get('request'))
        return getattr(self, op)(**arguments)


class ControlServer(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True
    block_on_close = False
    request_queue_size = 16

    def __init__(self, path, controller, allowed_uids):
        self.controller = controller
        self.allowed_uids = set(allowed_uids)
        self.slots = threading.BoundedSemaphore(16)
        super().__init__(str(path), ControlHandler)

    def process_request(self, request, client_address):
        if not self.slots.acquire(blocking=False):
            request.close()
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self.slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()

    def handle_error(self, request, client_address):
        # socketserver otherwise emits tracebacks that could contain secret input.
        pass

    def service_actions(self):
        if time.monotonic() >= getattr(self, '_next_reap', 0):
            self._next_reap = time.monotonic() + 5
            try:
                self.controller.reap()
            except Exception:
                pass


class ControlHandler(socketserver.StreamRequestHandler):
    def handle(self):
        self.connection.settimeout(10)
        try:
            _, uid, _ = struct.unpack('3i', self.connection.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
            if uid not in self.server.allowed_uids:
                raise Error('container access caller is not authorized')
            raw = self.rfile.readline(MAX_REQUEST + 1)
            if len(raw) > MAX_REQUEST or not raw.endswith(b'\n'):
                raise Error('container access request exceeds its limit')
            result = self.server.controller.dispatch(json.loads(raw, object_pairs_hook=_unique_object))
            response = {'ok': True, 'result': result}
        except Error as exc:
            response = {'ok': False, 'error': str(exc)}
        except Exception:
            response = {'ok': False, 'error': 'container access operation could not complete'}
        self.wfile.write(json.dumps(response, separators=(',', ':')).encode() + b'\n')


def installer_request(runtime, operation, arguments=None):
    """Use the running controller so terminal and browser share session state.

    The installer has container-root authority, but this bridge deliberately
    cannot manufacture canonical VPN verification or submit machine requests.
    """
    fields = {'readiness': set(), 'inventory': set(), 'prepare': {'name', 'replaces'}, 'status': {'session'},
              'export': {'session', 'pcs'}, 'confirm': {'session', 'pcs'},
              'cancel': {'session'}, 'revoke': {'generation'}}
    arguments = {} if arguments is None else arguments
    if operation not in fields or not isinstance(arguments, dict) or set(arguments) - fields[operation]:
        raise Error('unsupported installer access operation or fields')
    runtime.guard(False)
    directory = runtime.run_dir.parent / 'gridlens-access'
    runtime._safe(directory, directory=True)
    runtime._safe(directory / '.owner')
    with runtime.locked():
        state = runtime.load()
        if (directory / '.owner').read_text() != state['owner']:
            raise Error('access socket belongs to another installation')
    path = directory / 'control.sock'
    info = path.lstat()
    if not stat.S_ISSOCK(info.st_mode) or info.st_uid != runtime.owner_uid:
        raise Error('access socket ownership changed')
    body = {'op': operation, 'actor': 'installer', **arguments}
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.settimeout(2 if operation == 'readiness' else 35)
        client.connect(str(path))
        client.sendall(json.dumps(body, separators=(',', ':')).encode() + b'\n')
        with client.makefile('rb') as stream:
            raw = stream.readline(MAX_REQUEST + 1)
    if len(raw) > MAX_REQUEST or not raw.endswith(b'\n'):
        raise Error('invalid access controller response')
    response = json.loads(raw, object_pairs_hook=_unique_object)
    if not isinstance(response, dict) or response.get('ok') is not True or not isinstance(response.get('result'), dict):
        reason = response.get('error') if isinstance(response, dict) else None
        if isinstance(reason, str) and len(reason) <= 512 and all(ord(char) >= 32 and ord(char) != 127 for char in reason):
            raise Error(reason)
        raise Error('access controller did not complete this operation; refresh its status before retrying')
    return response['result']


class RunningServer:
    def __init__(self, server, path):
        self.server, self.path = server, path
        self.thread = threading.Thread(target=server.serve_forever, daemon=True, name='gridlens-access')
        self.thread.start()

    def stop(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        if self.path.exists():
            self.path.unlink()
        with self.server.controller.session_lock:
            self.server.controller.sessions.clear()


def start_server(runtime):
    runtime.guard(False)
    controller = AccessController(runtime)
    controller.reap()
    with runtime.locked():
        state = runtime.load()
        document = controller._load(state)
        if state['config'].get('advertise_host') and state['config'].get('management_available', True):
            controller._publish_roster(state, document)
        # The parent is root-owned: the hub cannot substitute this socket or its
        # directory. Other runtime receipts retain their existing separate paths.
        directory = runtime.run_dir.parent / 'gridlens-access'
        if directory.exists() or directory.is_symlink():
            runtime._safe(directory, directory=True)
            runtime._safe(directory / '.owner')
            if (directory / '.owner').read_text() != state['owner']:
                raise Error('access socket directory belongs to another installation')
        else:
            runtime._directory(directory, 0o750, gid=10001)
            runtime._write(directory / '.owner', state['owner'])
        path = directory / 'control.sock'
        if path.exists() or path.is_symlink():
            info = path.lstat()
            if not stat.S_ISSOCK(info.st_mode) or info.st_uid != runtime.owner_uid:
                raise Error('refusing an unowned access control socket')
            path.unlink()
        server = ControlServer(path, controller, {runtime.owner_uid, 10001})
        path.chmod(0o660)
        if os.geteuid() == 0:
            os.chown(path, 0, 10001)
    return RunningServer(server, path)
