"""Terminal instructions for the Docker installation, with no host operations.

The caller supplies its already-open controlling terminal, an owned-container
controller, and a local QR renderer. Nothing in this module reads stdin, invokes
commands, stores credentials, or opens a browser/network connection.
"""

import ipaddress
import os
import re


CLIENTS = {
    "1": ("Android phone", "my-android", "https://play.google.com/store/apps/details?id=com.wireguard.android"),
    "2": ("iPhone or iPad", "my-iphone", "https://apps.apple.com/us/app/wireguard/id1441195209"),
    "3": ("Windows computer", "my-windows", "https://www.wireguard.com/install/"),
    "4": ("Mac", "my-mac", "https://apps.apple.com/us/app/wireguard/id1451685025"),
    "5": ("Linux computer", "my-linux", "https://www.wireguard.com/install/"),
}


class OnboardingError(Exception):
    pass


class Cancelled(Exception):
    pass


def _text(value, maximum=512):
    if not isinstance(value, str) or not value or len(value) > maximum or any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise OnboardingError("The container returned invalid display text.")
    return value


def _endpoint(value):
    value = value.strip()
    try:
        address = ipaddress.ip_address(value)
        if address.is_unspecified or address.is_multicast or address.is_loopback:
            raise OnboardingError("Use this PC's reachable address, not a loopback or wildcard address.")
        return str(address)
    except ValueError:
        if len(value) > 253 or not value or any(not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?", label)
                                               for label in value.rstrip(".").split(".")):
            raise OnboardingError("Enter an IP address or hostname, without http://, a path, or a port.")
        return value


class Conversation:
    def __init__(self, tty, qr):
        self.tty = tty
        self.qr = qr
        self.color = (getattr(tty, "isatty", lambda: False)()
                      and os.environ.get("TERM", "dumb") not in ("", "dumb")
                      and "NO_COLOR" not in os.environ)
        self.help = None

    def _style(self, text, code="1;36"):
        text = _text(text)
        return "\033[" + code + "m" + text + "\033[0m" if self.color else text

    def heading(self, text):
        title = self._style(text)
        self.say()
        self.say(title)
        self.say()

    def key(self, label, value):
        self.say(self._style(label + ":", "1") + " " + _text(str(value)))

    def say(self, text=""):
        self.tty.write(text + "\n")
        self.tty.flush()

    def ask(self, label, default=None):
        label = _text(label)
        if default is not None and str(default):
            _text(str(default))
        self.tty.write("\n" + self._style(label, "1") + (" [" + str(default) + "]" if default is not None else "") + ": ")
        self.tty.flush()
        answer = self.tty.readline(513)
        if answer == "":
            raise Cancelled()
        if len(answer) > 512 or not answer.endswith("\n"):
            raise OnboardingError("That answer was too long. Restart setup and enter a short answer.")
        answer = answer.rstrip("\r\n").strip()
        if any(ord(char) < 32 or ord(char) == 127 for char in answer):
            raise OnboardingError("Use ordinary text for this answer.")
        if answer.lower() in ("quit", "cancel"):
            raise Cancelled()
        if answer.lower() == "help" and self.help:
            self.help()
            return self.ask(label, default)
        return answer or (str(default) if default is not None else "")

    def yes(self, label, default=True):
        while True:
            answer = self.ask(label + " (yes/no)", "yes" if default else "no").lower()
            if answer in ("yes", "y"):
                return True
            if answer in ("no", "n"):
                return False
            self.say("Type yes or no. Type cancel to stop.")

    def choice(self, label, choices, default):
        self.heading(label)
        for key, text in choices:
            self.say("  " + key + ". " + text)
        allowed = {key for key, _ in choices}
        while True:
            answer = self.ask("Choose a number", default)
            if answer in allowed:
                return answer
            self.say("Choose one of the numbers above.")

    def image(self, value, kind):
        try:
            rendered = self.qr(value, kind)
            if rendered is not None:
                if not isinstance(rendered, str):
                    raise OnboardingError("The QR renderer must return terminal text.")
                self.say(rendered)
            return True
        except Exception:
            self.say("The QR code could not be shown. Widen this terminal, or use the text instructions below.")
            return False


def _network_guidance(chat, environment, endpoints, bindings, port):
    """Keep the required router rule visible; expand troubleshooting on demand."""
    chat.heading("Router setup" if environment == "home" else "Network administrator request")
    if environment == "home":
        if "ipv4" in endpoints:
            chat.key("Forward UDP", str(port) + " → " + bindings["ipv4"] + ":" + str(port))
            chat.say("Port Forwarding / Virtual Server: External Port " + str(port)
                     + "; Internal IP " + bindings["ipv4"] + "; Internal Port " + str(port) + ".")
            chat.say("Use a DHCP Reservation to keep this PC's private address unchanged.")
        else:
            chat.say("IPv4 backup is not configured. It needs inbound public IPv4 and a UDP forwarding rule.")
        if "ipv6" in endpoints:
            chat.say("IPv6 Firewall / Inbound Rule: allow UDP " + str(port) + " to " + bindings["ipv6"] + ".")
    else:
        chat.say("Copy this to your network administrator; firewall-administrator rights are not required:")
        for family, endpoint in endpoints.items():
            advertised = "[" + endpoint + "]" if family == "ipv6" else endpoint
            chat.say("  Please permit inbound " + family.upper() + " UDP " + str(port) + " to " + bindings[family]
                     + ", advertised endpoint " + advertised + ":" + str(port)
                     + ", for GridLens WireGuard VPN-only access. Apply DNAT/VIP only if this destination requires it.")
        if "ipv4" not in endpoints:
            chat.say("  Please advise whether inbound public IPv4 is available for a backup.")
    chat.say("Only open this VPN UDP port. Keep dashboard/SSH ports private and the firewall enabled.")
    chat.say("Make this change in your router/provider settings. Type help at a prompt for troubleshooting.")

    def details():
        chat.heading("Network help")
        if environment == "home":
            chat.say("WAN/Internet IP must match your public IPv4 endpoint or its DNS record.")
            chat.say("IPv4 forwarding targets this PC's private address, not the phone or tunnel address.")
            chat.say("A private WAN/Internet IP (10/8, 172.16/12, 192.168/16) or 100.64/10 means upstream NAT/CGNAT.")
            chat.say("Ask your ISP for inbound public IPv4, or forward UDP through each router you control.")
            chat.say("If you cannot administer the router, ask its administrator; a QR code cannot bypass filtering.")
            chat.say("IPv6 Firewall / Inbound Rule permission targets this PC's global IPv6 address.")
        else:
            chat.say("Routed public addresses need an ACL/Security Policy or Security Group permitting the VPN UDP port.")
            chat.say("With DNAT or a Virtual IP/VIP, the provider maps the public endpoint to this PC.")
        chat.say("GridLens does not edit router settings or require a hosted relay or subscription.")
    chat.help = details


def _network_options(driver, chat, status, remote, environment):
    inventory = status.get("addressInventory", {})
    private = status.get("suggestedAddress")
    ipv4 = status.get("suggestedIPv4") or next(iter(inventory.get("ipv4", [])), None)
    ipv6 = status.get("suggestedIPv6") or next(iter(inventory.get("ipv6", [])), None)
    private_ipv4 = private if private and ipaddress.ip_address(private).version == 4 else None
    ipv4_bind = private_ipv4 or ipv4
    if ipv4 and not ipaddress.ip_address(ipv4).is_global:
        ipv4 = next((value for value in inventory.get("ipv4", []) if ipaddress.ip_address(value).is_global), None)
    if ipv6:
        chat.say("IPv6 address found: " + _text(ipv6) + ". A phone connection has not been verified.")
    else:
        chat.say("No stable global IPv6 address was found. IPv6 cannot be offered on this PC yet.")
    if inventory.get("ipv6Temporary"):
        chat.say("Temporary IPv6 addresses were excluded because saved profiles need a stable endpoint.")
    public_suggestion = None
    if remote and ipv4_bind and not ipv4:
        chat.say("Checking this PC's public IPv4 address with api.ipify.org...")
        public_suggestion = driver.public_ipv4_suggestion()
        if not public_suggestion:
            chat.say("The public IPv4 lookup did not succeed. You can still enter your router's WAN/Internet address or an administrator-provided address.")
    endpoints, bindings = {}, {}
    while not endpoints:
        if ipv4_bind:
            if remote and environment == "home":
                chat.say("Your phone uses your home's Internet address to find GridLens when you are away.")
                address_label = "Home Public Internet IPv4 address (or hostname)"
            elif remote:
                chat.say("Use the public IPv4 address or hostname provided by your network administrator.")
                address_label = "Public IPv4 address from your administrator (or hostname)"
            else:
                chat.say("Your dashboard already uses " + _text(private) + ". A VPN endpoint must use a different address so its dashboard route cannot capture the VPN transport.")
                chat.say("Type existing to use your current private network without a new VPN, or enter a distinct reachable endpoint.")
                address_label = "Distinct VPN endpoint address, or existing"
            address_default = (ipv4 or public_suggestion) if remote else None
            if remote and public_suggestion:
                chat.say("Your public Internet IPv4 address may be " + public_suggestion + ".")
                chat.say("A VPN or upstream NAT can change this suggestion; check your router's WAN/Internet IP if unsure.")
            elif address_default:
                chat.say("Press Enter to use the detected address: " + address_default + ".")
            elif ipv6:
                chat.say("No public IPv4 address was detected on this PC. Press Enter or type none to use the IPv6 option below.")
                address_default = "none"
            else:
                chat.say("Enter the public IPv4 address shown by your router or network administrator. If you need to check it first, type cancel and return when ready.")
            while True:
                candidate = chat.ask(address_label, address_default)
                if not remote and candidate.lower() == "existing":
                    return {"wireguard": False}
                if candidate.lower() == "none":
                    break
                try:
                    value = _endpoint(candidate)
                    try:
                        address = ipaddress.ip_address(value)
                        if address.version != 4:
                            raise OnboardingError("Enter an IPv4 address here; IPv6 is offered separately when assigned to this PC.")
                        if remote and not address.is_global:
                            raise OnboardingError("That WAN/Internet IP is private, shared (CGNAT), or otherwise not public. Upstream NAT needs a public endpoint and forwarding; ask your ISP or administrator, or type none to use IPv6.")
                        if str(address) == private:
                            raise OnboardingError("That VPN endpoint conflicts with this PC's dashboard route. Use a distinct endpoint, or type existing for local-only access.")
                    except ValueError:
                        if remote and (value.lower() == "localhost" or value.lower().endswith(".local")):
                            raise OnboardingError("That hostname is local. Enter a public IPv4 hostname or type none.")
                    endpoints["ipv4"], bindings["ipv4"] = value, ipv4_bind
                    break
                except OnboardingError as error:
                    chat.say(str(error))
        if ipv6:
            chat.say("IPv6 uses this PC's global address directly; the router/provider must permit incoming UDP.")
            if chat.yes("Keep IPv6 as an available endpoint using " + ipv6):
                endpoints["ipv6"], bindings["ipv6"] = ipv6, ipv6
        if not endpoints:
            if not ipv4_bind and not ipv6:
                raise OnboardingError("No usable VPN publication address was found. Configure a host network address outside GridLens, then rerun setup.")
            chat.say("Remote access cannot work until an endpoint is available. Ask your ISP or administrator for inbound access.")
            chat.say("Choose at least one endpoint, or type cancel to stop without creating an installation.")
    chat.say("Keep the suggested VPN port unless your network administrator supplied another.")
    while True:
        value = chat.ask("UDP port for this GridLens connection", status.get("suggestedUdpPort", 51871))
        if value.isdigit() and 1024 <= int(value) <= 65535:
            break
        chat.say("Choose a port number from 1024 to 65535.")
    port = int(value)
    if remote:
        _network_guidance(chat, environment, endpoints, bindings, port)
    else:
        chat.say("Local-only monitoring uses your private network. This does not establish remote access.")
    return {"endpoint": endpoints.get("ipv4", endpoints.get("ipv6")), "endpoints": endpoints,
            "vpnBindings": bindings, "udpPort": port}


def _first_install(driver, chat, status):
    chat.heading("1. Set up this PC")
    chat.say("GridLens runs in Docker and keeps its settings when you rerun setup.")
    chat.say("This name labels the PC in GridLens; it does not rename your computer.")
    chat.say("Press Enter to keep the suggested defaults. Type cancel to stop.")
    while True:
        name = chat.ask("Name for this PC in GridLens", status.get("suggestedName", "my-nosana-pc"))
        if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}", name):
            break
        chat.say("Use a short name with letters, numbers, dots or dashes.")
    use = chat.choice("How will you use GridLens?", (("1", "Remote access from mobile data or other networks"),
                      ("2", "Local-only monitoring on a private network")), "1")
    network = chat.choice("Who provides this PC's network?", (("1", "Home/small office"),
                          ("2", "Data center/managed network")), "1")
    remote, environment = use == "1", "home" if network == "1" else "managed"
    chat.say("WireGuard creates a private dashboard connection. " +
             ("Choose yes if you need a connection or are unsure." if remote else "No uses your existing private network; choose yes for a new VPN."))
    chat.say("Choose no to skip VPN setup if your device already reaches this PC through a VPN or home Wi-Fi.")
    wireguard = chat.yes("Set up a private WireGuard connection for your phone", default=remote)
    options = {"name": name, "wireguard": wireguard,
               "intendedUse": "remote" if remote else "local", "networkEnvironment": environment}
    legacy = status.get("legacyDetected") is True
    if not status.get("suggestedAddress"):
        raise OnboardingError("Assign this PC a private dashboard address before installation. GridLens cannot invent an alternate dashboard URL.")
    if wireguard:
        chat.heading("2. Connect from outside your home" if remote and environment == "home" else "2. Connection settings")
        options.update(_network_options(driver, chat, status, remote, environment))
        wireguard = options["wireguard"]
    else:
        chat.say("Without a new VPN, remote access requires a private VPN you already have.")
    if legacy:
        wrappers = []
        chat.say("Existing monitoring stays running. GridLens copies its fleet settings into Docker.")
    else:
        chat.say()
        chat.say("Some Nosana installers put their workers inside a Docker container, often named podman.")
        chat.say("Enter those outer container names only if your installer uses them. Leave this empty for normal Docker workers.")
        suggested = status.get("suggestedWrappers", [])
        if not isinstance(suggested, list) or any(not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", value)
                                                  for value in suggested):
            raise OnboardingError("The controller returned invalid wrapper suggestions.")
        while True:
            answer = chat.ask("Approved outer container names, separated by commas; type none for no nested checks", ", ".join(suggested))
            wrappers = [] if answer.lower() == "none" else [value.strip() for value in answer.split(",") if value.strip()]
            if len(wrappers) <= 15 and len(set(wrappers)) == len(wrappers) and all(
                    re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,127}", value) for value in wrappers):
                break
            chat.say("Use up to fifteen distinct container names, with letters, numbers, dots, underscores or dashes.")
    options["wrappers"] = wrappers
    chat.heading("3. Ready to install")
    chat.say("  PC name: " + name)
    if legacy:
        chat.say("  Create one GridLens Docker hub and one persistent volume; keep using existing fleet collection.")
    else:
        chat.say("  Create two GridLens Docker containers (core and probe) and two persistent volumes.")
    chat.say("  Phone VPN: " + ("WireGuard, limited to the dashboard." if wireguard else "No new VPN. Use home Wi-Fi or a VPN you already have."))
    if not legacy:
        chat.say("  Check inside these outer containers only: " + (", ".join(wrappers) if wrappers else "None; normal Docker workers only."))
    if wireguard:
        for family, endpoint in options["endpoints"].items():
            chat.say("  " + family.upper() + " VPN endpoint: " + endpoint + "; UDP " + str(options["udpPort"]) + ".")
        chat.say("  Phone connectivity remains unverified until its connection test succeeds.")
    chat.say("Existing VPN, SSH and Nosana services stay in place. Setup does not install host packages or edit your router.")
    if not chat.yes("Create this GridLens installation"):
        raise Cancelled()
    result = driver.configure(options)
    if not result.get("configured"):
        raise OnboardingError("The container did not confirm installation. No device profile was created.")
    _save_owner_login(chat, result)
    return result


def _save_owner_login(chat, status):
    """Display an optional first-init owner credential without retaining a copy."""
    login = status.pop("operatorLogin", None)
    if login is None:
        return
    if not isinstance(login, dict):
        raise OnboardingError("The container returned an invalid owner login.")
    try:
        if _vpn_auth(status) or status.get("browser_pairing"):
            chat.say("Setup can sign your device in without typing a password.")
            if not chat.yes("Show an optional recovery password as a backup", default=False):
                return
        username, password = _text(login["username"], 128), _text(login["password"], 256)
        dashboard_url = _text(login["dashboard_url"])
        chat.heading("Save your recovery login" if _vpn_auth(status) else "Save the GridLens OWNER login for this PC")
        chat.say("This is an optional GridLens password. It is not your computer's administrator password.")
        chat.key("Dashboard", dashboard_url)
        chat.key("Username", username)
        chat.key("Password", password)
        chat.say("Save this in your password manager; this password cannot be shown again.")
        while not chat.yes("Have you saved this owner login", default=False):
            chat.say("Save the login above before continuing, or type cancel to stop.")
    except Cancelled:
        chat.say("The Docker installation and owner account were kept. No password was reset or erased.")
        chat.say("If you did not save this login, use container administration to create a new owner login later.")
        raise
    finally:
        login.clear()


def _vpn_auth(status):
    return status.get("wireguard") is True and status.get("vpn_device_auth") is True


def _dashboard(chat, url, vpn_auth=False):
    chat.heading("Open your dashboard")
    chat.key("Dashboard", _text(url))
    chat.say("With WireGuard ON, scan this with your phone camera." if vpn_auth else
             "Scan this with your phone camera to open the browser.")
    chat.image(url, "dashboard")
    chat.say("Your saved WireGuard connection signs you in. No dashboard password to type." if vpn_auth else
             "Use your saved GridLens login.")


def _existing_names(status):
    names = set()
    for peer in status.get("peers", []):
        name = peer.get("name")
        if isinstance(name, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,47}", name):
            names.add(name)
    return names


def _families(status):
    endpoints = status.get("endpoints")
    if isinstance(endpoints, dict) and endpoints:
        return [family for family in ("ipv4", "ipv6") if endpoints.get(family)]
    # Existing single-profile installations remain usable without any rotation.
    try:
        return ["ipv6" if ipaddress.ip_address(status.get("endpoint", "")).version == 6 else "ipv4"]
    except ValueError:
        return ["ipv4"]


def _profile_name(name, family):
    return name[:10] + "-" + family


def _profile_instructions(chat, config, client, name, family, vpn_auth=False):
    if not isinstance(config, str) or not config or len(config) > 8192:
        raise OnboardingError("The container did not return the new WireGuard profile.")
    chat.key("WireGuard profile name", _profile_name(name, family))
    if client in ("1", "2"):
        chat.say("In WireGuard, tap + / Add → Scan QR code. Scan this PROFILE code inside WireGuard.")
        chat.say("Widen this terminal if needed to see the whole square. Keep this code private.")
        chat.image(config, "profile")
        if not vpn_auth:
            chat.say("Leave the new connection off until your login is saved.")
    else:
        chat.say("Import the connection into WireGuard's tunnel editor or an import file on your computer.")
        if chat.yes("Show the private WireGuard configuration here", default=False):
            chat.say(config)
        else:
            chat.say("The profile has not been transferred to your computer.")


def _connection_test(driver, chat, name, family, vpn_auth=False):
    if not chat.yes("Test this device's " + family.upper() + " connection now"):
        chat.say("This profile is saved but its connection remains unverified.")
        return None
    chat.say("Turn phone Wi-Fi OFF and use mobile data for an outside-network test. Turn ON only " + _profile_name(name, family) + ".")
    mobile = chat.yes("Have you turned off phone Wi-Fi and confirmed mobile data is in use", default=False)
    started = driver.test_start(name, family, mobile_data=mobile)
    try:
        chat.heading("Check your phone connection")
        chat.say("Open this test link on that device:" if vpn_auth else
                 "Open this test link on that device and sign in with its saved GridLens login:")
        url = _text(started["test_url"])
        chat.say(url)
        chat.image(url, "test")
        while chat.yes("Have you opened that link; check the result now" if vpn_auth else
                       "Have you opened that link and signed in; check the result now"):
            result = driver.test_status(name, family)
            vpn = result.get("vpn_connected") is True
            dashboard = result.get("dashboard_access") is True
            actual_family = result.get("endpoint_family", "unknown")
            actual_family = actual_family if actual_family in ("ipv4", "ipv6") else "unknown"
            confirmed = result.get("mobile_data_user_confirmed") is True
            chat.say("VPN connectivity: " + ("verified" if vpn else "not verified") + ".")
            chat.say("Authenticated dashboard access: " + ("verified" if dashboard else "not verified") + ".")
            chat.say("Observed endpoint family: " + actual_family.upper() + " (at the VPN server).")
            chat.say("Mobile-data use: " + ("user-confirmed" if confirmed else "not user-confirmed") + ".")
            verified = (result.get("verified") is True and vpn and dashboard and actual_family == family
                        and result.get("status") not in ("expired", "cancelled") and result.get("endpoint_available") is not False)
            if verified:
                chat.say(family.upper() + " phone connection verified for this connection" +
                         (" with user-confirmed mobile data." if confirmed else "; outside-network use remains unverified."))
                if family == "ipv6":
                    chat.say("IPv6 availability can change on other networks.")
                return {**result, "verified": True}
            if actual_family != family:
                chat.say("The transport is different or uncertain; this does not verify the selected address family.")
                chat.say("Confirm the selected endpoint and address family with your network administrator, then retest.")
            if result.get("repair"):
                chat.say(_text(result["repair"]))
            chat.say("Not verified yet. Check WireGuard is ON, the endpoint, and the UDP router/firewall rule.")
            if result.get("status") in ("expired", "cancelled"):
                chat.say("This test has ended. Run setup again to start a fresh test; the saved profile is unchanged.")
                return {**result, "verified": False}
            if not chat.yes("Retry after checking those settings", default=False):
                return {**result, "verified": False}
        return None
    finally:
        driver.test_cancel(name, family)


def _backup_instructions(chat, name, profiles, results=None):
    results = results or {}
    tested = [family for family in profiles if results.get(family, {}).get("verified")]
    if len(profiles) < 2 and "ipv6" not in profiles:
        return
    chat.heading("Keep your backup instructions")
    if len(profiles) > 1:
        chat.say("Save this before leaving setup: turn the active GridLens profile OFF, turn the saved alternate ON, then reopen the saved dashboard URL.")
        chat.say("Only one profile should be active. Removing a lost device revokes both profiles.")
    if "ipv4" in tested and "ipv6" in tested:
        chat.say("Both paths passed. Use " + _profile_name(name, "ipv4") + " normally for broader compatibility; keep " + _profile_name(name, "ipv6") + " saved as your tested backup.")
    elif "ipv6" in tested:
        chat.say("IPv6 is the only verified path. There is no verified working IPv4 backup.")
        chat.say("For IPv4, obtain an inbound public IPv4 endpoint and arrange UDP forwarding/ACL permission to this PC, then add and test an IPv4 profile.")
    elif "ipv4" in tested:
        chat.say("IPv4 passed. Any saved IPv6 alternate remains unverified until its own test passes.")
    else:
        chat.say("Saved profiles are not verified backups until their individual connection tests pass.")
    chat.say("IPv6 availability can change when you change networks.")


def _additional_profile(driver, chat, name, family, client, vpn_auth=False):
    chat.say("Keep your existing profile saved; " + family.upper() + " is an alternate connection for this device.")
    if not chat.yes("Create an additional " + family.upper() + " profile", default=True):
        return False
    pair = dict(driver.profile_add(name, family))
    saved = False
    try:
        _profile_instructions(chat, pair.get("wireguard_config"), client, name, family, vpn_auth)
        while not chat.yes("Have you imported and saved this additional profile", default=False):
            if chat.choice("Choose what to do next:", (("1", "Show this same profile again"),
                           ("2", "Cancel only the additional profile")), "1") == "2":
                raise Cancelled()
            _profile_instructions(chat, pair.get("wireguard_config"), client, name, family, vpn_auth)
        saved = True
        return True
    except Cancelled:
        chat.say("Additional profile cancelled. Your existing saved profile and login were kept.")
        return False
    finally:
        pair.clear()
        if not saved:
            driver.profile_cancel(name, family)


def _browser_signin(driver, chat, name):
    grant = dict(driver.browser_pair_issue(name))
    try:
        url = _text(grant["pair_url"], 2048)
        grant_hash = _text(grant["grant_hash"], 64)
        chat.heading("Sign in this browser")
        chat.say("Connect this device to your existing VPN or home Wi-Fi first.")
        chat.say("Open this one-time link on that device, then choose Connect browser. No password to type.")
        chat.say("The link expires in 10 minutes. Keep it private.")
        chat.say(url)
        while True:
            action = chat.choice("Continue when the dashboard opens", (
                ("1", "The dashboard is open — check sign-in"),
                ("2", "Show a QR code for my phone"),
                ("3", "Cancel this sign-in link")), "1")
            if action == "3":
                raise Cancelled()
            if action == "2":
                chat.image(url, "browser-login")
                continue
            result = driver.browser_pair_status(name, grant_hash)
            if result.get("paired") is True:
                chat.say("Browser connected. Bookmark the dashboard address below; the sign-in link is single-use.")
                return _text(grant["dashboard_url"])
            if result.get("status") in ("expired", "cancelled"):
                chat.say("That sign-in link has expired or was cancelled. Run setup again for a new link.")
                raise Cancelled()
            chat.say("The sign-in link has not been used yet. Open it on the device and choose Connect browser.")
    finally:
        # The link is ephemeral; cancelling it does not revoke an existing
        # device or a browser session already created by successful pairing.
        if grant.get("grant_hash"):
            driver.browser_pair_cancel(name, grant["grant_hash"])
        grant.clear()


def _pair(driver, chat, status, existing_network=False):
    wireguard = status.get("wireguard") is True and not existing_network
    browser_pairing = status.get("browser_pairing") is True
    management = status.get("management_available", True)
    if wireguard and browser_pairing and management:
        path = chat.choice("How should this device connect?", (
            ("1", "Use my existing VPN or home Wi-Fi — skip VPN setup"),
            ("2", "Set up a GridLens WireGuard connection for me")), "2")
        wireguard = path == "2"
    if not wireguard and not management:
        raise OnboardingError("This PC has no private dashboard address. Use its GridLens WireGuard connection.")
    vpn_auth = wireguard and _vpn_auth(status)
    chat.heading("Connect your device")
    client = "1"
    if wireguard:
        client = chat.choice("Which device are you connecting?", [(key, item[0]) for key, item in CLIENTS.items()], "1")
        title, suggested_name, app_url = CLIENTS[client]
        if not chat.yes("Is the official WireGuard app already installed"):
            chat.heading("Install WireGuard on your " + title)
            chat.say("Use your phone camera for this installation link. No VPN is needed to install the app.")
            chat.say(app_url)
            chat.image(app_url, "app")
            if not chat.yes("Have you installed WireGuard"):
                chat.say("Install it first, then run this command again. No device was added.")
                return {"status": "ready", "paired": False}
    else:
        suggested_name = "my-browser" if browser_pairing else "my-phone"
        chat.say("Use this PC’s existing LAN address. VPN setup is skipped for this device.")
        chat.say("Connect your phone to your hosts' home Wi-Fi, or use a VPN that already reaches them.")
    existing = _existing_names(status)
    base = suggested_name
    suffix = 2
    while suggested_name in existing:
        suggested_name = base + "-" + str(suffix)
        suffix += 1
    chat.say("This name identifies the device in GridLens.")
    while True:
        name = chat.ask("Give this device a name", suggested_name)
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,47}", name):
            chat.say("Use 1–48 letters, numbers or dashes. For example: my-phone.")
        elif name in existing and (wireguard or not browser_pairing):
            chat.say("That device already exists. Choose another name; its saved connection will be kept.")
        else:
            break
    if not vpn_auth and not browser_pairing and not chat.yes("Create a separate login" + (" and VPN profile" if wireguard else "") + " for " + name):
        raise Cancelled()
    families = _families(status) if wireguard else []
    family = families[0] if families else None
    modern_access = status.get("access_version", 1) >= 2
    reused = name in existing and not wireguard and browser_pairing
    pair = ({"username": name} if reused else
            dict(driver.add_device(name, app_only=not wireguard, profile=family) if modern_access
                 else driver.add_device(name, app_only=not wireguard)))
    saved = False
    try:
        if not wireguard and browser_pairing:
            url = _browser_signin(driver, chat, name)
            saved = True
            chat.key("Dashboard", url)
            return {"status": "paired", "device": name, "wireguard": False, "dashboard_url": url}
        username = _text(pair["username"], 128)
        password = None if vpn_auth else _text(pair["password"], 256)
        url = _text(pair["dashboard_url"])
        config = pair.get("wireguard_config")
        if wireguard and (not isinstance(config, str) or not config):
            raise OnboardingError("The container did not return the new device's WireGuard profile.")
        if vpn_auth:
            chat.heading("Save your WireGuard connection")
            chat.say("This saved profile is your dashboard login. No extra password is needed.")
        else:
            chat.heading("Save your dashboard login")
            chat.say("Save these in your password manager. This is not your computer's administrator password.")
            chat.key("Username", username)
            chat.key("Password", password)
            if pair.get("role") == "operator":
                chat.say("This device can manage dashboard settings.")
        if wireguard:
            chat.say()
            _profile_instructions(chat, config, client, name, family, vpn_auth)
        saved_question = ("Have you imported and saved this WireGuard profile" if vpn_auth else
                          "Have you saved the login" + (" and imported this WireGuard profile" if wireguard else ""))
        while not chat.yes(saved_question, default=False):
            choice = chat.choice("Choose what to do next:", (("1", "Show these same device details again"),
                                  ("2", "Cancel this new device")), "1")
            if choice == "2":
                raise Cancelled()
            if not vpn_auth:
                chat.key("Username", username)
                chat.key("Password", password)
            if wireguard:
                if client in ("1", "2"):
                    chat.image(config, "profile")
                elif chat.yes("Show the same private WireGuard configuration", default=False):
                    chat.say(config)
        saved = True
        chat.say("Device saved. Its profile stays valid when GridLens or this PC restarts.")
        results, profiles = {}, []
        if wireguard:
            profiles.append(family)
            chat.heading("Now turn this connection ON in WireGuard")
        _dashboard(chat, url, vpn_auth)
        if wireguard and modern_access:
            results[family] = _connection_test(driver, chat, name, family, vpn_auth) or {}
            chat.say("This bootstrap profile covers this PC only. In the dashboard, open Connect devices and download one WireGuard profile for all approved, prepared PCs.")
            chat.say("The combined profile lists its exact coverage. Keep this bootstrap connection until the replacement is verified.")
            if len(families) > 1:
                chat.say("Other endpoint families remain available for explicit maintenance; setup creates one bootstrap profile.")
        elif wireguard:
            chat.say("This saved image predates authenticated connection tests and alternate profiles. Connectivity remains unverified.")
            chat.say("Run the installer with --upgrade to enable those features explicitly. Your saved profile and login stay valid.")
        return {"status": "paired", "device": name, "wireguard": wireguard, "dashboard_url": url, "profiles": profiles, "tests": results}
    finally:
        # Plaintext login/profile exist only during this terminal conversation.
        pair.clear()
        if not saved and not reused:
            try:
                driver.revoke_device(name)
                chat.say("Only the unfinished new device " + name + " was removed. Existing devices were kept.")
            except Exception:
                chat.say("The unfinished device " + name + " needs cleanup. Run setup again and revoke that device by name.")


def _revocation_result(chat, result, name):
    result = result or {}
    if result.get("complete") is False:
        pending = [pc for pc, outcome in result.get("results", {}).items() if outcome.get("status") != "revoked"]
        chat.say("Revocation is pending on: " + ", ".join(_text(pc) for pc in pending) + ".")
        chat.say("Acknowledged PCs have removed this generation. Run setup again to retry the remaining PCs; the pending record is retained.")
        return {"status": "revocation_pending", "device": name, "paired": False, "results": result.get("results", {})}
    chat.say("Removed " + name + ". Run setup again to add a replacement with a new profile.")
    return {"status": "revoked", "device": name, "paired": False}


def _combined_profiles(driver, chat):
    inventory = driver.access_operation("inventory")
    for pc in inventory["pcs"]:
        chat.key(_text(pc["name"]), _text(pc["dashboard_url"]))
        if not pc["ready"]:
            chat.say("Needs configuration: " + _text(pc["reason"]))
    action = chat.choice("Combined WireGuard profiles", (("1", "Prepare a new combined profile"),
                        ("2", "Replace a confirmed combined profile"), ("3", "Revoke or retry a combined profile"),
                        ("4", "Finish for now")), "4")
    if action == "4":
        return {"status": "ready", "paired": False}
    generation, name = "", ""
    if action in ("2", "3"):
        records = [record for record in inventory["enrollments"]
                   if record["status"] == "confirmed" or action == "3" and record["status"] != "revoked"]
        if not records:
            chat.say("No matching combined profile is available.")
            return {"status": "ready", "paired": False}
        selected = chat.choice("Choose the exact generation", tuple((str(index + 1),
            _text(record["name"]) + " — " + _text(record["generation"]) + " (" + _text(record["status"]) + ")")
            for index, record in enumerate(records)), "1")
        previous = records[int(selected) - 1]
        generation, name = previous["generation"], previous["name"]
    if action == "3":
        chat.say("Every PC in this generation's saved coverage must acknowledge revocation. Unreachable PCs stay pending.")
        if chat.yes("Revoke this generation of " + name, default=False):
            return _revocation_result(chat, driver.access_operation("revoke", generation=generation), name)
        return {"status": "ready", "paired": False}
    if not name:
        while True:
            name = chat.ask("Name for the new combined profile", "my-phone")
            if re.fullmatch(r"[A-Za-z0-9_-]{1,48}", name):
                break
            chat.say("Use at most 48 letters, numbers, dashes or underscores.")
    chat.say("One temporary device key will be enrolled independently on approved PCs. Previous profiles remain active until the replacement is verified.")
    if not chat.yes("Prepare this combined profile", default=False):
        return {"status": "ready", "paired": False}
    prepared = driver.access_operation("prepare", name=name, replaces=generation)
    session, confirmed = prepared["session"], False
    try:
        while True:
            current = driver.access_operation("status", session=session)
            chat.heading("Complete file coverage")
            for pc in current["included"]:
                chat.key(_text(pc["name"]), _text(pc["dashboard_url"]))
            for pc in current["excluded"]:
                chat.say("Excluded " + _text(pc["name"]) + ": " + _text(pc["reason"]))
            chat.say("Import the saved .conf file into the official WireGuard app. This temporary enrollment expires after 15 minutes unless confirmed.")
            action = chat.choice("Continue this enrollment", (("1", "Save the complete WireGuard file"),
                ("2", "Retry PCs and refresh coverage"), ("3", "Confirm after verifying every included PC"),
                ("4", "Cancel this new generation")), "1")
            if action == "4":
                raise Cancelled()
            if action == "1":
                destination = chat.ask("New local file path for the private client export")
                exported = driver.save_access_profile(session, destination)
                chat.say("Private profile saved. File coverage: " + ", ".join(_text(pc["name"]) for pc in exported["included"]) + ".")
                chat.say("Activate that profile, open each included dashboard, and verify this generation in Connect devices before confirmation.")
            elif action == "3":
                try:
                    result = driver.access_operation("confirm", session=session, pcs=[pc["id"] for pc in current["included"]])
                except Exception:
                    chat.say("Confirmation was not acknowledged. Verify the imported generation on every included dashboard, then retry. Saved generations remain available in option 8.")
                    continue
                confirmed = result.get("confirmed") is True
                if confirmed:
                    chat.say("Combined profile confirmed. Its saved identity survives restart.")
                    if result.get("previous_preserved"):
                        chat.say("Previous coverage remains active because this replacement has not verified all of it.")
                    previous = result.get("previous_generation")
                    if previous and not previous.get("complete"):
                        _revocation_result(chat, previous, "previous generation")
                    return {"status": "paired", "paired": True, "generation": prepared["generation"]}
                chat.say("Confirmation is pending. Retry when every included PC is reachable.")
    finally:
        if not confirmed:
            # A response may be lost after successful confirmation. Cancel
            # refuses confirmed generations; never revoke the working profile
            # just because a terminal or connection disappeared mid-confirm.
            try:
                result = driver.access_operation("cancel", session=session)
            except Exception:
                chat.say("This generation may already be confirmed or needs cleanup. Review it in option 8; no confirmed profile was automatically revoked.")
            else:
                _revocation_result(chat, result, name)


def run_onboarding(driver, tty, qr):
    """Run one bounded onboarding conversation; Docker access belongs to driver.

    tty is a read/write text stream already opened on /dev/tty by the launcher.
    qr(text, kind) renders locally; kind is app, profile, dashboard, or test. It may
    return terminal text or print through the caller and return None.
    """
    chat = Conversation(tty, qr)
    try:
        status = driver.status()
        new = not status.get("configured")
        if new:
            status = _first_install(driver, chat, status)
        else:
            # The Docker driver may finish an interrupted first initialization
            # while restoring owned containers. Its one-time login still needs
            # to be saved even though the resulting status is now configured.
            _save_owner_login(chat, status)
            chat.heading("GridLens is ready")
            chat.say("Your saved settings and devices will be reused.")
            if status.get("running") is False:
                chat.say("The owned container is stopped. The Docker launcher must start it with its existing volume first.")
                return {"status": "stopped", "paired": False}
            if status.get("wireguard"):
                chat.key("Saved VPN endpoint", _text(status.get("endpoint", "not available")))
                health = status.get("endpointHealth", {})
                if health.get("missingBindings"):
                    for family, address in health["missingBindings"].items():
                        chat.say("Saved " + _text(family).upper() + " address is no longer assigned: " + _text(address) + ". This profile needs repair.")
                    chat.say(_text(health.get("repair") or "Restore the saved address, or explicitly repair the endpoint and update Endpoint in the saved WireGuard profile. Keep the existing keys."))
                elif health.get("addressInspectionAvailable") is False:
                    chat.say("Host address inspection is unavailable; saved endpoint availability is unknown.")
                if status.get("fleetConnection", {}).get("configured") is False:
                    chat.say("Fleet connection: unconfigured. Multi-PC replication needs a private network or an existing private VPN.")
                chat.say("You do not need to scan a new profile after a reboot.")
                if not _vpn_auth(status):
                    chat.say("This saved version still needs a dashboard password. Run the installer with --upgrade once for WireGuard sign-in.")
        saved_vpn = any(peer.get("wireguard", True) for peer in status.get("peers", []) if isinstance(peer, dict))
        first_device = new or (status.get("wireguard") and not saved_vpn)
        if first_device and _vpn_auth(status):
            return _pair(driver, chat, status)
        choices = [("1", "Connect a phone or computer"), ("2", "Use my saved device"),
                   ("3", "Finish for now"), ("4", "Remove a lost device"),
                   ("5", "Legacy endpoint maintenance for a saved profile"), ("6", "Test a saved device profile")]
        if status.get("browser_pairing") and status.get("management_available", True):
            choices.append(("7", "Sign in using my existing VPN or home Wi-Fi"))
        if status.get("fleet_access"):
            choices.append(("8", "Manage combined WireGuard profiles across approved PCs"))
        choice = chat.choice("What would you like to do?", choices, "1" if first_device else "2")
        if choice == "8":
            return _combined_profiles(driver, chat)
        if choice == "7":
            return _pair(driver, chat, status, existing_network=True)
        if choice == "1":
            return _pair(driver, chat, status)
        if choice == "2":
            if _vpn_auth(status):
                chat.say("Turn ON the WireGuard profile already saved on your device. No dashboard password is needed.")
            else:
                chat.say("Keep using the connection and GridLens login already saved on your device.")
            chat.say("Existing private keys and passwords cannot be shown again. Nothing was rotated or replaced.")
            if status.get("profile_route_update"):
                chat.heading("Use the same dashboard address on phone and laptop")
                chat.say("For an older GridLens profile, edit AllowedIPs in WireGuard and add " +
                         _text(status["profile_route_update"]) + "; keep its existing entries and keys.")
                chat.say("New profiles already include this route. The VPN still reaches only this PC's dashboard.")
                if status.get("canonical_migration_pending"):
                    chat.say("Test each saved profile at this address, then explicitly retire old access with --retire-tunnel-urls.")
            _dashboard(chat, status["dashboardURL"], _vpn_auth(status))
        if choice in ("5", "6"):
            if status.get("access_version", 1) < 2:
                chat.say("This saved image predates authenticated connection tests and alternate profiles.")
                chat.say("Run the installer with --upgrade to enable those features explicitly. Your saved profile and login stay valid.")
                return {"status": "ready", "paired": False}
            if not status.get("wireguard"):
                chat.say("This installation has no WireGuard server. Existing logins remain unchanged.")
                return {"status": "ready", "paired": False}
            names = sorted(_existing_names(status))
            if not names:
                chat.say("Add a device first so that its profiles share one saved login.")
                return {"status": "ready", "paired": False}
            chat.say("Saved devices: " + ", ".join(names))
            while True:
                name = chat.ask("Device name")
                if name in names:
                    break
                chat.say("Choose one of the saved names above.")
            peer = next(peer for peer in status["peers"] if peer.get("name") == name)
            profiles = peer.get("profiles", _families(status)[:1] if peer.get("wireguard", True) else [])
            if peer.get("generation") or "fleet" in profiles:
                chat.say("This is a combined profile. Use option 8 for generation administration; verify its access from each dashboard through that saved VPN profile.")
                return {"status": "ready", "paired": False}
            available = [family for family in _families(status) if family not in profiles] if choice == "5" else profiles
            if not available:
                chat.say("No additional configured endpoint is available for this device." if choice == "5" else "This device has no VPN profile.")
                chat.say("Existing private keys cannot be redisplayed. Keep the profiles already saved in WireGuard.")
                return {"status": "ready", "paired": False}
            selected = chat.choice("Choose the profile family:", tuple((str(i + 1), family.upper()) for i, family in enumerate(available)), "1")
            family = available[int(selected) - 1]
            if choice == "5":
                client = chat.choice("Which device are you connecting?", [(key, item[0]) for key, item in CLIENTS.items()], "1")
                if not _additional_profile(driver, chat, name, family, client, _vpn_auth(status)):
                    return {"status": "ready", "paired": False}
                profiles = [*profiles, family]
            if len(profiles) > 1:
                _backup_instructions(chat, name, profiles)
            result = _connection_test(driver, chat, name, family, _vpn_auth(status)) or {}
            _backup_instructions(chat, name, profiles, {family: result})
            return {"status": "ready", "paired": False, "device": name, "tests": {family: result}}
        if choice == "4":
            if status.get("fleet_access"):
                # A locally removed credential must not hide pending remote
                # revocations on subsequent terminal runs.
                inventory = driver.access_operation("inventory")
                status["peers"] = list(status.get("peers", []))
                for record in inventory["enrollments"]:
                    if record["status"] != "revoked" and record["device"] not in _existing_names(status):
                        status["peers"].append({"name": record["device"], "generation": record["generation"]})
            names = sorted(_existing_names(status))
            if not names:
                chat.say("No saved device names were returned by this container.")
                return {"status": "ready", "paired": False}
            chat.say("Saved devices: " + ", ".join(names))
            while True:
                name = chat.ask("Name of the lost device to remove")
                if name in names:
                    break
                chat.say("Choose one of the saved names above, or type cancel.")
            chat.say("This removes " + name + "'s dashboard login and all its VPN profiles. Other devices stay connected.")
            if status.get("origin", {}).get("kind") == "same-pc-legacy-hub":
                chat.say("This changes this Docker dashboard only. Older dashboards keep their separate logins and VPN connections.")
            if chat.yes("Remove only " + name, default=False):
                result = driver.revoke_device(name)
                return _revocation_result(chat, result, name)
        return {"status": "ready", "paired": False}
    except Cancelled:
        chat.say("Setup stopped. Existing GridLens data and devices were kept.")
        return {"status": "cancelled", "paired": False}
