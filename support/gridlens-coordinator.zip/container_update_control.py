#!/usr/bin/env python3
"""Root-owned update policy and bounded coordination, without Docker access.

The installer approves this roster independently of VPN/telemetry membership.
The browser can only switch its policy. A separate Docker worker verifies signed
releases and performs fixed prepare/apply/rollback operations from this journal.
"""
import base64
import copy
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import hmac
import http.client
import importlib.util
import json
import os
from pathlib import Path
import re
import secrets
import ssl
import stat
import time

try:
    from container_access import Error, _hostport, _origin, _unique_object, certificate_pin
except ModuleNotFoundError:
    # Isolated tests load runtime helpers by path, without modifying sys.path.
    _spec = importlib.util.spec_from_file_location('gridlens_update_access', Path(__file__).with_name('container_access.py'))
    _access = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_access)
    Error, _hostport, _origin = _access.Error, _access._hostport, _access._origin
    _unique_object, certificate_pin = _access._unique_object, _access.certificate_pin

MAX_PCS = 1024
LIMIT = 8 * 1024 * 1024
CHECK_INTERVAL = 120
PROTOCOL = 1
ID = re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}')
VERSION = re.compile(r'v[0-9]+\.[0-9]+\.[0-9]+(?:-[A-Za-z0-9][A-Za-z0-9.-]{0,63})?')
HEX = re.compile(r'[0-9a-f]{64}')
JOB = re.compile(r'[0-9a-f]{32}')


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def release_order(left, right):
    """Same precedence as terminal setup, including historical dev7/dev10 tags."""
    def parts(value):
        match = re.fullmatch(r'v?(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)'
                             r'(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?'
                             r'(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?', value)
        if not match:
            raise Error('cannot safely compare the selected and installed release versions')
        pre = match[4]
        if pre and re.fullmatch(r'dev[0-9]+', pre):
            pre = 'dev.' + pre[3:]
        identifiers = []
        for item in pre.split('.') if pre else []:
            if item.isdigit():
                if len(item) > 1 and item.startswith('0'):
                    raise Error('invalid prerelease version')
                identifiers.append((0, int(item)))
            else:
                identifiers.append((1, item))
        return (*map(int, match.group(1, 2, 3)), pre is None, tuple(identifiers))
    first, second = parts(left), parts(right)
    return (first > second) - (first < second)


def manifest(value):
    """Shape only; every worker independently verifies the pinned signature."""
    if not isinstance(value, dict) or set(value) != {'manifest', 'signature'}:
        raise Error('invalid signed release envelope')
    content = value['manifest']
    fields = {'schema', 'channel', 'sequence', 'version', 'sourceCommit', 'artifacts', 'minUpdaterProtocol'}
    if (not isinstance(content, dict) or set(content) != fields or content['schema'] != 1
            or content['channel'] != 'development' or type(content['sequence']) is not int
            or not 1 <= content['sequence'] <= 9007199254740991
            or type(content['minUpdaterProtocol']) is not int or content['minUpdaterProtocol'] != PROTOCOL
            or not isinstance(content['version'], str) or not VERSION.fullmatch(content['version'])
            or not isinstance(content['sourceCommit'], str) or not re.fullmatch(r'[0-9a-f]{40}', content['sourceCommit'])):
        raise Error('unsupported release channel, sequence or updater protocol')
    artifacts = content['artifacts']
    if not isinstance(artifacts, dict) or set(artifacts) != {'amd64', 'arm64'}:
        raise Error('release must include both supported architectures')
    for artifact in artifacts.values():
        if (not isinstance(artifact, dict) or set(artifact) != {'sha256', 'size'}
                or not isinstance(artifact['sha256'], str) or not HEX.fullmatch(artifact['sha256'])
                or type(artifact['size']) is not int or not 1 <= artifact['size'] <= 256 * 1024 * 1024):
            raise Error('invalid release artifact digest or size')
    try:
        if not isinstance(value['signature'], str) or len(base64.b64decode(value['signature'], validate=True)) != 64:
            raise ValueError()
    except (TypeError, ValueError):
        raise Error('invalid release signature encoding') from None
    return copy.deepcopy(value)


def registration(value):
    if (not isinstance(value, dict) or set(value) != {'id', 'name', 'dashboard_url', 'control_url', 'certificate'}
            or not isinstance(value['id'], str) or not ID.fullmatch(value['id'])
            or not isinstance(value['name'], str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', value['name'])):
        raise Error('invalid public update registration')
    dashboard = _origin(value['dashboard_url'], 'http')
    control = _origin(value['control_url'], 'https', '/v1/updates')
    if dashboard.hostname != control.hostname:
        raise Error('update administration must use the canonical PC address')
    certificate_pin(value['certificate'])
    return copy.deepcopy(value)


class PeerTransport:
    def __init__(self, runtime):
        self.runtime = runtime

    def __call__(self, pc, request):
        parsed = _origin(pc['control_url'], 'https', '/v1/updates')
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.minimum_version = ssl.TLSVersion.TLSv1_3
        context.load_verify_locations(cadata=pc['certificate'])
        context.verify_flags |= getattr(ssl, 'VERIFY_X509_PARTIAL_CHAIN', 0)
        directory = self.runtime.base / 'identities/hub'
        for name in ('identity.crt', 'identity.key'):
            self.runtime._safe(directory / name)
        context.load_cert_chain(directory / 'identity.crt', directory / 'identity.key')
        connection = http.client.HTTPSConnection(parsed.hostname, parsed.port, timeout=18 if request.get('action') == 'policy' else 4, context=context)
        try:
            connection.connect()
            actual = hashlib.sha256(connection.sock.getpeercert(binary_form=True)).hexdigest()
            if not hmac.compare_digest(actual, certificate_pin(pc['certificate'])):
                raise Error('update server identity changed')
            payload = encoded(request)
            if len(payload) > 128 * 1024:
                raise Error('update request exceeds its limit')
            connection.request('POST', '/v1/updates', body=payload, headers={'Content-Type': 'application/json'})
            response = connection.getresponse()
            data = response.read(LIMIT + 1)
            if response.status != 200 or len(data) > LIMIT:
                raise Error('update operation was not acknowledged')
            result = json.loads(data, object_pairs_hook=_unique_object)
            if not isinstance(result, dict):
                raise Error('invalid update acknowledgment')
            return result
        finally:
            connection.close()


class UpdatesController:
    def __init__(self, runtime, transport=None):
        self.r = runtime
        self.path = runtime.control / 'updates.json'
        self.transport = transport or PeerTransport(runtime)

    def _load(self, state):
        if not self.path.exists():
            return {'schema': 1, 'owner': state['owner'], 'pcs': [], 'coordinator_id': '', 'fleet_id': '',
                    'policy': {'revision': 0, 'enabled': False}, 'durable_policy_revision': 0,
                    'local': {'state': 'unavailable', 'worker_seen': 0},
                    'hosts': {}, 'transaction': None, 'candidate': None, 'sequence': 0, 'failed_manifest': '', 'cursor': 0}
        self.r._safe(self.path)
        data = self.path.read_bytes()
        if len(data) > LIMIT:
            raise Error('update journal exceeds its limit')
        value = json.loads(data, object_pairs_hook=_unique_object)
        if (not isinstance(value, dict) or value.get('schema') != 1 or value.get('owner') != state['owner']
                or not isinstance(value.get('pcs'), list) or len(value['pcs']) > MAX_PCS
                or not isinstance(value.get('policy'), dict) or type(value['policy'].get('enabled')) is not bool
                or type(value['policy'].get('revision')) is not int):
            raise Error('invalid owned update journal')
        return value

    def _save(self, value):
        self.r._write(self.path, value)

    def _snapshot(self):
        with self.r.locked():
            state = self.r.load()
            return state, self._load(state)

    def _public(self, state):
        c = state['config']
        return registration({'id': state['hub_id'], 'name': c['name'],
                             'dashboard_url': 'http://' + _hostport(c['advertise_host'], c['http_port']),
                             'control_url': 'https://' + _hostport(c['advertise_host'], c['telemetry_port']) + '/v1/updates',
                             'certificate': self.r._certificate('hub')})

    def public(self):
        with self.r.locked():
            return self._public(self.r.load())

    def _publish(self, state, document):
        self.r._write(self.r.base / 'app/updates-roster.json',
                      {'schema': 1, 'self_id': state['hub_id'], 'pcs': document['pcs']}, 0o640, gid=10001)

    def publish(self):
        with self.r.locked():
            state = self.r.load()
            self._publish(state, self._load(state))

    def join(self, pcs, coordinator_id):
        """Installer-only approval; no browser or remote action may call this."""
        if not isinstance(pcs, list) or not 1 <= len(pcs) <= MAX_PCS:
            raise Error('approve one to 1,024 update PCs explicitly')
        pcs = sorted([registration(pc) for pc in pcs], key=lambda pc: pc['id'])
        if (len({pc['id'] for pc in pcs}) != len(pcs)
                or len({certificate_pin(pc['certificate']) for pc in pcs}) != len(pcs)
                or len({pc['control_url'] for pc in pcs}) != len(pcs)
                or coordinator_id not in {pc['id'] for pc in pcs}):
            raise Error('update roster needs distinct identities/endpoints and an approved coordinator')
        with self.r.locked():
            state = self.r.load()
            if self._public(state) not in pcs:
                raise Error('update roster must include this PC\'s exact public registration')
            document = self._load(state)
            fleet_id = digest({'pcs': pcs, 'coordinator_id': coordinator_id})
            if document['fleet_id'] != fleet_id:
                if document['transaction'] and document['transaction']['phase'] not in ('complete', 'failed'):
                    raise Error('finish the pending update or rollback before changing its fleet')
                document.update(pcs=pcs, coordinator_id=coordinator_id, fleet_id=fleet_id,
                                policy={'revision': 0, 'enabled': False}, durable_policy_revision=0, hosts={}, transaction=None, candidate=None,
                                failed_manifest='', cursor=0)
                document['local'].pop('command', None)
            self._save(document)
            self._publish(state, document)
            return {'approved': len(pcs), 'coordinator_id': coordinator_id, 'fleet_id': fleet_id, 'enabled': document['policy']['enabled']}

    def _local_status(self, state, document):
        return {**copy.deepcopy(document['local']), 'id': state['hub_id'], 'name': state['config']['name'],
                'revision': document['policy']['revision'], 'enabled': document['policy']['enabled'],
                'durable_policy_revision': document.get('durable_policy_revision', 0),
                'fleet_id': document['fleet_id']}

    def _status(self, state, document):
        now = int(self.r.now())
        tx = document['transaction']
        hosts = []
        for pc in document['pcs']:
            info = document['hosts'].get(pc['id'], {})
            if pc['id'] == state['hub_id']:
                info = {**self._local_status(state, document), 'seen_at': now}
            row = {k: info[k] for k in ('current_version', 'state', 'error', 'worker_seen', 'revision') if k in info}
            if not info or now - info.get('seen_at', 0) > self._freshness(document):
                row.update(state='unreachable', error='Waiting for this approved PC')
            elif info.get('seen_at', now) - info.get('worker_seen', 0) > 120:
                row.update(state='unavailable', error='Waiting for this PC\'s Docker update worker')
            row.update(id=pc['id'], name=pc['name'])
            if tx:
                row['target_version'] = tx['manifest']['manifest']['version']
            hosts.append(row)
        phase = tx['phase'] if tx else 'idle' if document['policy']['enabled'] else 'disabled'
        message = document.get('message', '')
        if not tx and document['policy']['enabled'] and any(h['state'] in ('unavailable', 'unreachable') for h in hosts):
            phase, message = 'blocked', 'Waiting for every approved PC and update worker before updating the fleet.'
        result = {'available': bool(document['pcs']), 'enabled': document['policy']['enabled'],
                  'channel': 'development', 'check_interval_seconds': CHECK_INTERVAL,
                  'coordinator_id': document['coordinator_id'], 'self_id': state['hub_id'],
                  'revision': document['policy']['revision'], 'fleet_id': document['fleet_id'],
                  'hosts': hosts, 'phase': phase, 'message': message}
        result['policy_pending'] = document['policy']['revision'] != document.get('durable_policy_revision', 0)
        if result['policy_pending']:
            result['message'] = 'The requested setting is waiting for durable acknowledgment from the update worker.'
            if result['phase'] in ('idle', 'disabled', 'complete', 'failed'):
                result['phase'] = 'blocked'
        for field in ('last_check', 'next_check'):
            if field in document:
                result[field] = document[field]
        if tx:
            result.update(target_version=tx['manifest']['manifest']['version'], transaction=tx['id'])
        return result

    def status(self, actor=None):
        state, document = self._snapshot()
        if document['coordinator_id'] and document['coordinator_id'] != state['hub_id']:
            pc = next(pc for pc in document['pcs'] if pc['id'] == document['coordinator_id'])
            try:
                result = self.transport(pc, {'action': 'status', 'fleet_id': document['fleet_id']})
                result['self_id'] = state['hub_id']
                return result
            except Exception:
                result = self._status(state, document)
                result.update(phase='blocked', message='Update coordinator is unreachable; no new fleet update can start.')
                return result
        return self._status(state, document)

    def policy(self, enabled, actor=None):
        if type(enabled) is not bool:
            raise Error('enabled must be a boolean')
        state, document = self._snapshot()
        if not document['pcs']:
            raise Error('install the update worker and explicitly approve an update fleet first')
        if document['coordinator_id'] != state['hub_id']:
            pc = next(pc for pc in document['pcs'] if pc['id'] == document['coordinator_id'])
            result = self.transport(pc, {'action': 'policy', 'enabled': enabled, 'fleet_id': document['fleet_id']})
            result['self_id'] = state['hub_id']
            return result
        with self.r.locked():
            state = self.r.load()
            document = self._load(state)
            if document['policy']['enabled'] != enabled:
                document['policy'] = {'revision': document['policy']['revision'] + 1, 'enabled': enabled}
            self._save(document)
        # Save on other approved PCs before returning when reachable. This also
        # lets a coordinator recovering its paired backup recover a newer toggle.
        # Missing acknowledgments remain explicit; an offline PC never agreed.
        self._sync()
        deadline = time.monotonic() + 6
        while True:
            state, document = self._snapshot()
            if document['policy']['revision'] == document.get('durable_policy_revision', 0):
                return self._status(state, document)
            if time.monotonic() >= deadline:
                raise Error('Update policy is pending durable worker acknowledgment; refresh status before retrying.')
            time.sleep(.1)

    def peer(self, caller, certificate_sha256, request):
        state, document = self._snapshot()
        pc = next((pc for pc in document['pcs'] if pc['id'] == caller), None)
        if (not pc or caller == state['hub_id'] or not isinstance(certificate_sha256, str)
                or not hmac.compare_digest(certificate_sha256, certificate_pin(pc['certificate']))):
            raise Error('PC has not been explicitly approved for updates')
        return self._receive(caller, request)

    def _receive(self, caller, request):
        allowed = {'status': {'action', 'fleet_id'}, 'policy': {'action', 'fleet_id', 'enabled'},
                   'sync': {'action', 'fleet_id', 'policy'}, 'command': {'action', 'fleet_id', 'revision', 'command'}}
        if not isinstance(request, dict) or request.get('action') not in allowed or set(request) != allowed[request['action']]:
            raise Error('unsupported fixed update operation or fields')
        action = request['action']
        with self.r.locked():
            state = self.r.load()
            document = self._load(state)
            if request['fleet_id'] != document['fleet_id'] or not document['pcs']:
                raise Error('approved update rosters differ; rerun explicit enrollment')
            if action in ('sync', 'command') and caller != document['coordinator_id']:
                raise Error('only the approved coordinator may schedule an update')
            if action == 'status':
                return self._status(state, document)
            if action == 'policy':
                if state['hub_id'] != document['coordinator_id']:
                    raise Error('change policy through the approved coordinator')
            elif action == 'sync':
                policy = request['policy']
                if (not isinstance(policy, dict) or set(policy) != {'revision', 'enabled'}
                        or type(policy['revision']) is not int or policy['revision'] < 0
                        or type(policy['enabled']) is not bool
                        or policy['revision'] == document['policy']['revision'] and policy != document['policy']):
                    raise Error('update policy revision is stale or invalid')
                # A paired coordinator rollback may restore an older journal.
                # Return the newer approved policy instead of stranding recovery.
                if policy['revision'] > document['policy']['revision']:
                    document['policy'] = copy.deepcopy(policy)
                    self._save(document)
                return self._local_status(state, document)
            else:
                self._accept_command(document, request)
                self._save(document)
                return self._local_status(state, document)
        return self.policy(request['enabled'])

    def _accept_command(self, document, request):
        command = request['command']
        if (not isinstance(command, dict) or set(command) != {'id', 'action', 'manifest', 'manifest_digest'}
                or not isinstance(command['id'], str) or not JOB.fullmatch(command['id'])
                or command['action'] not in ('prepare', 'apply', 'rollback', 'commit')
                or request['revision'] != document['policy']['revision']):
            raise Error('invalid coordinated update command')
        envelope = manifest(command['manifest'])
        if command['manifest_digest'] != digest(envelope):
            raise Error('coordinated release digest changed')
        local = document['local']
        previous = local.get('command')
        if previous == command:
            return
        if command['action'] == 'commit' and (not previous or previous['id'] != command['id']):
            if previous and local.get('state') not in ('committed', 'idle'):
                raise Error('a different update is still pending')
            # The coordinator may have persisted delivery intent but lost the
            # connection before prepare arrived. Explicitly acknowledge that
            # this exact cohort has no local work to clean up; never run a worker
            # operation or touch resources for such an empty cancellation.
            local.update(command=copy.deepcopy(command), state='committed')
            return
        if command['action'] == 'prepare':
            if not document['policy']['enabled']:
                raise Error('automatic updates are disabled')
            if previous and local.get('state') not in ('committed', 'rolled_back', 'idle', 'failed'):
                raise Error('previous update is not resolved')
            if envelope['manifest']['sequence'] <= document['sequence']:
                raise Error('release sequence cannot go backwards')
            local.pop('error', None)
        elif (not previous or previous['id'] != command['id'] or previous['manifest_digest'] != command['manifest_digest']):
            raise Error('update phase does not match the prepared release')
        elif command['action'] == 'apply' and local.get('state') != 'ready':
            raise Error('this PC has not prepared the exact release')
        elif command['action'] == 'commit' and local.get('state') not in ('applied', 'rolled_back', 'ready', 'failed'):
            raise Error('update must finish or recover before commitment')
        local['command'] = copy.deepcopy(command)
        local['state'] = {'prepare': 'preparing', 'apply': 'applying', 'rollback': 'rolling_back', 'commit': 'committing'}[command['action']]

    @staticmethod
    def _freshness(document):
        return max(120, ((len(document['pcs']) + 31) // 32) * 15 + 60)

    def _call(self, state, document, pc, request):
        if pc['id'] == state['hub_id']:
            return self._receive(state['hub_id'], request)
        return self.transport(pc, request)

    def _sync(self):
        state, document = self._snapshot()
        if not document['pcs'] or state['hub_id'] != document['coordinator_id']:
            return
        count = len(document['pcs'])
        start = document['cursor'] % count
        batch = [document['pcs'][(start + n) % count] for n in range(min(32, count))]
        request = {'action': 'sync', 'fleet_id': document['fleet_id'], 'policy': document['policy']}
        def visit(pc):
            try:
                result = self._call(state, document, pc, request)
                if result.get('id') != pc['id'] or result.get('fleet_id') != document['fleet_id']:
                    raise Error('update status identity changed')
                return pc['id'], {**result, 'seen_at': int(self.r.now())}
            except Exception:
                return pc['id'], None
        with ThreadPoolExecutor(max_workers=16) as executor:
            results = list(executor.map(visit, batch))
        with self.r.locked():
            state = self.r.load()
            current = self._load(state)
            if current['fleet_id'] != document['fleet_id']:
                return
            for pc_id, result in results:
                if result is None:
                    current['hosts'][pc_id] = {**current['hosts'].get(pc_id, {}), 'seen_at': 0,
                                                'state': 'unreachable', 'error': 'Waiting for this approved PC'}
                else:
                    current['hosts'][pc_id] = result
                    if (type(result.get('revision')) is int and type(result.get('enabled')) is bool
                            and result['revision'] > current['policy']['revision']):
                        current['policy'] = {'revision': result['revision'], 'enabled': result['enabled']}
            current['cursor'] = (start + len(batch)) % count
            self._save(current)

    def _all_ready(self, document):
        now = int(self.r.now())
        return all((host := document['hosts'].get(pc['id'], {})).get('revision') == document['policy']['revision']
                   and host.get('durable_policy_revision') == document['policy']['revision']
                   and host.get('enabled') == document['policy']['enabled']
                   and now - host.get('seen_at', 0) <= self._freshness(document)
                   and host.get('seen_at', now) - host.get('worker_seen', 0) <= 120 for pc in document['pcs'])

    def _advance(self):
        self._sync()
        state, document = self._snapshot()
        if state['hub_id'] != document['coordinator_id']:
            return
        with self.r.locked():
            state = self.r.load()
            document = self._load(state)
            tx = document['transaction']
            if (not tx or tx['phase'] in ('complete', 'failed')) and document['candidate'] and document['policy']['enabled']:
                if not self._all_ready(document):
                    document['message'] = 'Waiting for every approved PC to acknowledge the update policy.'
                    self._save(document)
                    return
                envelope = document['candidate']
                if digest(envelope) == document['failed_manifest']:
                    return
                tx = {'id': secrets.token_hex(16), 'manifest': envelope, 'manifest_digest': digest(envelope),
                      'phase': 'preparing', 'attempted': [], 'sent': {}, 'created_at': int(self.r.now())}
                document['transaction'], document['candidate'] = tx, None
                document['message'] = 'Preparing the same signed release on every approved PC.'
            if not tx or tx['phase'] in ('complete', 'failed'):
                self._save(document)
                return
            hosts = document['hosts']
            states = {pc['id']: hosts.get(pc['id'], {}).get('state') if hosts.get(pc['id'], {}).get('command', {}).get('id') == tx['id'] else None for pc in document['pcs']}
            failed = [pc_id for pc_id, value in states.items() if value in ('failed', 'rollback_failed', 'rolled_back')]
            if failed and tx['phase'] not in ('rolling_back', 'committing_failure'):
                tx['phase'] = 'rolling_back'
                document['failed_manifest'] = tx['manifest_digest']
                document['message'] = 'An update failed. Restoring matching images and state; later account changes and revocations may need review.'
            jobs = []
            if tx['phase'] == 'preparing' and not document['policy']['enabled']:
                tx['phase'] = 'committing_failure'
                document['message'] = 'Automatic updates disabled. Finishing preparation cleanup without applying this release.'
            if tx['phase'] == 'preparing':
                if all(value == 'ready' for value in states.values()) and self._all_ready(document):
                    tx['phase'] = 'applying'
                else:
                    jobs = [(pc, 'prepare') for pc in document['pcs'] if states[pc['id']] in (None, 'unreachable')]
            if tx['phase'] == 'applying':
                order = sorted(document['pcs'], key=lambda pc: (pc['id'] == document['coordinator_id'], pc['name'], pc['id']))
                pending = [pc for pc in order if states[pc['id']] != 'applied']
                if not pending:
                    tx['phase'] = 'committing'
                elif states[pending[0]['id']] == 'ready' and self._all_ready(document):
                    pc = pending[0]
                    # Durable intent precedes delivery: lost acknowledgments must
                    # still trigger rollback if this apply was accepted remotely.
                    if pc['id'] not in tx['attempted']:
                        tx['attempted'].append(pc['id'])
                    jobs = [(pc, 'apply')]
                    document['message'] = 'Updating ' + pc['name'] + '; the remaining PCs stay available.'
            if tx['phase'] == 'rolling_back':
                if any(states.get(pc_id) == 'rollback_failed' for pc_id in tx['attempted']):
                    document['message'] = 'Rollback needs attention. Automatic updates are frozen; inspect the affected PC.'
                jobs = [(pc, 'rollback') for pc in document['pcs'] if pc['id'] in tx['attempted']
                        and states[pc['id']] not in ('rolled_back', 'rolling_back', 'rollback_failed')]
                if all(states.get(pc_id) == 'rolled_back' for pc_id in tx['attempted']):
                    tx['phase'] = 'committing_failure'
            if tx['phase'] in ('committing', 'committing_failure'):
                # A committed report remains tied to the transaction, so retries
                # after coordinator restart do not replay an earlier update.
                if all(value == 'committed' or (value is None and pc_id not in tx['sent']) for pc_id, value in states.items()):
                    success = tx['phase'] == 'committing'
                    tx['phase'] = 'complete' if success else 'failed'
                    if success:
                        document['sequence'] = tx['manifest']['manifest']['sequence']
                    document['message'] = 'Every approved PC runs the same verified release.' if success else 'The failed release is frozen; the next signed release can be retried.'
                else:
                    jobs = [(pc, 'commit') for pc in document['pcs'] if states[pc['id']] in ('applied', 'rolled_back', 'ready', 'failed')
                            or tx['phase'] == 'committing_failure' and states[pc['id']] in (None, 'unreachable')]
            jobs = jobs[:32]
            for pc, action in jobs:
                tx['sent'][pc['id']] = action
            self._save(document)
        def deliver(job):
            pc, action = job
            request = {'action': 'command', 'fleet_id': document['fleet_id'], 'revision': document['policy']['revision'],
                       'command': {key: tx[key] for key in ('id', 'manifest', 'manifest_digest')}}
            request['command']['action'] = action
            try:
                result = self._call(state, document, pc, request)
            except Exception:
                return pc, action, None
            return pc, action, result
        with ThreadPoolExecutor(max_workers=16) as executor:
            results = list(executor.map(deliver, jobs))
        for pc, action, result in results:
            if result is None:
                continue
            with self.r.locked():
                current_state = self.r.load()
                current = self._load(current_state)
                if current['transaction'] and current['transaction']['id'] == tx['id']:
                    current['transaction']['sent'][pc['id']] = action
                    current['hosts'][pc['id']] = {**result, 'seen_at': int(self.r.now())}
                    self._save(current)

    def worker_poll(self):
        """Docker-root CLI only; deliberately absent from the hub socket."""
        with self.r.locked():
            state = self.r.load()
            document = self._load(state)
            document['local']['worker_seen'] = int(self.r.now())
            self._save(document)
        if document['coordinator_id'] == state['hub_id']:
            self._advance()
        state, document = self._snapshot()
        result = {'schema': 1, 'available': bool(document['pcs']), 'enabled': document['policy']['enabled'],
                  'coordinator': document['coordinator_id'] == state['hub_id'], 'revision': document['policy']['revision'],
                  'fleet_id': document['fleet_id'], 'check_interval_seconds': CHECK_INTERVAL,
                  'local': self._local_status(state, document), 'health': self.health(state)}
        if document['local'].get('command') and document['local'].get('state') != 'committed':
            result['command'] = document['local']['command']
        return result

    def worker_report(self, report):
        fields = {'action', 'id', 'manifest', 'manifest_digest', 'current_version', 'image', 'error', 'last_check', 'next_check', 'recovery_policy'}
        actions = {'heartbeat', 'discovered', 'ready', 'applied', 'failed', 'rolled_back', 'rollback_failed', 'committed', 'check'}
        if not isinstance(report, dict) or set(report) - fields or report.get('action') not in actions:
            raise Error('invalid fixed worker report')
        for key, maximum in (('error', 512), ('image', 80), ('current_version', 100)):
            if key in report and (not isinstance(report[key], str) or len(report[key]) > maximum or any(ord(c) < 32 or ord(c) == 127 for c in report[key])):
                raise Error('invalid public worker status')
        for key in ('last_check', 'next_check'):
            if key in report and (type(report[key]) is not int or not 0 <= report[key] <= 9007199254740991):
                raise Error('invalid worker check time')
        with self.r.locked():
            state = self.r.load()
            document = self._load(state)
            if 'recovery_policy' in report:
                policy = report['recovery_policy']
                if (not isinstance(policy, dict) or set(policy) != {'revision', 'enabled', 'fleet_id'}
                        or policy['fleet_id'] != document['fleet_id'] or type(policy['revision']) is not int
                        or not 0 <= policy['revision'] <= 9007199254740991 or type(policy['enabled']) is not bool):
                    raise Error('invalid recovered update policy')
                if policy['revision'] > document['policy']['revision']:
                    document['policy'] = {key: policy[key] for key in ('revision', 'enabled')}
                if policy['revision'] == document['policy']['revision']:
                    if policy['enabled'] != document['policy']['enabled']:
                        raise Error('recovered update policy conflicts at the same revision')
                    document['durable_policy_revision'] = policy['revision']
            local = document['local']
            local['worker_seen'] = int(self.r.now())
            action = report['action']
            if action == 'discovered':
                if document['coordinator_id'] != state['hub_id'] or not document['policy']['enabled']:
                    raise Error('only the enabled update coordinator may propose a release')
                envelope = manifest(report.get('manifest'))
                if envelope['manifest']['sequence'] > document['sequence'] and digest(envelope) != document['failed_manifest']:
                    document['candidate'] = envelope
            elif action not in ('heartbeat', 'check'):
                command = local.get('command')
                expected = {'prepare': {'ready', 'failed'}, 'apply': {'applied', 'failed', 'rolled_back'},
                            'rollback': {'rolled_back', 'rollback_failed'}, 'commit': {'committed', 'failed'}}
                if (not command or report.get('id') != command['id'] or report.get('manifest_digest') != command['manifest_digest']
                        or action not in expected[command['action']]):
                    raise Error('worker report does not match its pending release operation')
                local['state'] = action
                if action == 'rolled_back':
                    # Paired rollback restores the journal snapshot taken before
                    # apply. Its old command cannot invalidate the worker's
                    # exact transaction recovery acknowledgment.
                    local['command']['action'] = 'rollback'
                    document['failed_manifest'] = command['manifest_digest']
                    if document['transaction'] and document['transaction']['id'] == command['id']:
                        document['transaction']['phase'] = 'rolling_back'
                if action == 'applied':
                    document['sequence'] = max(document['sequence'], command['manifest']['manifest']['sequence'])
            elif not local.get('command'):
                local['state'] = 'idle'
            for key in ('current_version', 'image', 'error'):
                if key in report:
                    local[key] = report[key]
            if action not in ('failed', 'rollback_failed') and 'error' not in report:
                local.pop('error', None)
            for key in ('last_check', 'next_check'):
                if key in report:
                    document[key] = report[key]
            self._save(document)
            return {'accepted': True, 'state': local['state']}

    def health(self, state):
        """Public source progress with signed local-hub acknowledgment, no keys."""
        result = {'ready': False, 'publisher_expected': False}
        try:
            telemetry = self.r._telemetry()
            membership = telemetry.load(state)
            collector = membership.get('collector')
            if not collector or not collector.get('enabled'):
                return {**result, 'ready': True}
            result['publisher_expected'] = True
            source = collector['source']
            result.update(host_id=source['hostID'], generation=source['generation'])
            config = telemetry._read(self.r.base / 'publisher/config.json')
            path = self.r.base / collector['spool'] / 'state.json'
            descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(descriptor, 'rb') as stream:
                info = os.fstat(stream.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid not in (self.r.owner_uid, 10002) or info.st_mode & 0o022:
                    return result
                raw = stream.read(1024 * 1024 + 1)
            if len(raw) > 1024 * 1024:
                return result
            spool = json.loads(raw)
            envelope = spool['envelope']
            sequence = envelope['sequence']
            observed = datetime.datetime.fromisoformat(envelope['observedAt'].replace('Z', '+00:00'))
            if (envelope['hostID'] != source['hostID'] or envelope['generation'] != source['generation']
                    or type(sequence) is not int or observed.tzinfo is None
                    or not -120 <= self.r.now() - observed.timestamp() <= 90
                    or spool.get('probeConfigDigest') != digest(membership['probe'])
                    or spool.get('signedAcknowledged', {}).get(config['endpoints'][0]['url'], 0) < sequence):
                return result
            def count(containers):
                return sum((1 if item.get('matched') and not item.get('nested') else 0) + count(item.get('nested', [])) for item in containers)
            runtimes = envelope['target']['runtimes']
            if any(not runtime.get('available') or runtime.get('error') for runtime in runtimes):
                return result
            return {**result, 'ready': True, 'sequence': sequence, 'observed_at': envelope['observedAt'],
                    'current_hosts': sum(count(runtime.get('containers', [])) for runtime in runtimes)}
        except (OSError, ValueError, TypeError, KeyError, IndexError):
            return result
