#!/usr/bin/env python3
"""Fixed-purpose Docker update worker, separate from the unprivileged web hub.

The worker has daemon authority and therefore verifies owned launch specifications
before every operation. It accepts no executable, Docker arguments, path or URL
from the browser. Public downloads are confined to the installer repository.
"""
import argparse
import email.utils
import fcntl
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import random
import re
import shutil
import signal
import socket
import ssl
import stat
import subprocess
import tarfile
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

from dockerctl import Docker, Driver, Error, LABEL

REPOSITORY = 'MachoDrone/gridlens-installer'
CHANNEL_URL = 'https://api.github.com/repos/' + REPOSITORY + '/contents/channels/development.json?ref=main'
WORKER = '/usr/local/lib/gridlens/container_updates.py'
CHECK_INTERVAL = 120
MAX_ARCHIVE = 128 * 1024 * 1024
MAX_EXPANDED = 256 * 1024 * 1024
VERSION = re.compile(r'v[0-9]+\.[0-9]+\.[0-9]+(?:-[0-9A-Za-z.-]+)?')
HEX = re.compile(r'[a-f0-9]{64}')
HELPERS = {'docker_setup.py', 'dockerctl.py', 'container_runtime.py', 'container_probe.py',
           'container_onboarding.py', 'container_upgrade.py', 'container_access.py',
           'container_telemetry.py', 'docker_telemetry_setup.py', 'legacy_import.py',
           'container_updates.py', 'container_update_control.py'}
DOCS = {'ACCESS.md', 'CLUSTER_PROTOCOL.md', 'HUB_MONITOR.md', 'SECURITY.md', 'VALIDATION.md',
        'TROUBLESHOOTING.md', 'COORDINATOR.md', 'AUTOMATIC_UPDATES.md'}


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise Error('Duplicate update document field.')
        value[key] = item
    return value


def manifest(value):
    if (not isinstance(value, dict) or set(value) != {'schema', 'channel', 'sequence', 'minUpdaterProtocol', 'version', 'sourceCommit', 'artifacts'}
            or value['schema'] != 1 or value['channel'] != 'development'
            or type(value['sequence']) is not int or not 1 <= value['sequence'] <= 2 ** 53 - 1
            or type(value['minUpdaterProtocol']) is not int or value['minUpdaterProtocol'] != 1
            or not isinstance(value['version'], str) or not VERSION.fullmatch(value['version'])
            or not isinstance(value['sourceCommit'], str) or not re.fullmatch(r'[a-f0-9]{40}', value['sourceCommit'])
            or not isinstance(value['artifacts'], dict) or set(value['artifacts']) != {'amd64', 'arm64'}):
        raise Error('Invalid development update manifest.')
    for artifact in value['artifacts'].values():
        if (not isinstance(artifact, dict) or set(artifact) != {'sha256', 'size'}
                or not isinstance(artifact['sha256'], str) or not HEX.fullmatch(artifact['sha256'])
                or type(artifact['size']) is not int or not 1 <= artifact['size'] <= MAX_ARCHIVE):
            raise Error('Invalid pinned update artifact.')
    return value


def manifest_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()


def verify_envelope(value):
    if (not isinstance(value, dict) or set(value) != {'manifest', 'signature'}
            or not isinstance(value['signature'], str) or len(value['signature']) > 128):
        raise Error('Invalid signed update envelope.')
    manifest(value['manifest'])
    result = subprocess.run(['/usr/local/bin/gridlens', 'release', 'verify'],
                            input=json.dumps(value, sort_keys=True, separators=(',', ':')),
                            text=True, capture_output=True, timeout=10)
    if result.returncode:
        raise Error('The development manifest maintainer signature did not verify.')
    verified = json.loads(result.stdout, object_pairs_hook=unique_object)
    if verified != value['manifest']:
        raise Error('The verified update manifest did not match its envelope.')
    return verified


class Redirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, newurl):
        parsed = urllib.parse.urlsplit(newurl)
        if (parsed.scheme != 'https' or parsed.username or parsed.password or parsed.port not in (None, 443)
                or parsed.hostname not in {'github.com', 'release-assets.githubusercontent.com',
                                           'objects.githubusercontent.com', 'raw.githubusercontent.com'}):
            raise Error('Update download redirected outside the approved HTTPS distribution hosts.')
        return super().redirect_request(request, fp, code, message, headers, newurl)


class RateLimited(Error):
    def __init__(self, seconds):
        self.seconds = seconds
        super().__init__('GitHub requested a pause; automatic checks will retry after backoff.')


def fetch(url, limit, etag=None, destination=None, now=time.time, metadata=None):
    headers = {'User-Agent': 'GridLens-development-updater/1',
               'Accept': 'application/vnd.github.raw+json' if url == CHANNEL_URL else 'application/octet-stream'}
    if etag:
        if not isinstance(etag, str) or len(etag) > 256 or any(ord(c) < 32 for c in etag):
            raise Error('Invalid saved update validator.')
        headers['If-None-Match'] = etag
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), Redirects(),
                                         urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    try:
        response = opener.open(urllib.request.Request(url, headers=headers), timeout=30)
    except urllib.error.HTTPError as exc:
        if metadata is not None:
            metadata.update(dict(exc.headers.items()))
        exc.close()
        if exc.code == 304:
            return None, etag
        if exc.code in (403, 429):
            delay = 900
            retry = exc.headers.get('Retry-After', '')
            if retry.isdecimal():
                delay = max(delay, int(retry) if len(retry) <= 12 else 10 ** 12)
            elif retry:
                try:
                    delay = max(delay, int(email.utils.parsedate_to_datetime(retry).timestamp() - now()) + 1)
                except (TypeError, ValueError, OverflowError):
                    pass
            reset = exc.headers.get('X-RateLimit-Reset', '')
            if reset.isdecimal():
                delay = max(delay, (int(reset) if len(reset) <= 12 else 10 ** 12) - int(now()) + 60)
            raise RateLimited(delay) from None
        raise Error('The public update download is unavailable; the installed version was kept.') from None
    with response:
        if metadata is not None:
            metadata.update(dict(response.headers.items()))
        length = response.headers.get('Content-Length')
        if length and (not length.isdecimal() or int(length) > limit):
            raise Error('Update download exceeds its size limit.')
        stream = destination.open('xb') if destination else io.BytesIO()
        try:
            count, deadline = 0, time.monotonic() + 300
            while True:
                chunk = response.read1(min(65536, limit + 1 - count))
                if not chunk:
                    break
                count += len(chunk)
                if count > limit or time.monotonic() > deadline:
                    raise Error('Update download exceeded its size or time limit.')
                stream.write(chunk)
            if not count:
                raise Error('Empty update download.')
            result = stream.getvalue() if not destination else count
        finally:
            stream.close()
    validator = response.headers.get('ETag')
    if validator and (len(validator) > 256 or any(ord(c) < 32 for c in validator)):
        validator = None
    return result, validator


def extract_package(archive_path, destination, release, arch):
    """Validate all members before extraction; no links, source or arbitrary code."""
    artifact = manifest(release)['artifacts'][arch]
    if archive_path.stat().st_size != artifact['size']:
        raise Error('The pinned update archive size did not match.')
    digest = hashlib.sha256()
    with archive_path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(65536), b''):
            digest.update(chunk)
    if digest.hexdigest() != artifact['sha256']:
        raise Error('The pinned update archive checksum did not match.')
    plain = destination / 'archive.tar'
    with gzip.open(archive_path, 'rb') as source, plain.open('xb') as output:
        expanded = 0
        while True:
            chunk = source.read(65536)
            if not chunk:
                break
            expanded += len(chunk)
            if expanded > MAX_EXPANDED:
                raise Error('Expanded update archive exceeds its limit.')
            output.write(chunk)
    required = {'gridlens/RELEASE.json', 'gridlens/bin/gridlens', 'gridlens/container/Dockerfile',
                'gridlens/install.sh', *('gridlens/scripts/' + name for name in HELPERS)}
    allowed = {'gridlens/install.sh', 'gridlens/start.sh', 'gridlens/README.md', 'gridlens/LICENSE',
               'gridlens/THIRD_PARTY_NOTICES.txt', 'gridlens/container/README.md', *required,
               *('gridlens/scripts/' + name for name in HELPERS),
               *('gridlens/docs/' + name for name in DOCS)}
    directories = {'gridlens', 'gridlens/bin', 'gridlens/scripts', 'gridlens/container', 'gridlens/docs'}
    class BoundedReader:
        def __init__(self, stream):
            self.stream = stream
        def read(self, size=-1):
            if size < 0 or size > 1048576:
                raise Error('Update archive metadata exceeds its limit.')
            return self.stream.read(size)
        def seek(self, *args):
            return self.stream.seek(*args)
        def tell(self):
            return self.stream.tell()
    with plain.open('rb') as raw, tarfile.open(fileobj=BoundedReader(raw), mode='r:') as archive:
        members, names, regular, total = [], set(), set(), 0
        for member in archive:
            name = member.name.rstrip('/')
            total += member.size
            if (name in names or len(members) >= 512 or member.size < 0 or member.size > MAX_ARCHIVE
                    or total > MAX_EXPANDED or member.sparse is not None
                    or not ((member.isfile() and name in allowed) or (member.isdir() and name in directories))):
                raise Error('The update archive contains an unsafe or unapproved file.')
            names.add(name)
            members.append(member)
            if member.isfile():
                regular.add(name)
        if not required <= regular:
            raise Error('The update package is incomplete.')
        entry = archive.getmember('gridlens/RELEASE.json')
        if entry.size > 16384:
            raise Error('The release metadata exceeds its limit.')
        metadata = json.loads(archive.extractfile(entry).read(), object_pairs_hook=unique_object)
        if (metadata.get('schema') != 2 or metadata.get('installation') != 'docker'
                or metadata.get('version') != release['version'] or metadata.get('target') != 'linux/' + arch
                or metadata.get('sourceCommit') != release['sourceCommit'] or metadata.get('sourceDirty') is not False):
            raise Error('The update package does not match its clean pinned source and release.')
        for member in members:
            path = destination / member.name.rstrip('/')
            if member.isdir():
                path.mkdir(mode=0o700, parents=True, exist_ok=True)
                continue
            path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with path.open('xb') as output, archive.extractfile(member) as source:
                shutil.copyfileobj(source, output, 65536)
            os.chmod(path, 0o700 if path.name in ('gridlens', 'install.sh') else 0o600)
    plain.unlink()
    program = destination / 'gridlens/bin/gridlens'
    with program.open('rb') as stream:
        header = stream.read(64)
    if (len(header) != 64 or header[:6] != b'\x7fELF\x02\x01'
            or int.from_bytes(header[18:20], 'little') != {'amd64': 62, 'arm64': 183}[arch]):
        raise Error('The update program architecture did not match.')
    return destination / 'gridlens'


def atomic_json(path, value):
    payload = json.dumps(value, sort_keys=True).encode()
    if len(payload) > 1024 * 1024:
        raise Error('Update worker journal exceeds its limit.')
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix='.update-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
        directory = os.open(path.parent, os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(name):
            os.unlink(name)


class WorkerDriver(Driver):
    """Use the original host namespace attestation; never attest a worker's ns."""
    def __init__(self, docker, prefix, owner, host_namespace):
        if not re.fullmatch(r'[a-f0-9]{32}', owner) or not str(host_namespace).isdecimal():
            raise Error('The update worker needs its installed ownership and namespace attestation.')
        super().__init__(docker, '', prefix=prefix)
        self.expected_owner, self.host_namespace = owner, str(host_namespace)
        self.update_transaction_id = None

    def create_journal(self, transaction):
        if (not isinstance(self.update_transaction_id, str)
                or not re.fullmatch(r'[a-f0-9]{32}', self.update_transaction_id)
                or transaction.get('updater_transaction', self.update_transaction_id) != self.update_transaction_id):
            raise Error('An automatic Docker upgrade requires its exact fleet transaction identity.')
        # Persist the worker's transaction in Docker's atomic ownership journal,
        # not only in a separate worker volume. A terminal upgrade to the same
        # image must never be mistaken for a crash of this automatic attempt.
        transaction['updater_transaction'] = self.update_transaction_id
        super().create_journal(transaction)

    def existing_recipe(self):
        recipe = super().existing_recipe()
        if not recipe or recipe['owner'] != self.expected_owner:
            raise Error('The updater installation ownership changed.')
        return recipe

    def create_args(self, role, recipe):
        args = super().create_args(role, recipe)
        if role == 'core':
            args = ['GRIDLENS_HOST_NETNS=' + self.host_namespace
                    if arg.startswith('GRIDLENS_HOST_NETNS=') else arg for arg in args]
        return args

    def check_container(self, value, role, recipe):
        super().check_container(value, role, recipe)
        if role == 'core':
            env = dict(item.split('=', 1) for item in value['Config'].get('Env', []) if '=' in item)
            if env.get('GRIDLENS_HOST_NETNS') != self.host_namespace:
                raise Error('The original host namespace attestation changed.')


def updater_args(driver, recipe, host_namespace, replacement=None):
    args = ['create', '--name', driver.prefix + '-updater', '--restart', 'unless-stopped',
            '--read-only', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges=true',
            '--pids-limit', '96', '--memory', '512m', '--network', driver.names['network'],
            '--tmpfs', '/tmp:rw,nosuid,nodev,noexec,size=16m',
            '--env', 'GRIDLENS_OWNER=' + recipe['owner'], '--env', 'GRIDLENS_PREFIX=' + driver.prefix,
            '--env', 'GRIDLENS_HOST_NETNS=' + host_namespace,
            '--env', 'GRIDLENS_UPDATER_IMAGE=' + recipe['image'],
            *driver.labels('updater', recipe['owner']),
            '--label', LABEL + '.updater-image=' + recipe['image'],
            '--mount', 'type=volume,src=' + driver.prefix + '-updates,dst=/updates',
            '--mount', 'type=bind,src=/var/run/docker.sock,dst=/var/run/docker.sock,readonly',
            '--entrypoint', '/usr/bin/python3', recipe['image'], '-B', WORKER, 'run']
    if replacement:
        args[1:1] = ['--label', LABEL + '.updater-replacement=' + replacement]
    return args


def ensure_updater(driver, start=True):
    """Installer-only provisioning; preserves the independent worker on upgrades."""
    recipe = driver.existing_recipe()
    driver.preflight(recipe)
    image = driver.inspect('image', recipe['image'])
    if (not image or image.get('Id') != recipe['image']
            or (image.get('Config', {}).get('Labels') or {}).get(LABEL + '.updater-protocol') != '1'):
        raise Error('Install a verified image with updater protocol 1 before provisioning automatic updates.')
    core = driver.inspect('container', driver.names['core'])
    environment = dict(item.split('=', 1) for item in core['Config'].get('Env', []) if '=' in item)
    namespace = environment.get('GRIDLENS_HOST_NETNS', '')
    if not namespace.isdecimal():
        raise Error('The installed core has no valid host namespace attestation.')
    volume = driver.inspect('volume', driver.prefix + '-updates')
    worker = driver.inspect('container', driver.prefix + '-updater')
    if volume:
        driver.verify(volume, 'updates', recipe['owner'])
    if worker:
        labels = driver.verify(worker, 'updater', recipe['owner'])
        cfg, host = worker.get('Config', {}), worker.get('HostConfig', {})
        env = dict(item.split('=', 1) for item in cfg.get('Env', []) if '=' in item)
        mounts = {item['Destination']: (item['Type'], item.get('Name') if item['Type'] == 'volume' else item['Source'], item['RW'])
                  for item in worker.get('Mounts', []) if item['Type'] != 'tmpfs'}
        if (worker.get('Image') != labels.get(LABEL + '.updater-image')
                or not host.get('ReadonlyRootfs') or host.get('Privileged') or host.get('PidMode')
                or host.get('NetworkMode') != driver.names['network'] or host.get('PortBindings')
                or set(host.get('CapDrop') or []) != {'ALL'} or host.get('CapAdd')
                or host.get('Devices') or host.get('DeviceRequests') or host.get('VolumesFrom')
                or cfg.get('User', '') not in ('', '0', '0:0')
                or cfg.get('Entrypoint') != ['/usr/bin/python3'] or cfg.get('Cmd') != ['-B', WORKER, 'run']
                or env.get('GRIDLENS_OWNER') != recipe['owner'] or env.get('GRIDLENS_PREFIX') != driver.prefix
                or env.get('GRIDLENS_HOST_NETNS') != namespace
                or env.get('GRIDLENS_UPDATER_IMAGE') != worker.get('Image')
                or any(key.startswith(('LD_', 'PYTHONPATH', 'PYTHONHOME')) for key in env)
                or not any(option.replace('=', ':') == 'no-new-privileges:true' for option in host.get('SecurityOpt', []))
                or host.get('RestartPolicy', {}).get('Name') != 'unless-stopped'
                or mounts != {'/updates': ('volume', driver.prefix + '-updates', True),
                              '/var/run/docker.sock': ('bind', '/var/run/docker.sock', False)}):
            raise Error('The owned update worker isolation changed.')
    if not volume:
        driver.docker.call(['volume', 'create', *driver.labels('updates', recipe['owner']), driver.prefix + '-updates'])
    if not worker:
        driver.docker.call(updater_args(driver, recipe, namespace))
    if start and (not worker or not worker.get('State', {}).get('Running')):
        driver.docker.call(['start', driver.prefix + '-updater'])
    return {'installed': True, 'container': driver.prefix + '-updater', 'channel': 'development'}


def check_delay(headers, now, failure_count=0):
    """One elected checker reserves quota for other clients sharing the public IP."""
    normalized = {key.lower(): value for key, value in headers.items()}
    delay = CHECK_INTERVAL
    interval = normalized.get('x-poll-interval', '')
    if interval.isdecimal():
        delay = max(delay, int(interval) if len(interval) <= 12 else 10 ** 12)
    remaining = normalized.get('x-ratelimit-remaining', '')
    reset = normalized.get('x-ratelimit-reset', '')
    if remaining.isdecimal() and reset.isdecimal():
        period = max(0, (int(reset) if len(reset) <= 12 else 10 ** 12) - int(now)) + 15
        budget = (int(remaining) if len(remaining) <= 12 else 0) - 10
        delay = max(delay, period if budget <= 0 else (period + budget - 1) // budget)
    if failure_count:
        delay = max(delay, min(3600, CHECK_INTERVAL * 2 ** min(failure_count, 5)))
    return delay + random.SystemRandom().randint(1, 20)


def build_image(driver, package, release, arch):
    # Use only reviewed runtime inputs; docs and terminal scripts are not Docker
    # context. The same mapping/fingerprint is used by the public coordinator.
    mapping = {'bin/gridlens': 'gridlens', 'container/Dockerfile': 'Dockerfile'}
    for helper in ('container_runtime.py', 'container_probe.py', 'container_upgrade.py',
                   'container_access.py', 'container_telemetry.py', 'dockerctl.py',
                   'container_updates.py', 'container_update_control.py'):
        source = package / 'scripts' / helper
        if source.is_file():
            mapping['scripts/' + helper] = helper
    digest = hashlib.sha256()
    for relative in sorted(mapping):
        digest.update(relative.encode() + b'\0')
        with (package / relative).open('rb') as stream:
            for chunk in iter(lambda: stream.read(65536), b''):
                digest.update(chunk)
    fingerprint = digest.hexdigest()
    tag = 'gridlens-local:' + fingerprint[:32] + '-' + arch
    existing = driver.inspect('image', tag)
    if existing:
        labels = existing.get('Config', {}).get('Labels') or {}
        if labels.get(LABEL + '.image-content') != fingerprint or labels.get(LABEL + '.version') != release['version']:
            raise Error('The staged update image tag belongs to different content.')
        return existing['Id']
    with tempfile.TemporaryDirectory(prefix='build-', dir=package.parent) as directory:
        for source, name in mapping.items():
            shutil.copyfile(package / source, Path(directory) / name)
        driver.docker.call(['build', '--platform', 'linux/' + arch, '--tag', tag,
                            '--label', LABEL + '.image-content=' + fingerprint,
                            '--label', LABEL + '.version=' + release['version'], directory], timeout=1800)
    value = driver.inspect('image', tag)
    if (not value or not re.fullmatch(r'sha256:[a-f0-9]{64}', value.get('Id', ''))
            or (value.get('Config', {}).get('Labels') or {}).get(LABEL + '.image-content') != fingerprint):
        raise Error('The staged Docker image did not match the verified release.')
    return value['Id']


class Worker:
    def __init__(self, driver, base=Path('/updates'), now=time.time):
        self.driver, self.base, self.now = driver, Path(base), now
        self.instance = socket.gethostname()
        self.path = self.base / 'worker.json'
        self.base.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.document = {'schema': 1, 'owner': driver.expected_owner, 'last_sequence': 0,
                         'next_check': 0, 'failures': 0}
        if self.path.exists() or self.path.is_symlink():
            info = self.path.lstat()
            if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077 or info.st_size > 1024 * 1024:
                raise Error('Unsafe update worker journal.')
            self.document = json.loads(self.path.read_text(), object_pairs_hook=unique_object)
            if self.document.get('schema') != 1 or self.document.get('owner') != driver.expected_owner:
                raise Error('Update worker ownership changed.')
        recovery = self.document.get('engine_recovery')
        if recovery and recovery.get('retained_image') != os.environ.get('GRIDLENS_UPDATER_IMAGE'):
            self.document.pop('engine_recovery', None)
            self.save()

    def save(self):
        atomic_json(self.path, self.document)

    def current_version(self):
        recipe = self.driver.existing_recipe()
        image = self.driver.inspect('image', recipe['image'])
        return ((image or {}).get('Config', {}).get('Labels') or {}).get(LABEL + '.version', '')

    def report(self, action, **values):
        if 'error' in values:
            values['error'] = ''.join(char if ord(char) >= 32 and ord(char) != 127 else ' '
                                      for char in values['error'])[:500]
        if action in ('rolled_back', 'heartbeat') and self.document.get('recovery_policy'):
            values['recovery_policy'] = self.document['recovery_policy']
        return self.driver.runtime('updates-worker-report', {'action': action, 'current_version': self.current_version(), **values})

    def remember_policy(self, poll):
        policy = {key: poll.get(key) for key in ('revision', 'enabled', 'fleet_id')}
        if (type(policy['revision']) is not int or policy['revision'] < 0
                or type(policy['enabled']) is not bool or not isinstance(policy['fleet_id'], str)
                or not HEX.fullmatch(policy['fleet_id'])):
            return
        previous = self.document.get('recovery_policy')
        if previous and previous['fleet_id'] == policy['fleet_id'] and previous['revision'] > policy['revision']:
            policy = previous
        if previous != policy:
            self.document['recovery_policy'] = policy
            self.save()
        # This acknowledgment follows atomic file+directory fsync. The GUI may
        # acknowledge a policy change only after it survives paired core rollback.
        self.report('heartbeat')

    def check(self):
        now, headers = int(self.now()), {}
        # Commit the next request time BEFORE opening a socket: restart loops
        # cannot repeatedly consume GitHub's shared unauthenticated quota.
        self.document['next_check'] = now + CHECK_INTERVAL + random.SystemRandom().randint(1, 20)
        self.save()
        try:
            data, etag = fetch(CHANNEL_URL, 65536, self.document.get('etag'), metadata=headers)
            if data is not None:
                envelope = json.loads(data, object_pairs_hook=unique_object)
                release = verify_envelope(envelope)
                digest = manifest_digest(envelope)
                if release['sequence'] < self.document['last_sequence']:
                    raise Error('The update channel sequence moved backwards; the installed version was kept.')
                if (release['sequence'] == self.document['last_sequence'] and self.document.get('last_digest')
                        and digest != self.document['last_digest']):
                    raise Error('The same update sequence changed content; the installed version was kept.')
                self.document.update(last_sequence=release['sequence'], last_digest=digest,
                                     envelope=envelope, etag=etag)
            self.document.update(failures=0, last_check=now,
                                 next_check=now + check_delay(headers, now))
            self.save()
            # Re-send the cached manifest after a lost acknowledgment or core
            # restart, including on HTTP 304; a release is never lost to ETag.
            if self.document.get('envelope'):
                self.report('discovered', manifest=self.document['envelope'], last_check=now,
                            next_check=self.document['next_check'])
            else:
                self.report('check', last_check=now, next_check=self.document['next_check'])
        except (Error, OSError, ValueError, subprocess.SubprocessError) as exc:
            self.document['failures'] += 1
            delay = exc.seconds if isinstance(exc, RateLimited) else check_delay(headers, now, self.document['failures'])
            self.document.update(last_check=now, next_check=now + delay)
            self.save()
            self.report('check', last_check=now, next_check=self.document['next_check'],
                        error=str(exc)[:500])

    def prepare(self, command):
        envelope = command['manifest']
        release = verify_envelope(envelope)
        digest = manifest_digest(envelope)
        if digest != command['manifest_digest']:
            raise Error('The coordinated release digest did not match.')
        # An older/rewritten channel must not replace a newer installed runtime.
        from container_update_control import release_order
        if release_order(release['version'], self.current_version()) < 0:
            raise Error('Automatic updates cannot downgrade the installed release.')
        arch = {'x86_64': 'amd64', 'aarch64': 'arm64', 'amd64': 'amd64', 'arm64': 'arm64'}.get(platform.machine())
        if not arch:
            raise Error('Automatic updates support Linux amd64 and arm64.')
        self.prune_cache(digest)
        if shutil.disk_usage(self.base).free < 1024 ** 3 + 4 * release['artifacts'][arch]['size']:
            raise Error('Automatic update paused: free Docker-volume space is below the staging reserve. Retained image/state backups were preserved.')
        cache = self.base / ('release-' + digest)
        package = cache / 'gridlens'
        completed = cache / 'verified.json'
        if completed.is_file():
            if json.loads(completed.read_text()) != {'digest': digest, 'architecture': arch}:
                raise Error('The saved verified update cache changed.')
        else:
            if cache.exists():
                shutil.rmtree(cache)
            cache.mkdir(mode=0o700)
            archive = cache / 'installer.tar.gz'
            url = ('https://github.com/' + REPOSITORY + '/releases/download/' + release['version']
                   + '/gridlens-linux-' + arch + '.tar.gz')
            fetch(url, release['artifacts'][arch]['size'], destination=archive)
            package = extract_package(archive, cache, release, arch)
            atomic_json(completed, {'digest': digest, 'architecture': arch})
        image = build_image(self.driver, package, release, arch)
        self.driver.upgrade_status(image)
        self.document['job'] = {'id': command['id'], 'digest': digest, 'image': image,
                                'manifest': envelope, 'state': 'ready'}
        self.save()
        self.report('ready', id=command['id'], manifest_digest=digest, image=image)

    def prune_cache(self, upcoming):
        keep = {upcoming, *(self.document.get('retained_caches') or [])}
        if self.document.get('job', {}).get('digest'):
            keep.add(self.document['job']['digest'])
        for path in self.base.iterdir():
            match = re.fullmatch(r'release-([a-f0-9]{64})', path.name)
            if not match or match[1] in keep:
                continue
            info = path.lstat()
            if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
                raise Error('An update cache directory changed ownership or permissions; it was retained.')
            # This is only the worker's disposable public archive/cache. Never
            # remove Docker images, state backups, profiles or identities here.
            shutil.rmtree(path)

    @staticmethod
    def advanced(before, after):
        if not before.get('publisher_expected'):
            return after.get('ready') is True
        return (after.get('ready') is True and after.get('host_id') == before.get('host_id')
                and after.get('generation') == before.get('generation')
                and type(after.get('sequence')) is int and after['sequence'] > before.get('sequence', 0)
                and after.get('observed_at', '') > before.get('observed_at', '')
                and after.get('current_hosts') == before.get('current_hosts'))

    def apply(self, command, poll):
        job = self.document.get('job')
        if not job or job['id'] != command['id'] or job['digest'] != command['manifest_digest']:
            raise Error('The release has not been prepared for this exact fleet transaction.')
        if job['state'] == 'applied':
            self.report('applied', id=job['id'], manifest_digest=job['digest'], image=job['image'])
            return
        recipe = self.driver.existing_recipe()
        if job['state'] == 'applying':
            before = job['before_health']
            if recipe['image'] == job['before_image']:
                # A crash before starting or after Driver's own rollback is
                # conservatively recovered. Do not retry a rejected image.
                job['state'] = 'rolled_back'
                self.save()
                self.report('rolled_back', id=job['id'], manifest_digest=job['digest'],
                            error='The interrupted update retained or restored its previous image and state.')
                return
            if recipe['image'] != job['image']:
                raise Error('A different maintenance operation changed the installed image during this update.')
            # Resume only health verification. Keep the original baseline and
            # backup reference; never rebase rollback onto the new image.
            transaction = (self.driver._metadata or {}).get('rollback')
            if (not transaction or transaction['old']['image'] != job['before_image']
                    or transaction['new']['image'] != job['image']
                    or transaction.get('updater_transaction') != job['id']
                    or transaction['backup'] == job.get('prior_backup')):
                raise Error('The completed image replacement has no matching retained state backup.')
            job['backup'] = transaction['backup']
            self.save()
        else:
            before = poll.get('health', {})
            if before.get('ready') is not True:
                raise Error('The current local collector is not healthy enough to establish upgrade preservation.')
            job.update(state='applying', before_health=before, before_image=recipe['image'],
                       prior_backup=((self.driver._metadata or {}).get('rollback') or {}).get('backup'))
            self.save()
            self.driver.update_transaction_id = job['id']
            result = self.driver.upgrade(job['image'])
            job['backup'] = result.get('backupVolume')
            self.save()
        deadline = time.monotonic() + 150
        while time.monotonic() < deadline:
            polled = self.driver.runtime('updates-worker-poll')
            self.remember_policy(polled)
            after = polled.get('health', {})
            if self.advanced(before, after):
                job.update(state='applied', after_health=after)
                self.save()
                self.report('applied', id=job['id'], manifest_digest=job['digest'], image=job['image'])
                return
            time.sleep(3)
        raise Error('The new local collector did not advance signed observations with preserved identity and host coverage.')

    def rollback(self, command):
        job = self.document.get('job')
        if not job or job['id'] != command['id']:
            raise Error('No matching automatic update is available to roll back.')
        if job['state'] == 'rolled_back':
            self.report('rolled_back', id=job['id'], manifest_digest=job['digest'])
            return
        recipe = self.driver.existing_recipe()
        if not self.driver._pending:
            try:
                self.remember_policy(self.driver.runtime('updates-worker-poll'))
            except (Error, OSError, ValueError, subprocess.SubprocessError):
                pass
        if recipe['image'] == job.get('before_image') and not self.driver._pending:
            # Driver.upgrade may already have restored this exact image/state.
            # Its older retained rollback is unrelated and must not be replayed.
            pass
        elif self.driver._pending or recipe['image'] == job.get('image'):
            transaction = self.driver._pending or (self.driver._metadata or {}).get('rollback')
            if (not transaction or transaction['new']['image'] != job.get('image')
                    or transaction['old']['image'] != job.get('before_image')
                    or transaction.get('updater_transaction') != job['id']
                    or transaction['backup'] == job.get('prior_backup')
                    or (job.get('backup') and transaction['backup'] != job['backup'])):
                raise Error('The retained rollback does not match this automatic update.')
            self.driver.update_transaction_id = job['id']
            self.driver.rollback_upgrade()
        else:
            raise Error('The installed image changed outside this automatic update; its rollback was retained for review.')
        job['state'] = 'rolled_back'
        self.save()
        self.report('rolled_back', id=job['id'], manifest_digest=job['digest'])

    def step(self):
        # Clear Driver's metadata cache between polls so terminal maintenance
        # cannot leave this long-lived worker acting on stale launch metadata.
        self.driver._metadata_checked, self.driver._metadata, self.driver._pending = False, None, None
        self.driver.existing_recipe()
        if self.driver._pending:
            job = self.document.get('job')
            if not job or job['state'] not in ('applying', 'failed') or self.driver._pending['new']['image'] != job['image']:
                raise Error('A separate terminal upgrade requires its operator recovery; the updater is waiting.')
            self.rollback({'id': job['id'], 'manifest_digest': job['digest']})
        poll = self.driver.runtime('updates-worker-poll')
        self.remember_policy(poll)
        recovery = self.document.get('engine_recovery')
        self.report('heartbeat', **({'error': 'The update worker restored its previous verified engine after replacement failed.'} if recovery else {}))
        # Only an acknowledged controller round trip marks this engine healthy.
        # The replacement helper checks the exact new Docker container identity.
        self.document['heartbeat'] = {'container': self.instance, 'at': int(self.now())}
        self.save()
        command = poll.get('command')
        if command:
            if (not isinstance(command, dict) or not re.fullmatch(r'[a-f0-9]{32}', command.get('id', ''))
                    or not isinstance(command.get('manifest_digest'), str) or not HEX.fullmatch(command['manifest_digest'])
                    or command.get('action') not in ('prepare', 'apply', 'rollback', 'commit')):
                raise Error('Invalid fixed update worker command.')
            try:
                if command['action'] == 'prepare':
                    job = self.document.get('job')
                    cooldown = self.document.get('download_cooldown', {})
                    if cooldown.get('id') == command['id'] and self.now() < cooldown.get('until', 0):
                        self.report('heartbeat', error='GitHub requested a download pause; this prepared fleet will retry after backoff.')
                    elif job and job['id'] == command['id'] and job['state'] == 'failed':
                        self.report('failed', id=job['id'], manifest_digest=job['digest'],
                                    error=job.get('error', 'This update attempt failed; the coordinator must choose recovery.'))
                    elif job and job['id'] == command['id'] and job['state'] == 'ready':
                        self.report('ready', id=job['id'], manifest_digest=job['digest'], image=job['image'])
                    else:
                        self.prepare(command)
                elif command['action'] == 'apply':
                    job = self.document.get('job')
                    if job and job['id'] == command['id'] and job['state'] in ('failed', 'rolled_back'):
                        self.report(job['state'], id=job['id'], manifest_digest=job['digest'],
                                    error=job.get('error', 'The update did not complete; its recovery status is retained.'))
                    else:
                        self.apply(command, poll)
                elif command['action'] == 'rollback':
                    self.rollback(command)
                else:
                    job = self.document.get('job')
                    if job:
                        if job['state'] == 'applied':
                            retained = self.document.get('retained_caches') or []
                            self.document['retained_caches'] = [job['digest'], *[item for item in retained if item != job['digest']]][:2]
                        job['state'] = 'committing'
                        self.save()
                    self.report('committed', id=command['id'], manifest_digest=command['manifest_digest'])
                    if job:
                        job['state'] = 'committed'
                        self.save()
                    self.refresh_engine()
                    self.document.pop('job', None)
                    self.save()
            except (Error, OSError, ValueError, subprocess.SubprocessError) as exc:
                if isinstance(exc, RateLimited) and command['action'] == 'prepare':
                    self.document['download_cooldown'] = {'id': command['id'], 'until': int(self.now()) + exc.seconds}
                    self.save()
                    self.report('heartbeat', error=str(exc))
                    return
                job = self.document.get('job')
                if not job or job['id'] != command['id']:
                    job = {'id': command['id'], 'digest': command['manifest_digest']}
                    self.document['job'] = job
                job['state'] = 'rollback_failed' if command['action'] == 'rollback' else 'failed'
                job['error'] = str(exc)[-500:]
                if command['action'] == 'apply' and job.get('before_image'):
                    try:
                        restored = self.driver.existing_recipe()
                        if (not self.driver._pending and restored['image'] == job['before_image']
                                and job['before_image'] != job.get('image')):
                            job['state'] = 'rolled_back'
                    except (Error, OSError, ValueError):
                        pass
                self.save()
                self.report(job['state'],
                            id=command['id'], manifest_digest=command['manifest_digest'], error=str(exc)[-500:])
        else:
            if self.document.get('job') and poll.get('local', {}).get('state') == 'committed':
                self.refresh_engine()
                self.document.pop('job', None)
                self.save()
            if poll.get('enabled') and poll.get('coordinator') and self.now() >= self.document.get('next_check', 0):
                self.check()

    def refresh_engine(self):
        """Prepare a detached owned helper before replacing this worker process."""
        recipe = self.driver.existing_recipe()
        worker = self.driver.inspect('container', self.driver.prefix + '-updater')
        if not worker or worker.get('Image') == recipe['image']:
            return
        ensure_updater(self.driver)
        name = self.driver.prefix + '-updater-refresh'
        previous = self.driver.inspect('container', name)
        if previous:
            self.driver.verify(previous, 'updater-refresh', recipe['owner'])
            if previous.get('State', {}).get('Running'):
                return
            self.driver.docker.call(['rm', name])
        self.driver.docker.call(['run', '--detach', '--name', name, '--restart', 'on-failure:5',
            '--network', 'none', '--read-only', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges=true',
            '--pids-limit', '32', '--memory', '128m', *self.driver.labels('updater-refresh', recipe['owner']),
            '--env', 'GRIDLENS_OWNER=' + recipe['owner'], '--env', 'GRIDLENS_PREFIX=' + self.driver.prefix,
            '--env', 'GRIDLENS_HOST_NETNS=' + self.driver.host_namespace,
            '--env', 'GRIDLENS_PREVIOUS_WORKER=' + worker['Id'],
            '--env', 'GRIDLENS_PREVIOUS_WORKER_IMAGE=' + worker['Image'],
            '--mount', 'type=volume,src=' + self.driver.prefix + '-updates,dst=/updates',
            '--mount', 'type=bind,src=/var/run/docker.sock,dst=/var/run/docker.sock,readonly',
            '--entrypoint', '/usr/bin/python3', recipe['image'], '-B', WORKER, 'replace'])


def worker_heartbeat(driver, container_id, base=Path('/updates'), timeout=60):
    deadline, started = time.monotonic() + timeout, time.monotonic()
    while time.monotonic() < deadline:
        value = driver.inspect('container', driver.prefix + '-updater')
        if not value or value.get('Id') != container_id or not value.get('State', {}).get('Running'):
            raise Error('The replacement update worker exited before acknowledging its controller.')
        path = base / 'worker.json'
        try:
            info = path.lstat()
            if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077 or info.st_size > 1024 * 1024:
                raise Error('The replacement worker journal is unsafe.')
            document = json.loads(path.read_text(), object_pairs_hook=unique_object)
            heartbeat = document.get('heartbeat', {})
            if (document.get('owner') == driver.expected_owner
                    and heartbeat.get('container') == container_id[:12]
                    and type(heartbeat.get('at')) is int and time.time() - heartbeat['at'] <= 30
                    and time.monotonic() - started >= 3):
                return
        except FileNotFoundError:
            pass
        time.sleep(.25)
    raise Error('The replacement update worker did not acknowledge its controller before the deadline.')


def replace_worker(driver, base=Path('/updates')):
    recipe = driver.existing_recipe()
    driver.preflight(recipe)
    name = driver.prefix + '-updater'
    worker = driver.inspect('container', name)
    previous = os.environ.get('GRIDLENS_PREVIOUS_WORKER', '')
    old_image = os.environ.get('GRIDLENS_PREVIOUS_WORKER_IMAGE', '')
    if not re.fullmatch(r'[a-f0-9]{64}', previous) or not re.fullmatch(r'sha256:[a-f0-9]{64}', old_image):
        raise Error('The updater replacement requires one exact previous container.')
    if worker and worker['Id'] != previous:
        # Retry only this helper's marked replacement. A separate installer
        # repair or another helper's valid new worker must never be stopped.
        ensure_updater(driver, start=False)
        if (worker['Config']['Labels'].get(LABEL + '.updater-replacement') != previous
                or worker['Image'] not in (old_image, recipe['image'])):
            return
        try:
            if worker['Image'] == old_image and not worker.get('State', {}).get('Running'):
                driver.docker.call(['start', worker['Id']])
            worker_heartbeat(driver, worker['Id'], base)
            return
        except Error:
            if worker['Image'] == old_image:
                raise
    elif worker:
        ensure_updater(driver, start=False)
        if worker['Image'] != old_image:
            raise Error('The previous worker image changed; no process was stopped.')
        driver.docker.call(['stop', '--time', '30', worker['Id']])
        driver.docker.call(['rm', worker['Id']])
        worker = None
    try:
        if not worker:
            driver.docker.call(updater_args(driver, recipe, driver.host_namespace, replacement=previous))
            worker = driver.inspect('container', name)
        driver.docker.call(['start', worker['Id']])
        worker_heartbeat(driver, worker['Id'], base)
    except Exception:
        current = driver.inspect('container', name)
        if current:
            driver.verify(current, 'updater', recipe['owner'])
            if (current['Config']['Labels'].get(LABEL + '.updater-replacement') != previous
                    or current['Image'] != recipe['image']):
                raise Error('Another worker owns this name; automatic engine recovery was stopped.') from None
            if current.get('State', {}).get('Running'):
                driver.docker.call(['stop', '--time', '30', current['Id']])
            driver.docker.call(['rm', current['Id']])
        path = base / 'worker.json'
        document = json.loads(path.read_text(), object_pairs_hook=unique_object) if path.is_file() else {'schema': 1, 'owner': driver.expected_owner}
        document['engine_recovery'] = {'retained_image': old_image, 'target_image': recipe['image']}
        atomic_json(path, document)
        driver.docker.call(updater_args(driver, {**recipe, 'image': old_image}, driver.host_namespace, replacement=previous))
        restored = driver.inspect('container', name)
        driver.docker.call(['start', restored['Id']])
        worker_heartbeat(driver, restored['Id'], base)
        print('GridLens restored the previous verified update worker after engine replacement failed.', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('run', 'replace'))
    args = parser.parse_args()
    driver = WorkerDriver(Docker(), os.environ.get('GRIDLENS_PREFIX', ''),
                          os.environ.get('GRIDLENS_OWNER', ''), os.environ.get('GRIDLENS_HOST_NETNS', ''))
    if args.command == 'replace':
        replace_worker(driver)
        return
    worker = Worker(driver)
    stopping = False
    def stop(_signum, _frame):
        nonlocal stopping
        stopping = True
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    # Exclusive persistent volume lock prevents two daemon workers consuming a
    # policy or GitHub quota concurrently during recovery/replacement.
    with (worker.base / 'worker.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        while not stopping:
            try:
                worker.step()
            except Exception:
                # No exception payload from Docker/state should enter logs;
                # public operation errors are surfaced through bounded reports.
                print('GridLens updater is waiting for its owned controller or recovery.', flush=True)
            for _ in range(10):
                if stopping:
                    break
                time.sleep(.5)


if __name__ == '__main__':
    main()
