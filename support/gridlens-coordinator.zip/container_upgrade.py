#!/usr/bin/env python3
"""Offline named-volume launch metadata and consistent Docker upgrade snapshots.

The controller supplies this stdlib helper to an isolated container, including
when the old image predates this file. No state or key material leaves volumes.
"""
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import tempfile

METADATA = '.gridlens-launch.json'


def regular_tree(path):
    for root, dirs, files in os.walk(path, followlinks=False):
        for name in dirs + files:
            mode = (Path(root) / name).lstat().st_mode
            if not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
                raise ValueError('Upgrade state contains a symbolic link or special file.')


def read_metadata(base):
    path = base / METADATA
    if not path.exists() and not path.is_symlink():
        return None
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077 or info.st_size > 65536:
        raise ValueError('Unsafe launch metadata.')
    value = json.loads(path.read_text())
    if not isinstance(value, dict) or value.get('version') not in (1, 2, 3, 4) or not isinstance(value.get('recipe'), dict):
        raise ValueError('Unsupported launch metadata.')
    return value


def write_metadata(base, value):
    if value.get('version') not in (1, 2, 3, 4) or len(json.dumps(value)) > 65536:
        raise ValueError('Invalid launch metadata.')
    read_metadata(base)
    # Retained installers reject metadata versions beyond their supported schema.
    # Advance that existing barrier with the state schema, before a future old
    # installer can stop writers or replace a rollback reference. Restoring an
    # old snapshot naturally writes metadata version 1 again.
    marker = base / 'control/state.json'
    if marker.exists() or marker.is_symlink():
        info = marker.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise ValueError('Unsafe container state marker.')
        if info.st_size > 16 * 1024 * 1024:
            raise ValueError('Container state exceeds its size limit.')
        schema = json.loads(marker.read_text()).get('version')
        if type(schema) is not int or schema not in (1, 2, 3, 4):
            raise ValueError('Incompatible container state version.')
        value = {**value, 'version': schema}
    fd, name = tempfile.mkstemp(prefix='.gridlens-launch-', dir=base)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(value, stream, sort_keys=True)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, base / METADATA)
        directory = os.open(base, os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def copy_owned(source, destination):
    regular_tree(source)
    shutil.copytree(source, destination, copy_function=shutil.copy2)
    for root, dirs, files in os.walk(source):
        for item in [Path(root), *(Path(root) / name for name in dirs + files)]:
            target = destination / item.relative_to(source)
            info = item.stat()
            if os.geteuid() == 0:
                os.chown(target, info.st_uid, info.st_gid)
            os.chmod(target, stat.S_IMODE(info.st_mode))
    # Persist copied bytes before committing the backup completion marker.
    for root, _, files in os.walk(destination):
        for name in files:
            with (Path(root) / name).open('rb') as stream:
                os.fsync(stream.fileno())
        directory = os.open(root, os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)


def operate(action, request, state=Path('/state'), backup=Path('/backup'), observations=Path('/observations')):
    if action == 'read':
        version = None
        marker = state / 'control/state.json'
        if marker.exists() or marker.is_symlink():
            info = marker.lstat()
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid()
                    or info.st_mode & 0o077 or info.st_size > 16 * 1024 * 1024):
                raise ValueError('Unsafe container state marker.')
            version = json.loads(marker.read_text()).get('version')
            if type(version) is not int or version < 1:
                raise ValueError('Invalid container state version.')
        return {'metadata': read_metadata(state), 'state_version': version}
    if action == 'write':
        write_metadata(state, request['metadata'])
        return {'written': True}
    if action == 'collector-abort':
        # Fixed recovery for an exited supervisor: no network, Docker socket,
        # caller-selected path or executable is available in this helper.
        sys.path.insert(0, '/usr/local/lib/gridlens')
        from container_runtime import Runtime
        if set(request) != {'generation'}:
            raise ValueError('Collector recovery requires one exact generation.')
        return Runtime(guard=lambda _=False: None)._telemetry().abort(request['generation'])
    if action == 'pause':
        path = state / '.gridlens-publishers-paused'
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        os.close(fd)
        return {'paused': True}
    if action == 'backup-status':
        saved = read_metadata(backup)
        return {'complete': bool(saved and saved.get('complete'))}
    if action == 'validate':
        # The old image is used for rollback validation, so this must rely only
        # on v0.3.0 APIs. No supervisor, listener, publisher or VPN is started.
        sys.path.insert(0, '/usr/local/lib/gridlens')
        from container_runtime import Runtime, BINARY
        runtime = Runtime(guard=lambda _=False: None)
        with runtime.locked():
            saved = runtime.load()
            if saved.get('phase') != 'ready':
                raise ValueError('Saved container state is not initialized.')
            config = runtime._hub_config(saved, '127.0.0.1')
            runtime.runner.run([BINARY, 'hub', 'validate-telemetry', '--telemetry-config', config])
        if hasattr(runtime, 'validate'):
            runtime.validate()
        return {'validated': True}
    roots = {'state': state}
    if request.get('observations'):
        roots['observations'] = observations
    if action == 'backup':
        if any(backup.iterdir()):
            raise ValueError('Backup volume must be empty; existing backups are retained.')
        for name, source in roots.items():
            copy_owned(source, backup / name)
        write_metadata(backup, {'version': 1, 'recipe': request['recipe'], 'complete': True})
        return {'complete': True}
    if action == 'restore':
        saved = read_metadata(backup)
        if not saved or not saved.get('complete') or saved['recipe'] != request['recipe']:
            raise ValueError('Backup is incomplete or belongs to another launch.')
        for name in roots:
            regular_tree(backup / name)
        for name, destination in roots.items():
            regular_tree(destination)
            for child in destination.iterdir():
                shutil.rmtree(child) if child.is_dir() else child.unlink()
            staged = backup / name
            # Mount roots cannot be replaced; copy each child into the mount.
            for child in staged.iterdir():
                target = destination / child.name
                if child.is_dir():
                    copy_owned(child, target)
                else:
                    shutil.copy2(child, target)
                    info = child.stat()
                    if os.geteuid() == 0:
                        os.chown(target, info.st_uid, info.st_gid)
                    with target.open('rb') as stream:
                        os.fsync(stream.fileno())
            info = staged.stat()
            if os.geteuid() == 0:
                os.chown(destination, info.st_uid, info.st_gid)
            os.chmod(destination, stat.S_IMODE(info.st_mode))
            directory = os.open(destination, os.O_DIRECTORY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        write_metadata(state, {'version': 1, 'recipe': request['recipe']})
        return {'restored': True}
    raise ValueError('Unknown volume maintenance action.')


def main():
    try:
        request = json.loads(sys.stdin.read(65537) or '{}')
        print(json.dumps(operate(sys.argv[1], request)))
    except (OSError, ValueError, KeyError) as error:
        print('GridLens volume maintenance failed: ' + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
