#!/usr/bin/env python3
"""Interactive Docker installer used by the verified GitHub release bundle."""
import argparse
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import platform
import re
import shlex
import shutil
import socket
import stat
import subprocess
import sys
import tempfile

import container_onboarding
import container_access
from dockerctl import Docker, Driver, Error, open_terminal

MAX_IMPORT = 16 * 1024 * 1024
IMAGE_FILES = {'bin/gridlens': 'gridlens', 'container/Dockerfile': 'Dockerfile',
               'scripts/container_runtime.py': 'container_runtime.py',
               'scripts/container_probe.py': 'container_probe.py',
               'scripts/container_upgrade.py': 'container_upgrade.py',
               'scripts/container_access.py': 'container_access.py',
               'scripts/container_telemetry.py': 'container_telemetry.py',
               'scripts/dockerctl.py': 'dockerctl.py',
               'scripts/container_updates.py': 'container_updates.py',
               'scripts/container_update_control.py': 'container_update_control.py',
               'scripts/container_enrichment.py': 'container_enrichment.py',
               'scripts/rewards_reader.cjs': 'rewards_reader.cjs'}
COPY_ONLY_IMAGE_FILES = {'scripts/dockerctl.py', 'scripts/container_updates.py',
                         'scripts/container_update_control.py', 'scripts/container_enrichment.py',
                         'scripts/rewards_reader.cjs'}
REQUIRED_IMAGE_FILES = {'bin/gridlens', 'container/Dockerfile',
                        'scripts/container_runtime.py', 'scripts/container_probe.py'}


def image_files(package):
    """Select image inputs from the runtime bundle, never the host coordinator.

    Earlier verified Docker bundles predate some optional runtime helpers. Keep
    their original inputs and fingerprint so a newer coordinator cannot silently
    produce a different image from a previously published runtime release.
    """
    dockerfile_path = package / 'container/Dockerfile'
    if dockerfile_path.is_symlink() or not dockerfile_path.is_file() or dockerfile_path.stat().st_size > 1048576:
        raise Error('The Docker image package is incomplete or unsafe.')
    sources = set()
    for line in dockerfile_path.read_text().replace('\\\n', ' ').splitlines():
        instruction, _, argument = line.strip().partition(' ')
        if instruction.upper() not in ('COPY', 'ADD'):
            continue
        if instruction.upper() != 'COPY':
            raise Error('The selected Docker image has an unsupported build input instruction.')
        try:
            fields = json.loads(argument) if argument.lstrip().startswith('[') else shlex.split(argument)
        except (ValueError, TypeError) as exc:
            raise Error('The selected Docker image has invalid COPY inputs.') from exc
        if (not isinstance(fields, list) or len(fields) < 2
                or any(not isinstance(source, str) for source in fields)):
            raise Error('The selected Docker image has invalid COPY inputs.')
        sources.update(fields[:-1])
    selected = {}
    for relative, destination in IMAGE_FILES.items():
        # dockerctl existed as host-only input in old bundles: adding it to
        # their image would change a previously published content fingerprint.
        if relative in COPY_ONLY_IMAGE_FILES and destination not in sources:
            continue
        path = package / relative
        if relative not in REQUIRED_IMAGE_FILES and not path.exists() and not path.is_symlink():
            continue
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 128 * 1024 * 1024:
            raise Error('The Docker image package is incomplete or unsafe.')
        selected[relative] = destination
    if not sources <= set(selected.values()):
        raise Error('The selected Docker image requires a missing or unsupported COPY input.')
    return selected


def release_order(left, right):
    """Compare release precedence; support the historical dev7/dev10 spelling."""
    def parts(value):
        match = re.fullmatch(r'v?(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)'
                             r'(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?'
                             r'(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?', value)
        if not match:
            raise Error('Cannot safely compare the installed and selected release versions; use a known compatible release or its matching rollback.')
        pre = match[4]
        if pre and re.fullmatch(r'dev[0-9]+', pre):
            pre = 'dev.' + pre[3:]
        identifiers = []
        for item in pre.split('.') if pre else []:
            if item.isdigit():
                if len(item) > 1 and item.startswith('0'):
                    raise Error('Cannot safely compare a release with an invalid prerelease version.')
                identifiers.append((0, int(item)))
            else:
                identifiers.append((1, item))
        return (*map(int, match.group(1, 2, 3)), pre is None, tuple(identifiers))
    first, second = parts(left), parts(right)
    return (first > second) - (first < second)


def package_info(package):
    package = Path(package).resolve(strict=True)
    metadata = package / 'RELEASE.json'
    if metadata.is_symlink() or not metadata.is_file() or metadata.stat().st_size > 16384:
        raise Error('Use the verified Docker release package; release metadata is missing or invalid.')
    value = json.loads(metadata.read_text())
    arch = {'x86_64': 'amd64', 'amd64': 'amd64', 'aarch64': 'arm64', 'arm64': 'arm64'}.get(platform.machine())
    if (platform.system() != 'Linux' or not arch or not isinstance(value, dict)
            or not isinstance(value.get('version'), str) or value.get('schema') != 2 or value.get('installation') != 'docker'
            or value.get('target') != 'linux/' + arch
            or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,127}', value.get('version', ''))):
        raise Error('This package is not a Docker installer for this PC. Run the current GitHub command again.')
    digest = hashlib.sha256()
    for relative in sorted(image_files(package)):
        path = package / relative
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 128 * 1024 * 1024:
            raise Error('The Docker image package is incomplete or unsafe.')
        digest.update(relative.encode() + b'\0')
        with path.open('rb') as source:
            for chunk in iter(lambda: source.read(65536), b''):
                digest.update(chunk)
    with (package / 'bin/gridlens').open('rb') as source:
        header = source.read(64)
    if (len(header) < 64 or header[:6] != b'\x7fELF\x02\x01'
            or int.from_bytes(header[18:20], 'little') != {'amd64': 62, 'arm64': 183}[arch]):
        raise Error('The bundled program does not match this PC architecture.')
    return package, value, digest.hexdigest()


def legacy_present():
    return any(Path(path).exists() for path in ('/opt/fleet-dashboard', '/var/lib/fleet-dashboard-control'))


def choose_port(address, first, kind, excluded=()):
    family = socket.AF_INET6 if ipaddress.ip_address(address).version == 6 else socket.AF_INET
    for port in range(first, min(first + 100, 65536)):
        if port in excluded:
            continue
        try:
            with socket.socket(family, kind) as probe:
                probe.bind((address, port))
            return port
        except OSError:
            pass
    raise Error('No available GridLens port was found on this PC; existing listeners were left running.')


def suggested_wrappers(docker):
    value = docker.call(['ps', '--format', '{{.Names}}\t{{.Image}}'])
    result = []
    for line in value.splitlines():
        fields = line.split('\t')
        if len(fields) != 2:
            continue
        name, image = fields
        if (re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', name)
                and re.fullmatch(r'(?:docker.io/)?nosana/podman(?::[^\s]+|@sha256:[a-f0-9]{64})?', image)):
            result.append(name)
    return sorted(set(result))[:15]


class SetupDriver(Driver):
    def __init__(self, docker, package, metadata, fingerprint, terminal, release_pinned=False, **options):
        self.package, self.metadata, self.fingerprint, self.terminal = package, metadata, fingerprint, terminal
        self.image_files = image_files(package)
        self.release_pinned = release_pinned
        self.legacy = legacy_present()
        arch = metadata['target'].split('/')[1]
        image = 'gridlens-local:' + fingerprint[:32] + '-' + arch
        super().__init__(docker, image, legacy_provider=self.export_legacy if self.legacy else None, **options)

    def status(self):
        recipe = self.existing_recipe()
        if recipe:
            self.bind = recipe['bind']
            self.ports = dict(recipe['ports'])
            return super().status()
        # The controller discovers private management and VPN transport
        # addresses independently. A public-only PC may have no management bind.
        status = super().status()
        # Keep the old hub and its temporary setup listener on their own ports.
        if self.legacy:
            if self.ports['http'] == 8787:
                self.ports['http'] = 8789
            if self.ports['telemetry'] == 8788:
                self.ports['telemetry'] = 8790
        if self.bind:
            self.ports['http'] = choose_port(self.bind, self.ports['http'], socket.SOCK_STREAM)
            self.ports['telemetry'] = choose_port(self.bind, self.ports['telemetry'], socket.SOCK_STREAM,
                                                 (self.ports['http'],))
        vpn_address = self.bind or status.get('suggestedIPv4') or status.get('suggestedIPv6')
        if vpn_address:
            self.ports['udp'] = choose_port(vpn_address, self.ports['udp'], socket.SOCK_DGRAM)
        if not self.legacy and not self.wrappers:
            self.wrappers = suggested_wrappers(self.docker)
        return {**status, 'suggestedUdpPort': self.ports['udp'], 'suggestedWrappers': self.wrappers}

    def export_legacy(self):
        if not self.bind:
            raise Error('Existing-hub import requires its validated private management address. Use --bind; existing services were kept.')
        self.terminal.write('Reading only this PC\'s existing GridLens fleet settings and hub identity.\n'
                            'If sudo asks, enter this PC\'s administrator password here.\n')
        self.terminal.flush()
        command = [sys.executable, '-B', str(self.package / 'scripts/legacy_import.py'),
                   '--export', '--expect-address', self.bind]
        if os.geteuid() != 0:
            command = ['sudo', '--', *command]
        # stdout contains GridLens secrets. Capture it in memory, never a log,
        # argument, environment variable, terminal or temporary host file.
        result = subprocess.run(command, stdin=self.terminal, stdout=subprocess.PIPE,
                                stderr=self.terminal, timeout=300)
        if result.returncode or len(result.stdout) > MAX_IMPORT:
            raise Error('Existing GridLens import failed. Its services and configuration were not changed.')
        return json.loads(result.stdout)

    def ensure_image(self):
        existing = self.inspect('image', self.image)
        if existing:
            labels = existing.get('Config', {}).get('Labels') or {}
            if labels.get('io.gridlens.image-content') != self.fingerprint:
                raise Error('The saved image tag belongs to different content; it will not be replaced.')
            return
        self.terminal.write('Preparing GridLens inside Docker. First setup can take a few minutes.\n'
                            'Dependencies are installed inside the image; no host packages are installed.\n')
        self.terminal.flush()
        with tempfile.TemporaryDirectory(prefix='gridlens-image-') as temporary:
            for source, destination in self.image_files.items():
                shutil.copyfile(self.package / source, Path(temporary) / destination)
            command = [*self.docker.prefix, 'build', '--platform', self.metadata['target'],
                       '--tag', self.image, '--label', 'io.gridlens.image-content=' + self.fingerprint,
                       '--label', 'io.gridlens.version=' + self.metadata['version'], temporary]
            result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    text=True, timeout=900, env=self.docker.env)
            if result.returncode:
                self.terminal.write(result.stdout[-3000:] + '\n')
                raise Error('The Docker image could not be prepared. Existing workloads were not changed.')
        existing = self.inspect('image', self.image)
        if not existing or (existing.get('Config', {}).get('Labels') or {}).get('io.gridlens.image-content') != self.fingerprint:
            raise Error('Docker did not produce the expected local GridLens image.')
        self.terminal.write('Docker image ready. Starting the saved GridLens services.\n')
        self.terminal.flush()

    def configure(self, options):
        if self.existing_recipe():
            raise Error('This GridLens installation already exists; its saved settings were kept.')
        self.validate_install_network(options)
        checks = [(self.bind, self.ports['http'], socket.SOCK_STREAM),
                  (self.bind, self.ports['telemetry'], socket.SOCK_STREAM)] if self.bind else []
        if options.get('wireguard'):
            bindings = options.get('vpn_bindings', options.get('vpnBindings', {}))
            addresses = list(bindings.values()) if bindings else ([self.bind] if self.bind else [])
            for address in addresses:
                checks.append((address, options.get('udpPort', self.ports['udp']), socket.SOCK_DGRAM))
        for address, port, kind in checks:
            if type(port) is not int or not 1024 <= port <= 65535:
                raise Error('Choose a port from 1024 to 65535.')
            if choose_port(address, port, kind) != port:
                raise Error('That port is already in use. Run setup again and choose its suggested free port; existing services were kept.')
        self.ensure_image()
        return super().configure(options)

    def upgrade(self, image=None, ipv6_bind=None, endpoints=None, ipv4_bind=None, http_port=None, collector_wrappers=None, enrichment=None):
        # An explicit upgrade is the only flow that prepares a newer image for
        # an existing installation. Ordinary status/rerun never invokes this.
        if not self.existing_recipe():
            raise Error('No owned Docker installation is available to upgrade.')
        if enrichment is not None:
            # Preparation is a layout transaction on the installed image.
            # In particular, an older public runtime selected by the bootstrap
            # must neither suppress this transaction nor become its target.
            if image != self.existing_recipe()['image']:
                raise Error('Enrichment preparation must preserve the installed image; upgrade it explicitly first.')
            return super().upgrade(image=image, enrichment=enrichment)
        if collector_wrappers is not None:
            if image != self.existing_recipe()['image']:
                raise Error('Collector staging must preserve the installed image; upgrade it explicitly first.')
            return super().upgrade(image=image, collector_wrappers=collector_wrappers)
        status = self.upgrade_status(image, ipv6_bind, endpoints, ipv4_bind, http_port)
        if status['already_current'] or status.get('newer_installed'):
            return status
        if image is None or image == self.image:
            self.ensure_image()
        return super().upgrade(image or self.image, ipv6_bind=ipv6_bind, endpoints=endpoints, ipv4_bind=ipv4_bind, http_port=http_port)

    def upgrade_status(self, image=None, ipv6_bind=None, endpoints=None, ipv4_bind=None, http_port=None):
        # A tag pointing at the saved image must not hide changed package
        # content. Validate the fingerprint even when no build is needed.
        if image is None or image == self.image:
            target = self.inspect('image', self.image)
            if target and (target.get('Config', {}).get('Labels') or {}).get('io.gridlens.image-content') != self.fingerprint:
                raise Error('The saved image tag belongs to different content; it will not be replaced.')
            retained = self.newer_installed_status(ipv6_bind, endpoints, ipv4_bind, http_port)
            if retained is not None:
                return retained
        return super().upgrade_status(image or self.image, ipv6_bind, endpoints, ipv4_bind, http_port)

    def newer_installed_status(self, ipv6_bind=None, endpoints=None, ipv4_bind=None, http_port=None):
        recipe = self.existing_recipe()
        if not recipe:
            raise Error('There is no owned Docker installation to upgrade.')
        if self._pending:
            raise Error('An interrupted upgrade must be recovered with --rollback first.')
        self.preflight(recipe)
        image = self.inspect('image', recipe['image'])
        if not image or image.get('Id') != recipe['image']:
            raise Error('The installed image identity could not be verified; no update was started.')
        installed = self.installed_version(recipe)
        selected = self.metadata['version']
        if release_order(installed, selected) <= 0:
            return None
        if self.release_pinned:
            raise Error('Refusing to downgrade installed GridLens ' + installed + ' to pinned release ' + selected +
                        '. Use --rollback only to restore its matching retained image and state.')
        if any(value is not None for value in (ipv6_bind, endpoints, ipv4_bind, http_port)):
            raise Error('Installed GridLens ' + installed + ' is newer than selected release ' + selected +
                        '. Configuration changes require its matching or a newer runtime bundle; no requested settings were applied.')
        # Unlike status(), this only inspects saved resources and asks a running
        # installed runtime for public status. Stopped services remain stopped.
        result = self._upgrade_status(recipe, recipe, False)
        return {**result, 'newer_installed': True, 'installed_version': installed,
                'selected_version': selected}

    def installed_version(self, recipe=None):
        recipe = recipe or self.existing_recipe()
        image = self.inspect('image', recipe['image']) if recipe else None
        value = ((image or {}).get('Config', {}).get('Labels') or {}).get('io.gridlens.version', '')
        return value if isinstance(value, str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,127}', value) else 'installed build'

    def bootstrap_needs_coordinator(self):
        """Keep published installation behavior for its matching runtime bundle."""
        recipe = self.existing_recipe()
        if not recipe:
            return False
        image = self.inspect('image', recipe['image'])
        if not image or image.get('Id') != recipe['image']:
            raise Error('The installed image identity could not be verified; no installer was started.')
        newer = release_order(self.installed_version(recipe), self.metadata['version']) > 0
        # Recovery can need the newer metadata reader even if an interrupted
        # transaction currently has an older image running. Never hand it to a
        # bundle solely because that image's version appears compatible.
        return newer or bool(self._pending)


def lifecycle_summary(chat, result, version, rollback=False):
    """Only operator-facing facts belong in the interactive result."""
    if result.get('newer_installed'):
        chat.heading('Keeping installed GridLens ' + result['installed_version'])
        chat.key('Selected release', result['selected_version'])
        chat.say('The installed version is newer than this release. No update was applied; your containers and saved settings were kept.')
    elif result.get('already_current'):
        chat.heading('GridLens ' + version + ' is already up to date')
        chat.say('No update was needed. Your containers and saved settings were kept.')
    elif rollback:
        chat.heading('Rollback complete')
        chat.key('Restored version', version)
    else:
        chat.heading('GridLens updated to ' + version)
        chat.say('Your saved devices, profiles and settings were kept.')
    if result.get('running') is False:
        chat.say('GridLens is stopped. Run the normal setup command when you want to start it.')
    elif not result.get('configured', result.get('initialized', False)):
        chat.say('Setup is incomplete. Run the normal setup command to resume it.')
    url = result.get('dashboardURL') or result.get('dashboard_url')
    if url:
        chat.key('Dashboard', url)
    if result.get('profile_route_update') and not result.get('already_current') and not result.get('newer_installed'):
        chat.say('For an existing GridLens phone profile, add ' + result['profile_route_update'] +
                 ' to AllowedIPs; keep its existing entries and keys.')
    if result.get('canonical_migration_pending'):
        chat.say('Canonical access migration is pending. Test every saved profile at this address, then run --retire-tunnel-urls explicitly.')
    if result.get('browser_pairing') and not result.get('already_current') and not result.get('newer_installed'):
        chat.say('To sign in through an existing VPN or home Wi-Fi, rerun setup and choose option 7.')
    if result.get('backupVolume') and not result.get('already_current') and not result.get('newer_installed'):
        chat.say('A backup is available for rollback with --rollback.')
    health = result.get('endpointHealth', {})
    if health.get('missingBindings'):
        chat.say('A saved VPN address needs repair. ' + health.get('repair', 'Restore its assigned host address before connecting.'))


def run_lifecycle(driver, chat, args, metadata):
    recipe = driver.existing_recipe()
    if not recipe:
        raise Error('No owned Docker installation is available.')
    endpoints = {family: value for family, value in
                 (('ipv4', args.endpoint_ipv4), ('ipv6', args.endpoint_ipv6)) if value} or None
    options = {'ipv6_bind': args.vpn_ipv6, 'ipv4_bind': args.vpn_ipv4, 'endpoints': endpoints,
               'http_port': getattr(args, 'http_port', None)}
    if args.upgrade:
        preview = driver.upgrade_status(**options)
        if preview['already_current'] or preview.get('newer_installed'):
            lifecycle_summary(chat, preview, metadata['version'])
            return 0
        chat.heading('Update GridLens')
        chat.key('Installed', driver.installed_version(recipe))
        chat.key('Selected update', metadata['version'])
        chat.say('GridLens will briefly restart. A backup keeps your current setup available for rollback.')
        chat.say('Your saved devices, profiles and fleet data will be preserved.')
        if options['http_port'] is not None and options['http_port'] != recipe['ports']['http']:
            chat.key('Dashboard port', str(recipe['ports']['http']) + ' → ' + str(options['http_port']))
            chat.say('Use the new port in your saved dashboard bookmarks after this update.')
        for family, address in (('IPv4', args.vpn_ipv4), ('IPv6', args.vpn_ipv6)):
            if address:
                chat.key('Requested ' + family + ' VPN address', address)
        for family, address in (endpoints or {}).items():
            chat.key('Requested ' + family.upper() + ' phone endpoint', address)
        if endpoints:
            chat.say('Update Endpoint in the affected saved client profiles; keep their keys and login.')
        if not chat.yes('Apply this update', False):
            return 130
        result = driver.upgrade(**options)
        lifecycle_summary(chat, result, metadata['version'])
    else:
        chat.heading('Restore the previous GridLens version')
        chat.say('This restores the retained backup and briefly restarts GridLens.')
        chat.say('Device, account and setting changes made after that backup will be reverted. Later revocations can become active again; reapply them on every affected PC before relying on access control.')
        if not chat.yes('Restore this backup', False):
            return 130
        result = driver.rollback_upgrade()
        lifecycle_summary(chat, result, driver.installed_version(), rollback=True)
    return 0


def run_access(driver, chat, args, output=None):
    """Explicit installer approval; telemetry discovery never calls this path."""
    output = output or sys.stdout
    if not driver.existing_recipe():
        raise Error('Install this PC with GridLens before joining an access fleet.')
    if args.access_public:
        record = driver.runtime('access-public')
        try:
            record = container_access.validate_record(record)
        except container_access.Error as exc:
            raise Error(str(exc)) from None
        output.write(json.dumps(record, indent=2) + '\n')
        output.flush()
        chat.say('Public PC registration exported. It contains no private keys; approve it explicitly on each participating PC.')
        return 0
    try:
        fd = os.open(args.access_join, os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, 'rb') as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size > container_access.MAX_DOCUMENT:
                raise Error('Access roster must be a bounded regular JSON file.')
            raw = stream.read(container_access.MAX_DOCUMENT + 1)
        if len(raw) > container_access.MAX_DOCUMENT:
            raise Error('Access roster exceeds its size limit.')
        roster = json.loads(raw)
        if isinstance(roster, dict) and set(roster) == {'pcs'}:
            roster = roster['pcs']
        if not isinstance(roster, list) or len(roster) > container_access.MAX_PCS:
            raise Error('Access roster must be a JSON list containing at most 1,024 public PC registrations.')
        records = [container_access.validate_record(pc) for pc in roster]
        if len({pc['id'] for pc in records}) != len(records):
            raise Error('Access roster contains duplicate PC identities.')
    except container_access.Error as exc:
        raise Error(str(exc)) from None
    except (OSError, ValueError) as exc:
        raise Error('Cannot read a valid public access roster from the selected file.') from None
    chat.heading('Approve these PCs for VPN administration')
    chat.say("This replaces this PC's approved access roster. Each listed PC can coordinate device enrollment and revocation after reciprocal installer approval.")
    chat.say('Telemetry membership does not grant these rights. Run this explicit join on every participating PC.')
    for pc in records:
        chat.key(pc['name'] + ' (' + pc['id'] + ')', pc['dashboard_url'])
        chat.key('Certificate SHA-256', container_access.certificate_pin(pc['certificate']))
        if not pc['ready']:
            chat.say('Needs configuration: ' + pc['reason'])
    if not chat.yes('Approve exactly this access roster on this PC', default=False):
        return 130
    result = driver.runtime('access-join', {'pcs': records})
    chat.say('Approved access roster saved: ' + str(result['approved']) + ' PCs including this PC. Existing profiles are unchanged; refresh them explicitly from the dashboard.')
    return 0


def run_updates(driver, chat, args, output=None):
    """Installer approval grants only the signed, fixed update workflow."""
    from docker_telemetry_setup import read_document
    from container_update_control import registration
    from container_updates import ensure_updater
    output = output or sys.stdout
    if not driver.existing_recipe():
        raise Error('Install this PC before approving automatic updates.')
    if args.updates_public:
        output.write(json.dumps(driver.runtime('updates-public'), indent=2) + '\n')
        output.flush()
        return 0
    document = read_document(args.updates_join)
    if (not isinstance(document, dict) or set(document) != {'pcs', 'coordinator_id'}
            or not isinstance(document['pcs'], list) or not 1 <= len(document['pcs']) <= 1024
            or not isinstance(document['coordinator_id'], str)):
        raise Error('Update approval requires one to 1,024 public PC records and coordinator_id.')
    pcs = [registration(pc) for pc in document['pcs']]
    if document['coordinator_id'] not in {pc['id'] for pc in pcs}:
        raise Error('Choose a coordinator from this approved update roster.')
    chat.heading('Approve automatic update fleet')
    for pc in pcs:
        chat.key(pc['name'], pc['dashboard_url'])
        chat.key('Certificate SHA-256', container_access.certificate_pin(pc['certificate']))
    chat.key('Coordinator', document['coordinator_id'])
    chat.say('The separate Docker update worker has Docker socket authority. It accepts only signed GridLens development releases and manages owned GridLens resources. Telemetry and VPN approvals are independent. The dashboard toggle controls the entire approved fleet; a new roster starts disabled.')
    if not chat.yes('Approve this update fleet and install its Docker workers on this PC', False):
        return 130
    # The runtime validates the complete roster before the worker is created.
    result = driver.runtime('updates-join', document)
    result['worker'] = ensure_updater(driver)
    output.write(json.dumps(result, indent=2) + '\n')
    output.flush()
    chat.say('Update roster saved. Repeat approval on every participating PC, then enable Automatic updates in the dashboard.')
    return 0


def run_enrichment(driver, chat, args, output=None):
    """Exact local preparation/approval, separate from installation and VPNs."""
    from docker_telemetry_setup import read_document
    output = output or sys.stdout
    if args.enrichment_prepare:
        preview = driver.enrichment_preview()
        chat.heading('Prepare shared fleet collection')
        chat.key('This PC', preview['pc_id'])
        for identifier, key in sorted(preview['roster'].items()):
            chat.key(identifier, 'public-key fingerprint ' + hashlib.sha256(key.encode()).hexdigest())
        chat.say('This pins the approved telemetry PCs for shared collection and briefly restarts only GridLens with a matched backup. A separate labeled Docker volume retains leases, request attempts and local approval revocations across application rollback. Existing Nosana workloads keep running.')
        chat.say('Preparing collection does not approve or enable wallet-backed rewards. New local policy starts disabled; existing approvals and enable/disable settings are preserved. The prior nn02 proof grants no recurring access.')
        if not chat.yes('Prepare this collection roster and its recovery volume', False):
            return 130
        result = driver.enrichment_prepare()
        chat.say('Shared collection prepared. Repeat on each participating PC. No wallet binding was approved or enabled.')
    elif args.enrichment_status:
        result = driver.enrichment_action('status')
    elif args.enrichment_approve:
        document = read_document(args.enrichment_approve)
        fields = {'pc_id', 'runtime', 'container_id', 'wrapper_id', 'node_address'}
        if (not isinstance(document, dict) or set(document) != fields
                or any(not isinstance(value, str) for value in document.values())
                or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,127}', document['pc_id'])
                or not re.fullmatch(r'[0-9a-f]{64}', document['container_id'])
                or not re.fullmatch(r'[1-9A-HJ-NP-Za-km-z]{32,44}', document['node_address'])
                or document['runtime'] not in ('docker', 'podman')
                or (document['runtime'] == 'docker' and document['wrapper_id'] != '')
                or (document['runtime'] == 'podman' and not re.fullmatch(r'[0-9a-f]{64}', document['wrapper_id']))):
            raise Error('Approval file must contain only the exact PC, runtime, full container/wrapper IDs and expected public node address.')
        chat.heading('Approve recurring local wallet-backed reads')
        for key in ('pc_id', 'runtime', 'container_id', 'wrapper_id', 'node_address'):
            chat.key(key, document[key] or '(none)')
        chat.say('After explicit enablement, the fixed helper signs authentication inside this exact running Nosana container for rewards and recent benchmark GET requests. Signatures are not read-scoped. Private keys and authorization stay inside that container; a privileged host administrator can still inspect it. A stopped or replaced container cannot inherit this approval.')
        if not chat.yes('Approve recurring local signing for exactly this binding', False):
            return 130
        result = driver.enrichment_action('approve', document, confirm=True)
        chat.say('Binding approved. Collection remains at its existing enabled/disabled setting; use --enrichment-enable only after reviewing all bindings.')
    elif args.enrichment_revoke:
        if not re.fullmatch(r'[0-9a-f]{64}', args.enrichment_revoke):
            raise Error('Choose the exact binding ID reported by --enrichment-status.')
        result = driver.enrichment_action('revoke', {'binding_id': args.enrichment_revoke})
        chat.say('Local binding revoked. The revocation survives paired application rollback.')
    elif args.enrichment_enable:
        status = driver.enrichment_action('status')
        chat.heading('Enable approved recurring wallet-backed reads on this PC')
        output.write(json.dumps(status, indent=2) + '\n')
        output.flush()
        chat.say('This enables repeated local signing for the approved exact bindings shown above. Rewards target about one minute when shared provider limits allow. Benchmark requests share scheduled rewards operations. No browser wallet or API key is involved; existing wallet signatures still have broader authority than these fixed GET requests.')
        if not chat.yes('Enable recurring local signing for these approved bindings', False):
            return 130
        result = driver.enrichment_action('enable', confirm=True)
    else:
        result = driver.enrichment_action('disable')
        chat.say('Wallet-backed collection disabled on this PC. Inventory and cached dashboards continue.')
    output.write(json.dumps(result, indent=2) + '\n')
    output.flush()
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    bootstrap = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    bootstrap.add_argument('--package-dir')
    bootstrap.add_argument('--bootstrap-selected', action='store_true')
    bootstrap.add_argument('--bootstrap-explicit-version', action='store_true')
    bootstrap.add_argument('--coordinator-version')
    bootstrap_args, original_args = bootstrap.parse_known_args(argv)
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--package-dir', required=True)
    parser.add_argument('--bootstrap-selected', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--bootstrap-explicit-version', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--coordinator-version', help=argparse.SUPPRESS)
    parser.add_argument('--bind')
    parser.add_argument('--prefix', default='gridlens')
    parser.add_argument('--http-port', type=int, help='dashboard port; with --upgrade, explicitly change the saved port')
    parser.add_argument('--telemetry-port', type=int, default=8788)
    parser.add_argument('--udp-port', type=int, default=51871)
    parser.add_argument('--wrapper', action='append', default=[])
    lifecycle = parser.add_mutually_exclusive_group()
    lifecycle.add_argument('--access-public', action='store_true', help='export this installed PC public VPN administration registration as JSON')
    lifecycle.add_argument('--access-join', metavar='FILE', help='preview and explicitly approve public access PC registrations from a JSON file')
    lifecycle.add_argument('--updates-public', action='store_true', help='export this PC public automatic-update registration')
    lifecycle.add_argument('--updates-join', metavar='FILE', help='approve an independent update roster/coordinator and provision its Docker worker')
    lifecycle.add_argument('--telemetry-public', action='store_true', help='export public collection and hub registrations; grants no VPN administration')
    lifecycle.add_argument('--telemetry-join', metavar='FILE', help='preview and approve a public telemetry roster and optional generation replacements')
    lifecycle.add_argument('--collector-prepare', metavar='FILE', help='stage a Docker collector using explicit probe settings from JSON')
    lifecycle.add_argument('--collector-verify', action='store_true', help='compare staged Docker collection with retained signed observations')
    lifecycle.add_argument('--collector-activate', metavar='GENERATION', help='verify and explicitly activate the prepared collector generation')
    lifecycle.add_argument('--enrichment-prepare', action='store_true', help='pin shared collection membership and attach independent recovery volume; no wallet approval')
    lifecycle.add_argument('--enrichment-status', action='store_true', help='inspect this PC exact local wallet-read approvals and enabled setting')
    lifecycle.add_argument('--enrichment-approve', metavar='FILE', help='review an exact public container binding and approve recurring local signing')
    lifecycle.add_argument('--enrichment-revoke', metavar='BINDING_ID', help='durably revoke an exact local collection approval')
    lifecycle.add_argument('--enrichment-enable', action='store_true', help='explicitly enable this PC approved recurring wallet-backed reads')
    lifecycle.add_argument('--enrichment-disable', action='store_true', help='disable this PC wallet-backed reads while retaining inventory and cache')
    lifecycle.add_argument('--upgrade', action='store_true', help='explicitly upgrade owned Docker containers with a consistent backup')
    lifecycle.add_argument('--retire-tunnel-urls', action='store_true', help='retire internal dashboard access only after canonical tests succeed for every saved profile')
    lifecycle.add_argument('--rollback', action='store_true', help='restore the retained Docker upgrade backup and original containers')
    parser.add_argument('--vpn-ipv6', help='with --upgrade, explicitly add or repair the assigned IPv6 UDP bind')
    parser.add_argument('--vpn-ipv4', help='with --upgrade, explicitly add or repair the assigned IPv4 UDP bind')
    parser.add_argument('--endpoint-ipv4', help='with --upgrade, repair the advertised IPv4 profile endpoint')
    parser.add_argument('--endpoint-ipv6', help='with --upgrade, repair the advertised IPv6 profile endpoint')
    args, unknown = parser.parse_known_args(argv)
    try:
        with open_terminal() as terminal:
            if not terminal.isatty():
                raise Error('Open a host terminal or SSH with -t; phone setup needs an interactive terminal.')
            package, metadata, fingerprint = package_info(args.package_dir)
            title = 'update' if args.upgrade else 'rollback' if args.rollback else 'Docker and phone VPN setup'
            if args.coordinator_version:
                if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,127}', args.coordinator_version):
                    raise Error('Invalid host coordinator version.')
            terminal.write('GridLens — ' + title + '\n')
            terminal.flush()
            driver = SetupDriver(Docker(), package, metadata, fingerprint, terminal,
                release_pinned=args.bootstrap_explicit_version or bool(os.environ.get('GRIDLENS_VERSION')),
                prefix=args.prefix, bind=args.bind, http_port=args.http_port if args.http_port is not None else 8789,
                telemetry_port=args.telemetry_port, udp_port=args.udp_port, wrappers=args.wrapper)
            if bootstrap_args.bootstrap_selected and not driver.bootstrap_needs_coordinator():
                # The runtime archive remains byte-for-byte verified. Its own
                # installer controls fresh/matching/forward installation; the
                # compatibility coordinator only bridges an older public bundle
                # to an already-installed newer runtime.
                return subprocess.run(['bash', str(package / 'install.sh'), 'setup', *original_args],
                                      stdin=terminal).returncode
            if unknown:
                parser.error('unrecognized arguments: ' + ' '.join(unknown))
            setup_only = {'--bind', '--telemetry-port', '--udp-port', '--wrapper'}
            if args.upgrade and any(value.split('=', 1)[0] in setup_only for value in original_args):
                raise Error('Initial setup address, telemetry port, UDP port and wrapper options cannot change an installed PC through --upgrade. No requested settings were applied.')
            if any((args.vpn_ipv4, args.vpn_ipv6, args.endpoint_ipv4, args.endpoint_ipv6)) and not args.upgrade:
                parser.error('VPN binding/endpoint changes require --upgrade; ordinary reruns keep saved settings')
            if args.updates_public or args.updates_join:
                chat = container_onboarding.Conversation(terminal, lambda *_: None)
                return run_updates(driver, chat, args)
            if any((args.enrichment_prepare, args.enrichment_status, args.enrichment_approve,
                    args.enrichment_revoke, args.enrichment_enable, args.enrichment_disable)):
                chat = container_onboarding.Conversation(terminal, lambda *_: None)
                return run_enrichment(driver, chat, args)
            if any((args.telemetry_public, args.telemetry_join, args.collector_prepare,
                    args.collector_verify, args.collector_activate)):
                from docker_telemetry_setup import run_telemetry
                chat = container_onboarding.Conversation(terminal, lambda *_: None)
                return run_telemetry(driver, chat, args)
            if args.access_public or args.access_join:
                chat = container_onboarding.Conversation(terminal, lambda *_: None)
                return run_access(driver, chat, args)
            if args.retire_tunnel_urls:
                result = driver.runtime('retire-tunnel-urls')
                terminal.write('Canonical dashboard access verified. Internal dashboard URLs retired.\n')
                terminal.flush()
                return 0
            if args.upgrade or args.rollback:
                chat = container_onboarding.Conversation(terminal, lambda *_: None)
                return run_lifecycle(driver, chat, args, metadata)
            if args.bootstrap_selected:
                terminal.write('Using installed GridLens ' + driver.installed_version() + '.\n'
                               'Selected public runtime: ' + metadata['version'] +
                               '. Your saved installation is retained.\n')
                terminal.flush()
            def qr(value, kind):
                return driver.docker.call(['exec', '-i', driver.names['core'], '/usr/local/bin/gridlens',
                                           'qr', '--format', 'terminal'], value)
            result = container_onboarding.run_onboarding(driver, terminal, qr)
            return 0 if result.get('status') != 'cancelled' else 130
    except (KeyboardInterrupt, container_onboarding.Cancelled):
        print('\nGridLens setup closed. Saved connections and existing workloads were kept.', file=sys.stderr)
        return 130
    except (Error, container_access.Error, OSError, ValueError, container_onboarding.OnboardingError, subprocess.SubprocessError) as error:
        print('GridLens setup: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
