"""Installer-owned telemetry approval, independent of VPN access approval."""
import json
import base64
import hashlib
import os
import re
import stat
import sys

from dockerctl import Error

MAX_ROSTER = 16 * 1024 * 1024
IDENTIFIER = re.compile(r'[A-Za-z0-9][A-Za-z0-9_-]{0,63}')


def certificate_fingerprint(value):
    """Bounded public PEM structure check; Go remains the X.509 authority."""
    if not isinstance(value, str) or len(value) > 16384:
        raise Error('Telemetry approval accepts bounded public certificates only.')
    match = re.fullmatch(r'-----BEGIN CERTIFICATE-----\r?\n([A-Za-z0-9+/=\r\n]+)-----END CERTIFICATE-----\r?\n?', value)
    if not match:
        raise Error('Telemetry approval accepts public certificate PEM, never private keys.')
    try:
        der = base64.b64decode(''.join(match.group(1).split()), validate=True)
    except ValueError:
        raise Error('Telemetry public certificate encoding is invalid.') from None
    if not der:
        raise Error('Telemetry public certificate is empty.')
    return hashlib.sha256(der).hexdigest()


def public_record(record):
    if not isinstance(record, dict) or set(record) != {'schema', 'source', 'hub'} or type(record['schema']) is not int or record['schema'] != 1:
        raise Error('Each telemetry record needs exactly schema, source and hub public fields.')
    source, hub = record['source'], record['hub']
    if (not isinstance(source, dict) or set(source) != {'hostID', 'generation', 'name', 'address', 'certificate'}
            or not isinstance(hub, dict) or set(hub) != {'id', 'url', 'certificate'}):
        raise Error('Telemetry records contain unsupported or private fields.')
    for value in (source['hostID'], source['generation'], hub['id']):
        if not isinstance(value, str) or not IDENTIFIER.fullmatch(value):
            raise Error('Telemetry identity or generation is invalid.')
    for value, limit in ((source['name'], 128), (source['address'], 255), (hub['url'], 1024)):
        if not isinstance(value, str) or not 1 <= len(value) <= limit or any(ord(c) < 32 or ord(c) == 127 for c in value):
            raise Error('Telemetry display metadata is invalid.')
    return certificate_fingerprint(source['certificate']), certificate_fingerprint(hub['certificate'])


def read_document(path):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, 'rb') as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_ROSTER:
                raise Error('Choose a bounded regular public JSON file.')
            raw = stream.read(MAX_ROSTER + 1)
        if len(raw) > MAX_ROSTER:
            raise Error('Public telemetry document exceeds its size limit.')
        return json.loads(raw)
    except (OSError, ValueError):
        raise Error('Cannot read the selected public telemetry JSON file.') from None


def run_telemetry(driver, chat, args, output=None):
    output = output or sys.stdout
    recipe = driver.existing_recipe()
    if not recipe:
        raise Error('Install this PC before approving telemetry or preparing collector migration.')
    if args.telemetry_public:
        output.write(json.dumps(driver.runtime('telemetry-public'), indent=2) + '\n')
        output.flush()
        chat.say('Public telemetry registration exported. VPN administration approval is separate.')
        return 0
    if args.telemetry_join:
        document = read_document(args.telemetry_join)
        if isinstance(document, list):
            document = {'pcs': document}
        if (not isinstance(document, dict) or set(document) - {'pcs', 'probe', 'replacements'}
                or not isinstance(document.get('pcs'), list) or not 1 <= len(document['pcs']) <= 1024):
            raise Error('Telemetry approval requires 1–1,024 public PC records and optional explicit generation replacements.')
        fingerprints = [public_record(record) for record in document['pcs']]
        replacements = document.get('replacements', [])
        if not isinstance(replacements, list) or len(replacements) > 1024:
            raise Error('Invalid explicit generation replacement list.')
        for replacement in replacements:
            if (not isinstance(replacement, dict) or set(replacement) != {'hostID', 'from_generation', 'to_generation'}
                    or any(not isinstance(value, str) or not IDENTIFIER.fullmatch(value) for value in replacement.values())):
                raise Error('Invalid explicit generation replacement.')
        chat.heading('Approve telemetry membership')
        chat.say('This authorizes signed collection and replication on this PC. It grants no VPN administration and preserves other enrolled sources.')
        for record, (source_fingerprint, hub_fingerprint) in zip(document['pcs'], fingerprints):
            source, hub = record['source'], record['hub']
            chat.key(str(source.get('name', 'PC')), str(source.get('hostID', '')) + ' → ' + str(hub.get('url', '')))
            chat.key('Collector generation', str(source.get('generation', '')))
            chat.key('Source certificate SHA256', source_fingerprint)
            chat.key('Hub certificate SHA256', hub_fingerprint)
        if document.get('replacements'):
            chat.say('Generation replacements revoke new ingestion from the previous collectors on this hub. Existing signed observations retain their original age until replacement data arrives.')
            for replacement in document['replacements']:
                chat.key(str(replacement.get('hostID', '')), str(replacement.get('from_generation', '')) + ' → ' + str(replacement.get('to_generation', '')))
        if not chat.yes('Approve this telemetry membership on this PC', False):
            return 130
        result = driver.telemetry_join(document)
        chat.say('Telemetry membership committed and the owned Docker services restarted. Repeat approval on every participating hub.')
    elif args.collector_prepare:
        document = read_document(args.collector_prepare)
        if not isinstance(document, dict) or set(document) != {'host_id', 'probe'} or not isinstance(document['probe'], dict):
            raise Error('Collector preparation requires host_id and explicit probe settings.')
        if not isinstance(document['host_id'], str) or not IDENTIFIER.fullmatch(document['host_id']):
            raise Error('Collector preparation requires a valid stable PC identity.')
        wrappers = document['probe'].get('wrappers', [])
        if not isinstance(wrappers, list) or any(not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', value) for value in wrappers):
            raise Error('Collector preparation requires explicit valid wrapper names.')
        chat.heading('Prepare replacement Docker collection')
        chat.key('Stable PC identity', str(document['host_id']))
        chat.key('Explicit wrappers', ', '.join(wrappers) or '(none)')
        chat.say('A separate Docker probe will read inventory through the Docker socket. A new source key stays inside Docker. Existing collectors continue running; activation requires matching signed observations.')
        if not chat.yes('Stage this Docker collector with an owned rollback backup', False):
            return 130
        result = driver.collector_prepare(document)
        chat.say('Collector staged. Run --collector-verify, then approve its public replacement registration on the other Docker hubs before local activation. Keep legacy collectors running on hubs awaiting approval.')
    elif args.collector_verify:
        result = driver.runtime('collector-verify')
        chat.say('Staged collector verification passed against the retained signed baseline.')
    else:
        chat.heading('Activate replacement collector generation')
        chat.key('Generation', args.collector_activate)
        chat.say('This PC will accept one active generation. Other hubs need explicit telemetry generation approval. Legacy services remain running, including capabilities Docker cannot reproduce.')
        if not chat.yes('Reverify and activate this generation on this PC', False):
            return 130
        result = driver.collector_activate(args.collector_activate)
        chat.say('The verified Docker generation is active on this PC. Legacy service retirement is a separate acceptance step.')
    output.write(json.dumps(result, indent=2) + '\n')
    output.flush()
    return 0
