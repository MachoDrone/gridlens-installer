#!/usr/bin/env python3
"""Docker-only GridLens lifecycle. Never installs or configures the host OS.

All durable state belongs to labeled named Docker volumes. Existing deployments
are inspected/reused, never silently reset, upgraded, or force-recreated.
"""
import argparse
import ipaddress
import io
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import subprocess
import sys
import time

LABEL = 'io.gridlens'
RUNTIME = '/usr/local/lib/gridlens/container_runtime.py'
PROBE = '/usr/local/lib/gridlens/container_probe.py'
CORE_CAPS = ['CHOWN', 'DAC_OVERRIDE', 'FOWNER', 'KILL', 'SETGID', 'SETUID']


def public_ipv4_suggestion():
    """Best-effort outgoing IPv4 hint, never proof of router ownership or reachability."""
    command = shutil.which('curl')
    if not command:
        return None
    process = None
    try:
        # No curlrc, proxy, redirect, credentials, or local state accompanies
        # this optional lookup. A VPN may still determine the outgoing route.
        process = subprocess.Popen([
            command, '--disable', '--ipv4', '--noproxy', '*',
            '--silent', '--fail', '--proto', '=https', '--max-redirs', '0',
            '--connect-timeout', '3', '--max-time', '5',
            '--', 'https://api.ipify.org',
        ], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        # Enforce the response limit ourselves, including chunked responses and
        # older curl versions without streaming --max-filesize enforcement.
        response = process.stdout.read(65)
        if len(response) > 64 or process.wait(timeout=6) != 0:
            return None
        if not re.fullmatch(rb'[0-9]{1,3}(?:\.[0-9]{1,3}){3}', response):
            return None
        address = ipaddress.IPv4Address(response.decode('ascii'))
        if not address.is_global or address.is_multicast or address.is_reserved:
            return None
        return str(address)
    except (OSError, ValueError, subprocess.SubprocessError):
        return None
    finally:
        if process is not None:
            if process.poll() is None:
                process.kill()
            process.wait()
            process.stdout.close()


def host_addresses():
    """Read assigned addresses; temporary/deprecated IPv6 cannot be saved endpoints."""
    inventory = {'private': [], 'ipv4': [], 'ipv6': [], 'ipv6Temporary': []}
    try:
        result = subprocess.run(['ip', '-j', 'address', 'show'], capture_output=True, text=True, check=True)
        interfaces = json.loads(result.stdout)
    except (OSError, ValueError, subprocess.SubprocessError):
        return {**inventory, 'available': False}
    for interface in interfaces:
        if interface.get('ifname', '').startswith(('lo', 'docker', 'br-', 'veth')):
            continue
        for entry in interface.get('addr_info', []):
            try:
                address = ipaddress.ip_address(entry['local'])
            except (KeyError, ValueError):
                continue
            if address.is_loopback or address.is_link_local or address.is_multicast or address.is_unspecified:
                continue
            flags = set(entry.get('flags', []))
            if (flags & {'tentative', 'dadfailed', 'deprecated'}
                    or any(entry.get(flag) is True for flag in ('tentative', 'dadfailed', 'deprecated'))
                    or entry.get('preferred_life_time') == 0):
                continue
            value = str(address)
            try:
                private_ip(value)
                inventory['private'].append(value)
            except Error:
                pass
            if address.version == 4:
                inventory['ipv4'].append(value)
            elif address.is_global:
                temporary = entry.get('temporary') is True or 'temporary' in flags
                inventory['ipv6Temporary' if temporary else 'ipv6'].append(value)
    return {**{k: sorted(set(v)) for k, v in inventory.items()}, 'available': True}


def vpn_bind_address(value, family):
    try:
        address = ipaddress.ip_address(value)
    except (TypeError, ValueError) as exc:
        raise Error('VPN publication requires an assigned IP address.') from exc
    if address.version != (4 if family == 'ipv4' else 6) or address.is_loopback or address.is_link_local or address.is_unspecified or address.is_multicast:
        raise Error('VPN publication requires a usable address of the selected family.')
    # ULA remains supported for existing/private-network profiles.
    if address.version == 6 and not (address.is_global or address in ipaddress.ip_network('fc00::/7')):
        raise Error('IPv6 VPN publication requires global IPv6 or an existing private IPv6 network.')
    return str(address)


class Error(Exception):
    pass


def open_terminal():
    # Text r+ uses a seekable buffered pair, which /dev/tty cannot provide.
    return io.TextIOWrapper(open('/dev/tty', 'r+b', buffering=0), encoding='utf-8', write_through=True)


class Docker:
    def __init__(self):
        command = shutil.which('docker')
        if not command:
            raise Error('Docker must already be installed. GridLens will not install host packages.')
        self.prefix = [command, '--host', 'unix:///var/run/docker.sock']
        self.env = {k: v for k, v in os.environ.items() if not k.startswith('DOCKER_')}
        result = self.raw(['version', '--format', '{{.Server.Version}}'])
        if result.returncode:
            if os.geteuid() == 0 or not shutil.which('sudo'):
                raise Error('The local Docker daemon is unavailable.')
            # Normal sudo prompts through the controlling terminal; stdin is
            # reserved for Docker JSON or profile operations, never passwords.
            self.prefix = ['sudo', '--', *self.prefix]
            if self.raw(['version', '--format', '{{.Server.Version}}']).returncode:
                raise Error('Local Docker access failed. Existing workloads were not changed.')

    def raw(self, args, body=None, timeout=60):
        return subprocess.run([*self.prefix, *map(str, args)], input=body, text=True,
                              capture_output=True, timeout=timeout, env=self.env)

    def call(self, args, body=None, timeout=60):
        result = self.raw(args, body, timeout)
        if result.returncode:
            raise Error('Docker operation failed: ' + result.stderr.strip()[-1500:])
        return result.stdout


def private_ip(value):
    address = ipaddress.ip_address(value)
    blocks = ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16') if address.version == 4 else ('fc00::/7',)
    if not any(address in ipaddress.ip_network(block) for block in blocks):
        raise Error('Choose an assigned private LAN address for this PC.')
    return str(address)



class Driver:
    def __init__(self, docker, image, prefix='gridlens', bind=None, http_port=8789,
                 telemetry_port=8788, udp_port=51871, wrappers=(), pilot=False, legacy_provider=None):
        if not re.fullmatch(r'gridlens(?:-[a-z0-9][a-z0-9-]{0,32})?', prefix):
            raise Error('Use gridlens or a short gridlens-prefixed installation name.')
        self.docker, self.image, self.prefix = docker, image, prefix
        self.bind = private_ip(bind) if bind else None
        self.ports = {'http': http_port, 'telemetry': telemetry_port, 'udp': udp_port}
        if any(type(p) is not int or not 1024 <= p <= 65535 for p in self.ports.values()) or http_port == telemetry_port:
            raise Error('Choose distinct unprivileged HTTP and telemetry ports.')
        if any(not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', w) for w in wrappers) or len(wrappers) > 15:
            raise Error('Invalid explicitly enrolled Docker wrapper name.')
        self.wrappers = list(wrappers)
        self.pilot = pilot
        self.legacy_provider = legacy_provider
        self.names = {role: prefix + '-' + role for role in ('core', 'probe', 'state', 'observations', 'network')}
        self._metadata_checked = False
        self._metadata = None
        self._pending = None

    def public_ipv4_suggestion(self):
        return public_ipv4_suggestion()

    def inspect(self, kind, name):
        result = self.docker.raw([kind, 'inspect', name])
        if result.returncode:
            if any(text in result.stderr.lower() for text in ('no such', 'not found')):
                return None
            raise Error('Cannot inspect the local Docker installation.')
        values = json.loads(result.stdout)
        if len(values) != 1 or not isinstance(values[0], dict):
            raise Error('Unexpected Docker inspection result.')
        return values[0]

    def labels(self, role, owner, recipe=None):
        result = {LABEL + '.managed': 'true', LABEL + '.owner': owner,
                  LABEL + '.role': role, LABEL + '.schema': '1'}
        if recipe is not None:
            result[LABEL + '.recipe'] = json.dumps(recipe, sort_keys=True, separators=(',', ':'))
        return [part for key, value in result.items() for part in ('--label', key + '=' + value)]

    def verify(self, value, role, owner):
        labels = value.get('Config', {}).get('Labels') if 'Config' in value else value.get('Labels')
        labels = labels or {}
        if labels.get(LABEL + '.managed') != 'true' or labels.get(LABEL + '.role') != role or labels.get(LABEL + '.owner') != owner:
            raise Error('A Docker resource has a foreign or changed ownership label: ' + role)
        return labels

    def existing_recipe(self):
        volume = self.inspect('volume', self.names['state'])
        if not volume:
            return None
        labels = volume.get('Labels') or {}
        owner = labels.get(LABEL + '.owner', '')
        if not re.fullmatch(r'[a-f0-9]{32}', owner):
            raise Error('The existing volume has no valid GridLens owner. It will not be adopted.')
        self.verify(volume, 'state', owner)
        recipe = json.loads(labels.get(LABEL + '.recipe', '{}'))
        if recipe.get('owner') != owner or recipe.get('prefix') != self.prefix or recipe.get('schema') not in (1, 2):
            raise Error('The saved Docker installation record is invalid.')
        self.validate_recipe(recipe)
        journal = self.inspect('volume', self.prefix + '-upgrade')
        if journal:
            self.verify(journal, 'upgrade', owner)
            try:
                self._pending = json.loads(journal['Labels'][LABEL + '.transaction'])
                for key in ('old', 'new'):
                    self.validate_recipe(self._pending[key])
                    if self._pending[key]['owner'] != owner or self._pending[key]['prefix'] != self.prefix:
                        raise Error('Upgrade transaction ownership changed.')
                if not re.fullmatch(re.escape(self.prefix) + r'-backup-[a-f0-9]{16}', self._pending['backup']):
                    raise Error('Invalid upgrade backup name.')
            except (KeyError, ValueError, TypeError) as exc:
                raise Error('Invalid upgrade recovery journal.') from exc
        if not self._metadata_checked:
            # Check every extant ownership label before a read-only helper mounts
            # the state volume. The helper cannot reach the host or its network.
            for role, kind in self.resource_roles(recipe):
                value = volume if role == 'state' else self.inspect(kind, self.names[role])
                if value:
                    self.verify(value, role, owner)
            self._metadata = self.maintenance('read', recipe).get('metadata')
            self._metadata_checked = True
        if self._metadata:
            candidate = self._metadata.get('recipe', {})
            if candidate.get('owner') != owner or candidate.get('prefix') != self.prefix:
                raise Error('Launch metadata ownership changed.')
            self.validate_recipe(candidate)
            recipe = candidate
        self.names['network'] = recipe.get('network_name', self.prefix + '-network')
        return recipe

    def maintenance(self, action, recipe, payload=None, backup=None):
        script = Path(__file__).with_name('container_upgrade.py').read_text()
        readonly = ',readonly' if action in ('read', 'backup') else ''
        args = ['run', '--rm', '-i', '--network', 'none', '--read-only', '--cap-drop', 'ALL',
                '--security-opt', 'no-new-privileges=true', '--pids-limit', '32', '--memory', '128m',
                *self.labels('maintenance', recipe['owner']), '--entrypoint', '/usr/bin/python3',
                '--env', 'GRIDLENS_OWNER=' + recipe['owner'],
                '--mount', 'type=volume,src=' + self.names['state'] + ',dst=/state' + readonly]
        if action in ('validate', 'collector-abort'):
            args += ['--mount', 'type=volume,src=' + self.names['state'] + ',dst=/var/lib/gridlens']
        if action != 'read':
            for capability in ('CHOWN', 'DAC_OVERRIDE', 'FOWNER'):
                args += ['--cap-add', capability]
        if backup:
            args += ['--mount', 'type=volume,src=' + backup + ',dst=/backup' + (',readonly' if action == 'restore' else '')]
            if recipe.get('collection', 'local') in ('local', 'staged'):
                args += ['--mount', 'type=volume,src=' + self.names['observations'] + ',dst=/observations' + readonly]
        args += [recipe['image'], '-B', '-c', script, action]
        return json.loads(self.docker.call(args, json.dumps(payload or {}), timeout=300))

    def save_metadata(self, recipe, pending=None):
        metadata = {'version': 1, 'recipe': recipe}
        if pending:
            metadata['pending'] = pending
        self.maintenance('write', recipe, {'metadata': metadata})
        self._metadata, self._metadata_checked = metadata, True

    def validate_recipe(self, recipe):
        try:
            if recipe.get('schema') not in (1, 2):
                raise Error('Unsupported launch metadata version.')
            if recipe.get('network_name', self.prefix + '-network') not in (self.prefix + '-network', self.prefix + '-network-v6'):
                raise Error('Invalid owned network name.')
            if recipe['bind'] is not None and private_ip(recipe['bind']) != recipe['bind']:
                raise Error('The saved bind address is not canonical.')
            if recipe['bind'] is None and (recipe['schema'] == 1 or not recipe['wireguard']):
                raise Error('An installation without private management requires WireGuard.')
            ports = recipe['ports']
            if set(ports) != {'http', 'telemetry', 'udp'} or any(type(p) is not int or not 1024 <= p <= 65535 for p in ports.values()) or ports['http'] == ports['telemetry']:
                raise Error('Invalid saved ports.')
            if not re.fullmatch(r'sha256:[a-f0-9]{64}', recipe['image']):
                raise Error('Invalid saved image identity.')
            if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', recipe['name']):
                raise Error('Invalid saved PC name.')
            if type(recipe['wireguard']) is not bool:
                raise Error('Invalid saved VPN choice.')
            wrappers = recipe['wrappers']
            if not isinstance(wrappers, list) or len(wrappers) > 15 or any(not isinstance(w, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', w) for w in wrappers) or len(set(wrappers)) != len(wrappers):
                raise Error('Invalid saved wrapper enrollment.')
            self.validate_endpoint(recipe['endpoint'], recipe['wireguard'])
            if recipe['schema'] == 2:
                bindings, endpoints = recipe['vpn_bindings'], recipe['endpoints']
                if not isinstance(bindings, dict) or not isinstance(endpoints, dict) or set(bindings) != set(endpoints) or set(bindings) - {'ipv4', 'ipv6'}:
                    raise Error('Invalid saved VPN address families.')
                if bool(bindings) != recipe['wireguard']:
                    raise Error('Saved VPN publication does not match its mode.')
                for family, address in bindings.items():
                    if vpn_bind_address(address, family) != address:
                        raise Error('The saved VPN address is not canonical.')
                    self.validate_endpoint(endpoints[family], True)
                    try:
                        endpoint_ip = ipaddress.ip_address(endpoints[family])
                    except ValueError:
                        if family == 'ipv6':
                            raise Error('IPv6 verification requires an explicit IPv6 endpoint.')
                    else:
                        if endpoint_ip.version != (4 if family == 'ipv4' else 6):
                            raise Error('The endpoint does not match its selected family.')
                if 'ipv6' in bindings:
                    network = ipaddress.ip_network(recipe['ipv6_subnet'])
                    if network.version != 6 or network.prefixlen != 64 or not network.subnet_of(ipaddress.ip_network('fd00::/8')):
                        raise Error('Invalid owned IPv6 Docker subnet.')
            if recipe.get('collection', 'local') not in ('local', 'replica', 'staged'):
                raise Error('Invalid saved collection mode.')
        except (KeyError, TypeError, ValueError) as exc:
            raise Error('The saved Docker installation record is invalid.') from exc

    @staticmethod
    def validate_endpoint(endpoint, wireguard):
        if not wireguard:
            if endpoint:
                raise Error('An endpoint requires WireGuard.')
            return
        if not isinstance(endpoint, str) or not endpoint or len(endpoint) > 253:
            raise Error('Choose a valid WireGuard endpoint address.')
        try:
            address = ipaddress.ip_address(endpoint)
            if address.is_unspecified or address.is_multicast or address.is_loopback:
                raise Error('Choose a reachable WireGuard endpoint address.')
        except ValueError:
            if not all(re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?', part) for part in endpoint.split('.')):
                raise Error('Choose a WireGuard hostname or IP, without a URL or port.')

    def runtime(self, action, payload=None, timeout=90):
        recipe = self.existing_recipe()
        if self._pending and action not in ('init', 'status', 'service-readiness', 'upgrade-config', 'upgrade-resume', 'validate'):
            raise Error('Device changes are paused until the owned upgrade is completed or rolled back.')
        container = self.inspect('container', self.names['core'])
        if not recipe or not container:
            raise Error('The owned Docker installation is unavailable.')
        self.verify(container, 'core', recipe['owner'])
        self.check_container(container, 'core', recipe)
        arguments = ['exec', '-i', self.names['core'], 'python3', '-B', RUNTIME, action]
        result = self.docker.call(arguments, None if payload is None else json.dumps(payload), timeout=timeout)
        return json.loads(result)

    def status(self):
        recipe = self.existing_recipe()
        if not recipe:
            inventory = host_addresses()
            if self.bind is None and inventory['private']:
                self.bind = next((value for value in inventory['private'] if ':' not in value), inventory['private'][0])
            return {'configured': False, 'suggestedName': socket.gethostname().split('.')[0],
                    'suggestedAddress': self.bind, 'suggestedUdpPort': self.ports['udp'],
                    'suggestedIPv4': next(iter(inventory['ipv4']), None),
                    'suggestedIPv6': next(iter(inventory['ipv6']), None), 'addressInventory': inventory,
                    'suggestedWrappers': self.wrappers, 'legacyDetected': self.legacy_provider is not None}
        if self._pending:
            raise Error('An interrupted upgrade is retained. Run --rollback to restore its consistent backup before restarting publishers.')
        inventory = host_addresses()
        addresses = inventory['ipv4'] + inventory['ipv6'] + inventory['private']
        if inventory['available'] and any(address not in addresses for address in self.vpn_bindings(recipe).values()):
            self.preflight(recipe)
            core = self.inspect('container', self.names['core'])
            running = bool(core.get('State', {}).get('Running'))
            state = self.runtime('status') if running else {'initialized': True}
            return self.view({**state, 'running': running}, recipe)
        self.ensure_resources(recipe)
        # The source configuration is immutable and idempotent. Repairing an
        # interrupted probe initialization must not depend on a viewing device.
        status = self.initialize(recipe)
        configured = bool(status.get('initialized', status.get('configured', False)))
        if not configured:
            raise Error('Container initialization is incomplete; owned state has been retained.')
        return self.view(status, recipe)

    def view(self, state, recipe):
        state = dict(state)
        login = state.pop('operator_login', None)
        if login:
            state['operatorLogin'] = login
        inventory = host_addresses()
        bindings = self.vpn_bindings(recipe)
        available = set(inventory['ipv4'] + inventory['ipv6'] + inventory['private'])
        missing = {family: address for family, address in bindings.items() if inventory['available'] and address not in available}
        return {**state, 'configured': bool(state.get('initialized', state.get('configured', False))),
                'wireguard': state.get('vpn_available', recipe['wireguard']),
                'endpoint': recipe.get('endpoint', ''), 'publicEndpoint': False,
                'udpPort': recipe['ports']['udp'], 'bind': recipe['bind'],
                'endpoints': self.endpoints(recipe), 'vpnBindings': bindings,
                'addressInventory': inventory, 'endpointHealth': {'bindingAvailable': not missing and inventory['available'],
                    'missingBindings': missing, 'addressInspectionAvailable': inventory['available'],
                    'repair': 'Restore the saved host address or explicitly repair the endpoint and update the saved client profile. Keys are retained.' if missing else ''},
                'fleetConnection': {'configured': bool(recipe['bind']), 'reason': '' if recipe['bind'] else 'No private management network is configured; multi-PC replication requires a private network or existing private VPN.'},
                'dashboardURL': state.get('dashboard_url'),
                'peers': state.get('devices', []), 'running': state.get('running', True)}

    @staticmethod
    def vpn_bindings(recipe):
        if recipe.get('schema') == 2:
            return recipe['vpn_bindings']
        return {('ipv6' if ':' in recipe['bind'] else 'ipv4'): recipe['bind']} if recipe['wireguard'] else {}

    @staticmethod
    def endpoints(recipe):
        if recipe.get('schema') == 2:
            return recipe['endpoints']
        if not recipe['wireguard']:
            return {}
        return {('ipv6' if ':' in recipe['endpoint'] else 'ipv4'): recipe['endpoint']}

    def check_network(self, value, recipe):
        if value.get('Driver') != 'bridge' or value.get('Internal') is True:
            raise Error('The owned Docker network configuration changed.')
        if recipe.get('ipv6_subnet'):
            subnets = {entry.get('Subnet') for entry in value.get('IPAM', {}).get('Config', [])}
            if value.get('EnableIPv6') is not True or recipe['ipv6_subnet'] not in subnets:
                raise Error('Native IPv6 transport is unavailable on the owned Docker network; existing profiles were retained.')

    @staticmethod
    def resource_roles(recipe):
        roles = [('network', 'network'), ('state', 'volume'), ('core', 'container')]
        if recipe.get('collection', 'local') in ('local', 'staged'):
            roles = [('network', 'network'), ('state', 'volume'), ('observations', 'volume'),
                     ('core', 'container'), ('probe', 'container')]
        return roles

    def ensure_resources(self, recipe, start_probe=True):
        owner = recipe['owner']
        # Inspect and validate the complete existing installation before creating
        # a missing network/volume or starting a stopped container. Otherwise a
        # later foreign resource could be discovered only after earlier mutations.
        existing = {}
        roles = self.resource_roles(recipe)
        for role, kind in roles:
            value = self.inspect(kind, self.names[role])
            existing[role] = value
            if value:
                self.verify(value, role, owner)
                if kind == 'network':
                    self.check_network(value, recipe)
                if kind == 'container':
                    self.check_container(value, role, recipe)
        if not existing['network']:
            ipv6 = ['--ipv6', '--subnet', recipe['ipv6_subnet']] if recipe.get('ipv6_subnet') else []
            self.docker.call(['network', 'create', '--driver', 'bridge', *ipv6, *self.labels('network', owner), self.names['network']])
            self.check_network(self.inspect('network', self.names['network']), recipe)
        for role in (role for role, kind in roles if kind == 'volume'):
            if not existing[role]:
                self.docker.call(['volume', 'create', *self.labels(role, owner, recipe if role == 'state' else None), self.names[role]])
        for role in (role for role, kind in roles if kind == 'container'):
            container = existing[role]
            if not container:
                self.docker.call(self.create_args(role, recipe))
            if (role != 'probe' or start_probe) and (not container or not container.get('State', {}).get('Running')):
                self.docker.call(['start', self.names[role]])

    @staticmethod
    def publish_address(address):
        return '[' + address + ']' if ':' in address else address

    def create_args(self, role, recipe):
        owner = recipe['owner']
        args = ['create', '--name', self.names[role], '--restart', 'unless-stopped',
                '--read-only', '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges=true',
                '--pids-limit', '128', '--memory', '256m',
                '--tmpfs', '/run:rw,nosuid,nodev,noexec,size=16m',
                '--tmpfs', '/tmp:rw,nosuid,nodev,noexec,size=16m', *self.labels(role, owner)]
        if role == 'core':
            args += ['--network', self.names['network'], '--hostname', recipe['name'],
                     '--sysctl', 'net.ipv4.ip_forward=0', '--sysctl', 'net.ipv6.conf.all.forwarding=0',
                     '--env', 'GRIDLENS_HOST_NETNS=' + str(os.stat('/proc/self/ns/net').st_ino),
                     '--env', 'GRIDLENS_OWNER=' + owner,
                     '--mount', 'type=volume,src=' + self.names['state'] + ',dst=/var/lib/gridlens']
            if recipe.get('collection', 'local') in ('local', 'staged'):
                args += ['--mount', 'type=volume,src=' + self.names['observations'] + ',dst=/probe,readonly']
            for capability in CORE_CAPS + (['NET_ADMIN'] if recipe['wireguard'] else []):
                args += ['--cap-add', capability]
            if recipe['bind']:
                for key, internal in [('http', 8787), ('telemetry', 8788)]:
                    args += ['--publish', f"{self.publish_address(recipe['bind'])}:{recipe['ports'][key]}:{internal}/tcp"]
            if recipe['wireguard']:
                for address in self.vpn_bindings(recipe).values():
                    args += ['--publish', f"{self.publish_address(address)}:{recipe['ports']['udp']}:51871/udp"]
            args += [recipe['image'], 'run']
        else:
            args += ['--network', 'none', '--user', '0:10002',
                     '--mount', 'type=volume,src=' + self.names['observations'] + ',dst=/probe',
                     '--mount', 'type=bind,src=/var/run/docker.sock,dst=/var/run/docker.sock,readonly',
                     '--entrypoint', '/usr/bin/python3', recipe['image'], '-B', PROBE, 'run']
        return args

    def check_container(self, container, role, recipe):
        cfg, host = container.get('Config', {}), container.get('HostConfig', {})
        if container.get('Image') != recipe['image'] or host.get('Privileged') or host.get('PidMode') or not host.get('ReadonlyRootfs'):
            raise Error('The owned container isolation/image changed.')
        expected_network = self.names['network'] if role == 'core' else 'none'
        if host.get('NetworkMode') != expected_network:
            raise Error('The owned container is no longer in its private network namespace.')
        if set(host.get('CapDrop') or []) != {'ALL'}:
            raise Error('Container capability isolation changed.')
        expected_caps = set(CORE_CAPS + (['NET_ADMIN'] if recipe['wireguard'] else [])) if role == 'core' else set()
        if {cap.removeprefix('CAP_') for cap in host.get('CapAdd') or []} != expected_caps:
            raise Error('Container capabilities changed.')
        if not any(option.replace('=', ':') == 'no-new-privileges:true' for option in host.get('SecurityOpt', [])):
            raise Error('Container privilege-escalation protection changed.')
        if host.get('Devices') or host.get('DeviceRequests') or host.get('VolumesFrom'):
            raise Error('Unexpected container devices or inherited mounts.')
        if cfg.get('User', '') not in (('', '0', '0:0') if role == 'core' else ('0:10002',)):
            raise Error('Container execution identity changed.')
        expected_entrypoint = ['/usr/bin/python3', '-B', RUNTIME] if role == 'core' else ['/usr/bin/python3']
        expected_command = ['run'] if role == 'core' else ['-B', PROBE, 'run']
        if cfg.get('Entrypoint') != expected_entrypoint or cfg.get('Cmd') != expected_command:
            raise Error('The owned container command changed.')
        env = dict(item.split('=', 1) for item in cfg.get('Env', []) if '=' in item)
        if role == 'core' and (env.get('GRIDLENS_OWNER') != recipe['owner'] or not env.get('GRIDLENS_HOST_NETNS', '').isdecimal()):
            raise Error('The container ownership or network attestation changed.')
        if any(key.startswith(('LD_', 'PYTHONPATH', 'PYTHONHOME')) for key in env):
            raise Error('The container execution environment changed.')
        expected_mounts = {}
        if recipe.get('collection', 'local') in ('local', 'staged'):
            expected_mounts['/probe'] = ('volume', self.names['observations'], role == 'probe')
        if role == 'core':
            expected_mounts['/var/lib/gridlens'] = ('volume', self.names['state'], True)
        else:
            expected_mounts['/var/run/docker.sock'] = ('bind', '/var/run/docker.sock', False)
        actual = {m['Destination']: (m['Type'], m.get('Name') if m['Type'] == 'volume' else m['Source'], m['RW'])
                  for m in container.get('Mounts', []) if m['Type'] != 'tmpfs'}
        if actual != expected_mounts:
            raise Error('The owned container mounts changed.')
        if role == 'core':
            if host.get('Sysctls', {}).get('net.ipv4.ip_forward') != '0' or host.get('Sysctls', {}).get('net.ipv6.conf.all.forwarding') != '0':
                raise Error('Container forwarding must remain disabled.')
            expected_ports = {str(internal) + '/tcp': [{'HostIp': recipe['bind'], 'HostPort': str(recipe['ports'][key])}]
                              for key, internal in [('http', 8787), ('telemetry', 8788)]} if recipe['bind'] else {}
            if recipe['wireguard']:
                expected_ports['51871/udp'] = [{'HostIp': address, 'HostPort': str(recipe['ports']['udp'])} for address in self.vpn_bindings(recipe).values()]
            normalize = lambda ports: {k: sorted((p['HostIp'], p['HostPort']) for p in v) for k, v in (ports or {}).items()}
            if normalize(host.get('PortBindings')) != normalize(expected_ports):
                raise Error('Published Docker ports changed; saved client endpoints must be preserved.')
        elif host.get('PortBindings'):
            raise Error('The local probe cannot publish network ports.')
        if host.get('RestartPolicy', {}).get('Name') != 'unless-stopped':
            raise Error('The owned container restart policy changed.')

    def configure(self, options):
        if self.existing_recipe():
            raise Error('This installation already exists; rerun reuses it rather than resetting it.')
        self.validate_install_network(options)
        if not self.pilot and self.legacy_provider is None and any(Path(p).exists() for p in ('/opt/fleet-dashboard', '/var/lib/fleet-dashboard-control')):
            raise Error('A legacy host-service installation exists. Preserve it until the Docker migration is reviewed; use an isolated pilot on separate ports.')
        for role, kind in [('core', 'container'), ('probe', 'container'), ('network', 'network'), ('observations', 'volume')]:
            if self.inspect(kind, self.names[role]):
                raise Error('A Docker resource name is already in use; it will not be adopted: ' + self.names[role])
        name = options.get('name', '')
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', name) or type(options.get('wireguard')) is not bool:
            raise Error('Invalid PC name or VPN choice.')
        image = self.inspect('image', self.image)
        if not image or not re.fullmatch(r'sha256:[a-f0-9]{64}', image.get('Id', '')):
            raise Error('Load the verified GridLens Docker image before configuring this PC.')
        udp_port = options.get('udpPort', self.ports['udp'])
        if type(udp_port) is not int or not 1024 <= udp_port <= 65535:
            raise Error('Choose an unprivileged UDP port.')
        ports = {**self.ports, 'udp': udp_port}
        endpoints = options.get('endpoints')
        endpoint = options.get('endpoint', '')
        if isinstance(endpoints, dict) and endpoints:
            endpoint = endpoints.get('ipv4') or endpoints.get('ipv6')
        self.validate_endpoint(endpoint, options['wireguard'])
        wrappers = options.get('wrappers', self.wrappers)
        if not isinstance(wrappers, list) or len(wrappers) > 15 or any(
                not isinstance(w, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', w) for w in wrappers):
            raise Error('Invalid explicit runtime wrapper names.')
        if len(set(wrappers)) != len(wrappers):
            raise Error('Use distinct runtime wrapper names.')
        if 'bind' in options:
            self.bind = private_ip(options['bind']) if options['bind'] is not None else None
        elif self.bind is None:
            inventory = host_addresses()
            self.bind = next((value for value in inventory['private'] if ':' not in value), next(iter(inventory['private']), None))
        bindings = options.get('vpnBindings', options.get('vpn_bindings'))
        if bindings is None:
            bindings = {('ipv6' if ':' in self.bind else 'ipv4'): self.bind} if self.bind and options['wireguard'] else {}
        if endpoints is None:
            family = 'ipv6' if ':' in endpoint else 'ipv4'
            endpoints = {family: endpoint} if endpoint else {}
            # Retain prior private IPv6 + hostname use without attributing public
            # IPv6 proof to a hostname with uncertain resolution.
            if set(bindings) == {'ipv6'} and set(endpoints) == {'ipv4'}:
                endpoints = {'ipv6': endpoint}
        recipe = {'schema': 2, 'owner': secrets.token_hex(16), 'prefix': self.prefix,
                  'image': image['Id'], 'bind': self.bind, 'ports': ports, 'name': name,
                  'wireguard': options['wireguard'], 'endpoint': endpoint,
                  'wrappers': wrappers, 'vpn_bindings': bindings, 'endpoints': endpoints,
                  'launch_revision': 1}
        if 'ipv6' in bindings:
            recipe['ipv6_subnet'] = str(ipaddress.ip_network('fd' + secrets.token_hex(1) + ':' + secrets.token_hex(2) + ':' + secrets.token_hex(2) + ':1::/64'))
        legacy = None
        if self.legacy_provider is not None:
            legacy = self.legacy_provider()
            if not isinstance(legacy, dict):
                raise Error('Existing GridLens import was not valid.')
            recipe['collection'] = 'replica'
            recipe['wrappers'] = []
        self.validate_recipe(recipe)
        # Record a complete public recipe in volume labels before starting any
        # container. Private keys are generated inside the volume, never here.
        self.docker.call(['volume', 'create', *self.labels('state', recipe['owner'], recipe), self.names['state']])
        self.ensure_resources(recipe)
        try:
            result = self.initialize(recipe, legacy)
            self.save_metadata(recipe)
            return self.view(result, recipe)
        finally:
            if legacy is not None:
                legacy.clear()

    def initialize(self, recipe, legacy=None, configure_probe=True):
        options = {'name': recipe['name'], 'advertise_host': recipe['bind'] or '',
                   'mode': 'wireguard' if recipe['wireguard'] else 'existing-network',
                   'endpoint': recipe['endpoint'], 'external_http_port': recipe['ports']['http'],
                   'external_udp_port': recipe['ports']['udp'], 'external_telemetry_port': recipe['ports']['telemetry']}
        if recipe['schema'] == 2:
            options.update(endpoints=recipe['endpoints'], management_available=bool(recipe['bind']))
        replica = recipe.get('collection') == 'replica'
        if replica:
            options['collect'] = False
            current = self.runtime('status')
            if not current.get('initialized') and legacy is None:
                if self.legacy_provider is None:
                    raise Error('Run the guided Docker installer to resume the existing fleet import.')
                legacy = self.legacy_provider()
            if legacy is not None:
                options['legacy'] = legacy
        try:
            result = self.runtime('init', options)
        finally:
            if legacy is not None:
                legacy.clear()
        status = self.runtime('status')
        if not replica and configure_probe:
            probe = status.get('probe_config')
            if not probe:
                registration = status.get('source_registration') or result.get('source_registration')
                if not registration:
                    raise Error('The container did not provide its persistent source identity.')
                probe = {'hostID': registration['hostID'], 'name': registration['name'], 'address': registration['address'],
                         'runtimes': ['docker'], 'wrappers': recipe['wrappers'], 'output': '/probe/probe.json'}
            self.configure_probe(probe, status.get('probe_previous_digest'))
            if not status.get('probe_config') and status.get('telemetry_membership_version'):
                self.runtime('telemetry-probe-commit', {'probe': probe})
                status = self.runtime('status')
        # This one-time secret is shown only by the terminal conversation.
        # Do not put it in Docker labels, logs, arguments or a saved recipe.
        if result.get('operator_login'):
            status['operator_login'] = result.pop('operator_login')
        return status

    def configure_probe(self, probe, previous_digest=None):
        args = ['exec', '-i', self.names['probe'], 'python3', '-B', PROBE, 'configure']
        if previous_digest:
            args += ['--expected-digest', previous_digest]
        self.docker.call(args, json.dumps(probe))

    def restart_core(self):
        recipe = self.existing_recipe()
        self.preflight(recipe)
        self.docker.call(['stop', '--time', '30', self.names['core']])
        self.docker.call(['start', self.names['core']])
        status = self.initialize(recipe)
        readiness = self.wait_core_ready()
        return {**status, 'service_readiness': readiness}

    def wait_core_ready(self, timeout=75):
        """A Docker start or persisted initialized flag is not runtime health."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                result = self.runtime('service-readiness', timeout=3)
            except (Error, OSError, ValueError, subprocess.TimeoutExpired):
                result = {}
            if (result.get('ready') is True and result.get('hub_ready') is True
                    and (not result.get('publisher_expected') or result.get('publisher_running') is True)):
                return result
            if result.get('failed'):
                raise Error('An owned service exited after startup. Activation was not confirmed; inspect the container logs and restore the prior collector membership.')
            time.sleep(.5)
        raise Error('GridLens services did not become ready before the startup deadline. Activation was not confirmed; inspect the container logs and restore the prior collector membership.')

    def telemetry_join(self, document):
        recipe = self.existing_recipe()
        self.preflight(recipe)
        result = self.runtime('telemetry-join', document)
        if result.get('probe_config') and recipe.get('collection', 'local') in ('local', 'staged'):
            self.configure_probe(result['probe_config'], result.get('probe_previous_digest'))
        self.restart_core()
        return result

    def collector_prepare(self, document):
        recipe = self.existing_recipe()
        if recipe.get('collection') not in ('replica', 'staged'):
            raise Error('Collector migration requires an existing imported Docker replica.')
        self.preflight(recipe)
        result = self.runtime('collector-prepare', document)
        # Same image, backed-up layout change. Never use the package's target
        # image as an implicit upgrade during collector preparation.
        layout = self.upgrade(image=recipe['image'], collector_wrappers=document['probe'].get('wrappers', []))
        return {**result, 'backupVolume': layout.get('backupVolume')}

    def collector_activate(self, generation):
        recipe = self.existing_recipe()
        if recipe.get('collection') != 'staged':
            raise Error('Prepare the Docker probe before activating a collector generation.')
        self.preflight(recipe)
        result = self.runtime('collector-activate', {'generation': generation})
        try:
            self.restart_core()
            confirmed = self.runtime('collector-confirm', {'generation': generation})
        except Exception as failure:
            try:
                # A failed publisher can terminate the supervisor, making exec
                # unavailable. Restore only the journaled membership offline;
                # preserve staged keys, accounts, VPN profiles and observation
                # bytes instead of restoring a whole older volume snapshot.
                self.preflight(recipe)
                self.docker.call(['stop', '--time', '30', self.names['core']])
                self.maintenance('collector-abort', recipe, {'generation': generation})
                self.restart_core()
            except Exception as recovery:
                raise Error('Collector activation was not confirmed and automatic recovery could not complete. The prepared identity and activation journal are retained; recover the prior collector membership before retrying. ' + str(recovery)) from failure
            raise Error('Collector activation failed; the prior collector membership is restored and its dashboard is ready. Prepared collector identity, accounts and VPN profiles were retained.') from failure
        return {**result, **confirmed, 'pending_confirmation': False, 'services_ready': True}

    def check_http_port_available(self, address, port):
        # Docker can publish through NAT without a listening host socket. Check
        # its running publications as well as ordinary host TCP listeners.
        result = self.docker.raw(['ps', '--format', '{{.Names}}'])
        if result.returncode:
            raise Error('Cannot check existing Docker port publications; no update was started.')
        for name in result.stdout.splitlines():
            if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,255}', name):
                raise Error('Cannot validate an existing Docker port publication.')
            container = self.inspect('container', name)
            if container is None:
                raise Error('Docker containers changed during the port check; retry the update.')
            publications = (container.get('HostConfig', {}).get('PortBindings'),
                            container.get('NetworkSettings', {}).get('Ports'))
            for bindings in publications:
                for internal, entries in (bindings or {}).items():
                    if not internal.endswith('/tcp'):
                        continue
                    for entry in entries or []:
                        if (entry.get('HostPort') == str(port)
                                and entry.get('HostIp', '') in ('', '0.0.0.0', '::', address)):
                            raise Error('That dashboard port is already published by Docker. Choose another port; existing services were kept.')
        family = socket.AF_INET6 if ipaddress.ip_address(address).version == 6 else socket.AF_INET
        try:
            with socket.socket(family, socket.SOCK_STREAM) as probe:
                probe.bind((address, port))
        except OSError as exc:
            raise Error('That dashboard address and port are unavailable. Choose a free port on this PC; existing services were kept.') from exc

    def _upgrade_plan(self, image=None, ipv6_bind=None, endpoints=None, ipv4_bind=None, http_port=None, collector_wrappers=None):
        """Inspect the saved launch and proposed effective configuration without writes."""
        old = self.existing_recipe()
        if not old:
            raise Error('There is no owned Docker installation to upgrade.')
        if self._pending:
            raise Error('An interrupted upgrade must be recovered with --rollback first.')
        # An identical image must not conceal missing resources, altered ports,
        # foreign ownership, or a container outside its saved isolation boundary.
        self.preflight(old)
        target = self.inspect('image', image or self.image)
        if target is not None and not re.fullmatch(r'sha256:[a-f0-9]{64}', target.get('Id', '')):
            raise Error('The target image has no valid Docker image identity.')
        if target is not None:
            # Read only the public schema marker, never state/key contents.
            # Pre-barrier images have no labels and support state version 1.
            version = self.maintenance('read', old).get('state_version') or 1
            labels = target.get('Config', {}).get('Labels') or {}
            try:
                minimum = int(labels.get(LABEL + '.state-min', '1'))
                maximum = int(labels.get(LABEL + '.state-max', '1'))
            except (TypeError, ValueError) as exc:
                raise Error('The target image has invalid state compatibility labels.') from exc
            if not 1 <= minimum <= version <= maximum:
                raise Error('The selected image cannot read this container state version. Use --rollback to restore the matching retained image and state together; no resources were changed.')
        new = json.loads(json.dumps(old))
        new.update(image=target['Id'] if target else old['image'])
        if collector_wrappers is not None:
            if old.get('collection') not in ('replica', 'staged'):
                raise Error('Only an imported replica can stage a replacement Docker collector.')
            new.update(collection='staged', wrappers=list(collector_wrappers))
        if http_port is not None:
            if type(http_port) is not int or not 1024 <= http_port <= 65535:
                raise Error('Choose a dashboard port from 1024 to 65535.')
            if http_port == old['ports']['telemetry']:
                raise Error('The dashboard and telemetry TCP ports must be different.')
            if not old['bind']:
                raise Error('This installation has no private dashboard address to publish. Its dashboard remains VPN-only.')
            if http_port != old['ports']['http']:
                self.check_http_port_available(old['bind'], http_port)
                new['ports']['http'] = http_port
        if ipv6_bind is not None or endpoints is not None or ipv4_bind is not None:
            if not old['wireguard']:
                raise Error('This upgrade can add endpoints only to an existing WireGuard installation.')
            new.update(schema=2, vpn_bindings=dict(self.vpn_bindings(old)), endpoints=dict(self.endpoints(old)))
            if ipv6_bind is not None:
                new['vpn_bindings']['ipv6'] = vpn_bind_address(ipv6_bind, 'ipv6')
                new['endpoints']['ipv6'] = ipv6_bind
            if ipv4_bind is not None:
                address = vpn_bind_address(ipv4_bind, 'ipv4')
                inventory = host_addresses()
                if inventory['available'] and address not in inventory['ipv4']:
                    raise Error('Select an assigned IPv4 address for VPN UDP publication.')
                new['vpn_bindings']['ipv4'] = address
                # A router's public endpoint can stay the same when only its
                # private forwarding destination changes. For a newly added
                # family, the explicit bind is a local-test default unless the
                # operator also supplies its advertised public endpoint.
                new['endpoints'].setdefault('ipv4', address)
            if endpoints is not None:
                if not isinstance(endpoints, dict):
                    raise Error('Choose a mapping of VPN endpoint families to addresses.')
                new['endpoints'].update(endpoints)
            new['endpoint'] = new['endpoints'].get('ipv4') or new['endpoints']['ipv6']
        unchanged = (target is not None and new['image'] == old['image']
                     and new['ports'] == old['ports']
                     and self.vpn_bindings(new) == self.vpn_bindings(old)
                     and self.endpoints(new) == self.endpoints(old)
                     and new.get('collection') == old.get('collection')
                     and new['wrappers'] == old['wrappers'])
        if unchanged:
            # Explicitly repeating an existing option is not a schema migration.
            # Keep the exact launch metadata, rollback recipe and backup intact.
            return old, old, True
        new['launch_revision'] = old.get('launch_revision', 1) + 1
        if 'ipv6' in self.vpn_bindings(new) and not old.get('ipv6_subnet'):
            new['ipv6_subnet'] = 'fd' + secrets.token_hex(1) + ':' + secrets.token_hex(2) + ':' + secrets.token_hex(2) + ':1::/64'
            new['network_name'] = self.prefix + '-network-v6'
        self.validate_recipe(new)
        # A staged collector adds a probe and observations volume to a replica.
        # Check collisions before a recovery journal or stopped writer exists;
        # otherwise a foreign probe could also prevent automatic rollback.
        previous_roles = set(self.resource_roles(old))
        for role, kind in self.resource_roles(new):
            if (role, kind) in previous_roles:
                continue
            existing = self.inspect(kind, self.names[role])
            if existing:
                self.verify(existing, role, old['owner'])
                if kind == 'container':
                    self.check_container(existing, role, new)
        new_network = new.get('network_name', self.prefix + '-network')
        if new_network != self.names['network']:
            network = self.inspect('network', new_network)
            if network:
                self.verify(network, 'network', old['owner'])
                self.check_network(network, new)
        return old, new, target is not None

    def _upgrade_status(self, old, new, target_available):
        core = self.inspect('container', self.names['core'])
        if not core:
            raise Error('An owned resource is missing; recover the installation before upgrading.')
        running = bool(core.get('State', {}).get('Running'))
        # status() resumes stopped containers and initializes state. Inspection
        # must instead leave a stopped installation stopped and never enroll it.
        state = self.runtime('status') if running else {'configured': True}
        return {**self.view({**state, 'running': running}, old),
                'upgraded': False, 'already_current': target_available and new == old,
                'target_available': target_available, 'current_image': old['image'],
                'target_image': new['image'] if target_available else None}

    def upgrade_status(self, image=None, ipv6_bind=None, endpoints=None, ipv4_bind=None, http_port=None):
        """Read-only comparison; an absent target image still needs preparation."""
        return self._upgrade_status(*self._upgrade_plan(image, ipv6_bind, endpoints, ipv4_bind, http_port))

    def upgrade(self, image=None, ipv6_bind=None, endpoints=None, ipv4_bind=None, http_port=None, collector_wrappers=None):
        """Explicit image/config upgrade; stopped-volume backup precedes replacement."""
        old, new, target_available = self._upgrade_plan(image, ipv6_bind, endpoints, ipv4_bind, http_port, collector_wrappers)
        if not target_available:
            raise Error('Load the verified target image before upgrading.')
        if new == old:
            return self._upgrade_status(old, new, target_available)
        new_network = new.get('network_name', self.prefix + '-network')
        backup = self.prefix + '-backup-' + secrets.token_hex(8)
        transaction = {'old': old, 'new': new, 'backup': backup}
        self.create_journal(transaction)
        try:
            self.stop_owned(old)
            self.docker.call(['volume', 'create', *self.labels('backup', old['owner'], old), backup])
            self.maintenance('backup', old, {'recipe': old, 'observations': old.get('collection', 'local') in ('local', 'staged')}, backup)
            self.maintenance('pause', old)
            self.remove_owned_containers(old)
            self.save_metadata(new)
            self.maintenance('validate', new)
            self.names['network'] = new_network
            self.ensure_resources(new, start_probe=False)
            changed_config = {}
            if new.get('endpoints') != old.get('endpoints'):
                changed_config.update(endpoints=new.get('endpoints', {}), endpoint=new['endpoint'])
            if new['ports']['http'] != old['ports']['http']:
                changed_config['external_http_port'] = new['ports']['http']
            if changed_config:
                self.runtime('upgrade-config', changed_config)
            status = self.initialize(new, configure_probe=False)
            if not status.get('initialized', status.get('configured', False)):
                raise Error('The upgraded core did not validate its saved state.')
            self.runtime('validate')
            # All source identities, account hashes and fleet state have survived
            # init/status validation before any publisher or probe is resumed.
            self.runtime('upgrade-resume')
            if new.get('collection', 'local') in ('local', 'staged'):
                self.docker.call(['start', self.names['probe']])
                status = self.initialize(new)
            if status.get('service_readiness_supported'):
                status['service_readiness'] = self.wait_core_ready()
            metadata = {'version': 1, 'recipe': new, 'rollback': transaction}
            self.maintenance('write', new, {'metadata': metadata})
            self._metadata = metadata
            self.docker.call(['volume', 'rm', self.prefix + '-upgrade'])
            self._pending = None
            return {**self.view(status, new), 'upgraded': True, 'already_current': False, 'backupVolume': backup}
        except Exception as failure:
            try:
                self.rollback_upgrade()
            except Exception as recovery:
                raise Error('Upgrade stopped; publishers remain paused or stopped. Run --rollback to recover the retained backup. ' + str(recovery)) from failure
            raise Error('Upgrade failed and the previous owned installation was restored: ' + str(failure)) from failure

    def create_journal(self, transaction):
        if self.inspect('volume', self.prefix + '-upgrade'):
            raise Error('An upgrade recovery journal already exists.')
        self.docker.call(['volume', 'create', *self.labels('upgrade', transaction['old']['owner']),
                         '--label', LABEL + '.transaction=' + json.dumps(transaction, sort_keys=True), self.prefix + '-upgrade'])
        saved = self.inspect('volume', self.prefix + '-upgrade')
        self.verify(saved, 'upgrade', transaction['old']['owner'])
        if json.loads(saved.get('Labels', {}).get(LABEL + '.transaction', '{}')) != transaction:
            raise Error('Another upgrade owns the recovery journal; no containers were stopped.')
        self._pending = transaction

    def preflight(self, recipe):
        for role, kind in self.resource_roles(recipe):
            value = self.inspect(kind, self.names[role])
            if not value:
                raise Error('An owned resource is missing; recover the installation before upgrading.')
            self.verify(value, role, recipe['owner'])
            if kind == 'container':
                self.check_container(value, role, recipe)
            elif kind == 'network':
                self.check_network(value, recipe)

    def stop_owned(self, recipe):
        for role, kind in reversed(self.resource_roles(recipe)):
            if kind != 'container':
                continue
            value = self.inspect(kind, self.names[role])
            if value:
                self.verify(value, role, recipe['owner'])
                self.check_container(value, role, recipe)
                if value.get('State', {}).get('Running'):
                    self.docker.call(['stop', '--time', '30', self.names[role]])

    def remove_owned_containers(self, recipe):
        for role, kind in reversed(self.resource_roles(recipe)):
            if kind != 'container':
                continue
            value = self.inspect(kind, self.names[role])
            if value:
                self.verify(value, role, recipe['owner'])
                self.check_container(value, role, recipe)
                if value.get('State', {}).get('Running'):
                    raise Error('Owned writers must stop before replacement.')
                self.docker.call(['rm', self.names[role]])

    def rollback_upgrade(self):
        current = self.existing_recipe()
        transaction = self._pending or (self._metadata or {}).get('rollback')
        if not current or not transaction:
            raise Error('No retained Docker upgrade is available to roll back.')
        old, new, backup = transaction['old'], transaction['new'], transaction['backup']
        for recipe in (old, new):
            self.validate_recipe(recipe)
            if recipe['owner'] != current['owner'] or recipe['prefix'] != self.prefix:
                raise Error('Rollback ownership changed.')
        if not self._pending:
            self.create_journal(transaction)
        volume = self.inspect('volume', backup)
        if volume:
            self.verify(volume, 'backup', old['owner'])
        # A crash may leave a mix of old/new containers. Validate all of them
        # before stopping any, then use each one's exact saved launch recipe.
        containers = []
        for role, kind in dict(self.resource_roles(old) + self.resource_roles(new)).items():
            if kind != 'container':
                continue
            value = self.inspect(kind, self.names[role])
            if not value:
                continue
            self.verify(value, role, old['owner'])
            # Image and network can remain identical during a port-only repair.
            # Accept only an exact old or new spec, including its publications.
            for recipe in (new, old):
                self.names['network'] = recipe.get('network_name', self.prefix + '-network')
                try:
                    self.check_container(value, role, recipe)
                    break
                except Error:
                    if recipe is old:
                        raise
            containers.append((role, value))
        for role, value in reversed(containers):
            if value.get('State', {}).get('Running'):
                self.docker.call(['stop', '--time', '30', self.names[role]])
        old_intact = current == old and len(containers) == sum(kind == 'container' for _, kind in self.resource_roles(old))
        self.names['network'] = old.get('network_name', self.prefix + '-network')
        for role, value in containers:
            try:
                self.check_container(value, role, old)
            except Error:
                old_intact = False
        if not volume and not old_intact:
            raise Error('The consistent backup is missing; owned containers remain stopped for recovery.')
        if volume:
            complete = self.backup_complete(old, backup)
            if complete:
                self.maintenance('restore', old, {'recipe': old, 'observations': old.get('collection', 'local') in ('local', 'staged')}, backup)
            elif not old_intact:
                raise Error('The backup is incomplete; retain stopped resources for manual recovery.')
        for role, _ in reversed(containers):
            self.docker.call(['rm', self.names[role]])
        self.save_metadata(old)
        self.names['network'] = old.get('network_name', self.prefix + '-network')
        self.maintenance('validate', old)
        self.ensure_resources(old, start_probe=False)
        state = self.initialize(old, configure_probe=False)
        if not state.get('initialized', state.get('configured', False)):
            raise Error('Rollback validation failed; publishers remain stopped.')
        if old.get('collection', 'local') in ('local', 'staged'):
            self.docker.call(['start', self.names['probe']])
            state = self.initialize(old)
        if state.get('service_readiness_supported'):
            state['service_readiness'] = self.wait_core_ready()
        self.docker.call(['volume', 'rm', self.prefix + '-upgrade'])
        self._pending = None
        return {**self.view(state, old), 'rolledBack': True, 'backupVolume': backup}

    def backup_complete(self, recipe, backup):
        return self.maintenance('backup-status', recipe, backup=backup).get('complete', False)

    def validate_install_network(self, options):
        """Reject an unusable new canonical route before image/resource creation.

        Existing saved recipes deliberately bypass this check: preserving an old
        working profile does not authorize changing or retiring its endpoint.
        """
        bind = options.get('bind', self.bind)
        if bind is None and 'bind' not in options:
            inventory = host_addresses()
            bind = next((value for value in inventory['private'] if ':' not in value), next(iter(inventory['private']), None))
        if not bind:
            raise Error('Assign this PC a private dashboard address before installation; no alternate dashboard URL is available.')
        bind = private_ip(bind)
        if options.get('wireguard'):
            if ipaddress.ip_address(bind).version != 4:
                raise Error('WireGuard dashboard access needs an assigned private IPv4 dashboard address.')
            endpoints = options.get('endpoints')
            if endpoints is None:
                value = options.get('endpoint', '')
                endpoints = {('ipv6' if ':' in value else 'ipv4'): value}
            if not isinstance(endpoints, dict) or not endpoints or set(endpoints) - {'ipv4', 'ipv6'}:
                raise Error('Choose at least one valid VPN endpoint.')
            for family, value in endpoints.items():
                self.validate_endpoint(value, True)
                try:
                    remote = ipaddress.ip_address(value)
                    if remote.version != (4 if family == 'ipv4' else 6):
                        raise Error('The endpoint does not match its selected family.')
                    addresses = {str(remote)}
                except ValueError:
                    try:
                        addresses = {str(ipaddress.ip_address(result[4][0])) for result in
                                     socket.getaddrinfo(value, None, socket.AF_UNSPEC, socket.SOCK_DGRAM)}
                    except (OSError, ValueError):
                        raise Error('Resolve the VPN endpoint before installation, or use a distinct literal IP address.') from None
                if not addresses or bind in addresses:
                    raise Error('VPN endpoint conflicts with the dashboard route. Use your existing network without a new VPN, or choose a distinct reachable endpoint.')
        self.bind = bind

    def access_operation(self, operation, **arguments):
        return self.runtime('access-operation', {'operation': operation, 'arguments': arguments})

    def save_access_profile(self, session, destination):
        exported = self.access_operation('export', session=session)
        config = exported.get('config')
        if not isinstance(config, str) or not config or len(config.encode()) > 2 * 1024 * 1024:
            raise Error('The controller returned an invalid profile export.')
        path = Path(destination).expanduser()
        # The operator explicitly chooses this client export. Never overwrite a
        # saved profile or follow a symlink, and never write a temporary key file.
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, 'w') as stream:
            stream.write(config)
            stream.flush()
            os.fsync(stream.fileno())
        return {key: value for key, value in exported.items() if key != 'config'}

    def browser_pair_issue(self, name):
        return self.runtime('browser-pair-issue', {'name': name})

    def browser_pair_status(self, name, grant_hash):
        return self.runtime('browser-pair-status', {'name': name, 'grant_hash': grant_hash})

    def browser_pair_cancel(self, name, grant_hash):
        return self.runtime('browser-pair-cancel', {'name': name, 'grant_hash': grant_hash})

    def add_device(self, name, app_only=False, profile=None):
        payload = {'name': name, 'app_only': app_only, 'role': 'operator'}
        if profile is not None:
            payload['profile'] = profile
        return {**self.runtime('device-add', payload), 'role': 'operator'}

    def profile_add(self, name, profile):
        return self.runtime('profile-add', {'name': name, 'profile': profile})

    def profile_cancel(self, name, profile):
        return self.runtime('profile-cancel', {'name': name, 'profile': profile})

    def test_start(self, name, profile, mobile_data):
        return self.runtime('test-start', {'name': name, 'profile': profile, 'mobile_data': mobile_data})

    def test_status(self, name, profile):
        result = self.runtime('test-status', {'name': name, 'profile': profile})
        recipe = self.existing_recipe()
        inventory = host_addresses()
        binding = self.vpn_bindings(recipe).get(profile)
        if inventory['available'] and binding not in inventory['ipv4'] + inventory['ipv6'] + inventory['private']:
            result.update(verified=False, remote_verified=False, endpoint_family_verified=False, endpoint_available=False,
                          repair='The saved VPN bind address is no longer assigned. Restore the address or repair the saved endpoint.')
        return result

    def test_cancel(self, name, profile):
        return self.runtime('test-cancel', {'name': name, 'profile': profile})

    def device_status(self, name):
        return self.runtime('device-status', {'name': name})

    def revoke_device(self, name):
        return self.runtime('device-revoke', {'name': name})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', required=True)
    parser.add_argument('--prefix', default='gridlens')
    parser.add_argument('--bind')
    parser.add_argument('--http-port', type=int, default=8789)
    parser.add_argument('--telemetry-port', type=int, default=8788)
    parser.add_argument('--udp-port', type=int, default=51871)
    parser.add_argument('--wrapper', action='append', default=[])
    parser.add_argument('--isolated-pilot', action='store_true')
    parser.add_argument('--status', action='store_true')
    args = parser.parse_args()
    try:
        driver = Driver(Docker(), args.image, args.prefix, args.bind, args.http_port,
                        args.telemetry_port, args.udp_port, args.wrapper, args.isolated_pilot)
        if args.status:
            status = driver.status()
            if status.pop('operatorLogin', None):
                raise Error('Initialization resumed. Run interactive setup to add an owner device and save its login.')
            print(json.dumps(status))
            return 0
        import container_onboarding
        with open_terminal() as terminal:
            def qr(text, kind):
                return driver.docker.call(['exec', '-i', driver.names['core'], '/usr/local/bin/gridlens',
                                           'qr', '--format', 'terminal'], text)
            container_onboarding.run_onboarding(driver, terminal, qr)
        return 0
    except (Error, OSError, ValueError, subprocess.SubprocessError) as error:
        print('GridLens Docker setup: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
